import { useEffect, useMemo, useState } from "react";
import { Stage } from "@/three/Stage";
import { ChapterRail, Nav, StatusHud } from "@/ui/Nav";
import { IgnitionSection, OutroSection } from "@/ui/sections/IgnitionSection";
import { IntroSection } from "@/ui/sections/IntroSection";
import { ChipSection, TransistorSection } from "@/ui/sections/ChipTransistor";
import { EngineSection, MemorySection } from "@/ui/sections/EngineMemory";
import { LabSection, VlsiSection } from "@/ui/sections/VlsiLab";
import { EngineeringGuide } from "@/ui/sections/EngineeringGuide";
import { useChapterScroll, usePointerField, useQualityManager, useRevealMasks } from "@/lib/hooks";
import { useUI } from "@/state/store";
import { cn } from "@/utils/cn";

function detectWebGL() {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") ?? c.getContext("webgl"));
  } catch {
    return false;
  }
}

function BootScreen() {
  const ready = useUI((s) => s.ready);
  const webgl = useUI((s) => s.webgl);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    if (!ready) return;
    const t = window.setTimeout(() => setGone(true), 900);
    return () => window.clearTimeout(t);
  }, [ready]);

  if (gone) return null;

  return (
    <div
      className={cn(
        "fixed inset-0 z-[70] flex flex-col items-center justify-center bg-[#0a0a0b] transition-opacity duration-700",
        ready ? "pointer-events-none opacity-0" : "opacity-100"
      )}
      aria-hidden={ready}
    >
      <div className="font-display text-[13px] font-bold tracking-[0.3em] text-white">
        NEURAL<span className="text-[#38bdf8]">//</span>FORGE
      </div>
      <div className="mt-5 h-[2px] w-40 overflow-hidden bg-white/10">
        <div className="h-full w-1/3 animate-[sweep_1.4s_ease-in-out_infinite] bg-[#38bdf8]" />
      </div>
      <div className="tech mt-5">
        {webgl ? "INITIALISING WEBGL DESCENT" : "WEBGL UNAVAILABLE · FALLBACK LAYOUT"}
      </div>
    </div>
  );
}

export default function App() {
  useQualityManager(true);
  const setWebgl = useUI((s) => s.setWebgl);
  const webgl = useMemo(detectWebGL, []);

  useEffect(() => {
    setWebgl(webgl);
  }, [webgl, setWebgl]);

  useChapterScroll();
  useRevealMasks();
  usePointerField();

  return (
    <>
      <Stage />

      <Nav />
      <ChapterRail />
      <StatusHud />

      <main className="nf-content relative z-10">
        <IntroSection />
        <IgnitionSection />
        <EngineeringGuide
          chapter="00"
          eyebrow="IGNITION"
          title="FROM SOFTWARE TO SILICON"
          intro="AI models are written as software, but software only becomes computation when hardware executes it. At the bottom of the stack, instructions are represented by electrical states, processed by transistor networks, and moved through memory and interconnects. This experience follows that descent from system-level intent to physical silicon."
          accent="#38bdf8"
          items={[
            { title: "Software becomes operations", tag: "ABSTRACTION", body: "A neural network or program begins as an abstract description: operations, data structures and instructions. Hardware turns those abstractions into concrete sequences of arithmetic, data movement and control signals." },
            { title: "Electrical states carry information", tag: "SIGNAL", body: "Digital hardware represents information using controlled electrical states. The exact voltage ranges depend on the technology, but the important idea is that logic is physically encoded as signals that circuits can switch, combine and store." },
            { title: "Silicon is the switching medium", tag: "MATERIAL", body: "Silicon is a semiconductor whose electrical behaviour can be engineered through doping and electric fields. That controllability makes it possible to build transistors that act as the switches from which modern logic is constructed." },
            { title: "Architecture organizes the switches", tag: "SYSTEM", body: "Individual transistors are not useful in isolation. They are assembled into gates, registers, arithmetic units, caches, interconnects and control logic. Architecture decides how these structures cooperate to execute useful computation." },
          ]}
        />
        <ChipSection />
        <EngineeringGuide
          chapter="01"
          eyebrow="THE CHIP"
          title="WHAT IS INSIDE THE PACKAGE?"
          intro="The processor you see is a stack of physical structures, each solving a different problem. Protection, thermal transfer, power delivery, high-density interconnects, compute and memory all have to coexist within a tiny package."
          accent="#38bdf8"
          items={[
            { title: "Heat spreader lid", tag: "THERMAL", body: "The lid protects the package and provides a broad thermal interface between the tiny silicon die and the cooler. It spreads heat so the cooling system can remove it more effectively." },
            { title: "Package substrate", tag: "CONNECTION", body: "The substrate behaves like a miniature multilayer circuit board. It fans dense connections from the die outward to the package contacts while also carrying power and ground into the device." },
            { title: "Silicon interposer", tag: "INTERCONNECT", body: "An interposer provides very dense wiring between nearby dies. Keeping compute and memory physically close shortens electrical paths and allows much wider connections than a conventional board-level interface." },
            { title: "Compute die", tag: "LOGIC", body: "This is the active silicon containing the logic that performs computation and control. Its transistor networks become cores, caches, schedulers, arithmetic units, memory controllers and specialized accelerators." },
            { title: "HBM stack", tag: "MEMORY", body: "High-bandwidth memory uses vertically stacked DRAM dies and a very wide interface. The goal is to move large amounts of data close to the compute die rather than relying on a narrow, distant connection." },
            { title: "I/O die", tag: "INTERFACE", body: "I/O logic connects the internal compute system to external devices and interfaces. It handles communication paths such as memory, expansion and other high-speed links so compute blocks can remain focused on processing." },
          ]}
          disclaimer="Package geometry and labels are educational representations. Exact package construction varies by architecture and product."
        />
        <TransistorSection />
        <EngineeringGuide
          chapter="02"
          eyebrow="TRANSISTOR"
          title="THE SWITCH THAT BUILDS EVERYTHING"
          intro="The transistor is the fundamental controlled switch underneath digital logic. The interactive model simplifies semiconductor physics so the relationship between gate control, channel formation and current flow is easy to see."
          accent="#10b981"
          items={[
            { title: "Gate", tag: "CONTROL", body: "The gate controls the electric field that changes the conductivity of the channel. In an insulated-gate MOS structure, the gate does not simply behave like a mechanical switch; it controls the semiconductor underneath it through an electric field." },
            { title: "Source", tag: "TERMINAL", body: "The source is one of the transistor terminals connected to the conducting region. In the simplified model, it represents the side from which charge carriers enter the channel when the device conducts." },
            { title: "Drain", tag: "TERMINAL", body: "The drain is the other main terminal of the device. When the transistor is conducting, carriers travel through the channel between the source and drain under the influence of the applied electrical conditions." },
            { title: "Channel", tag: "CONDUCTION", body: "The channel is the semiconductor region whose conductivity is controlled by the gate. When the gate voltage is sufficient, an inversion layer forms in an NMOS-style device and creates a path for current." },
            { title: "OFF → ON", tag: "SWITCHING", body: "With the gate below the required threshold, the conductive path is effectively absent in this educational model. Raising the gate creates stronger inversion, increasing conduction and allowing the model's carrier flow to appear." },
            { title: "Transistors become logic", tag: "COMPOSITION", body: "Connect transistors in carefully designed networks and they implement NOT, NAND, NOR and other logic functions. Combine those gates into adders, registers, control units and memory, and billions of simple switches become a processor." },
          ]}
          disclaimer="SIMPLIFIED DEVICE VISUALIZATION · The model illustrates the switching concept, not a full semiconductor device simulation."
        />
        <EngineSection />
        <EngineeringGuide
          chapter="03"
          eyebrow="AI ENGINE"
          title="HOW AI BECOMES MATH"
          intro="A neural network can look mysterious at the software level, but its core operations are remarkably concrete: multiply values by learned weights, accumulate the results, apply nonlinear functions and pass the result to the next layer."
          accent="#d946ef"
          items={[
            { title: "Input", tag: "DATA", body: "The input layer receives a representation of the problem: pixels, tokens, sensor readings or other numerical features. Hardware sees these values as data that must be stored, moved and operated on." },
            { title: "Weights", tag: "PARAMETERS", body: "Weights encode learned relationships between inputs and neurons. During inference, the accelerator repeatedly reads weights and activations and combines them through arithmetic operations." },
            { title: "Matrix multiplication", tag: "MATMUL", body: "Large neural-network layers can be expressed as matrix operations. Each output value is formed by multiplying corresponding elements and accumulating the products — the basic pattern behind multiply-accumulate hardware." },
            { title: "Activation", tag: "NONLINEARITY", body: "An activation function introduces nonlinearity. Without nonlinear stages, stacking linear transformations would collapse into another linear transformation and the network would lose much of its expressive power." },
            { title: "CPU vs GPU vs accelerator", tag: "ARCHITECTURE", body: "CPUs emphasize flexible general-purpose control. GPUs expose many parallel arithmetic lanes. Dedicated AI accelerators specialize further around matrix/tensor operations and efficient data movement. The comparison here is normalized and structural, not a product benchmark." },
            { title: "Why hardware matters", tag: "THROUGHPUT", body: "AI workloads repeat enormous numbers of arithmetic operations while moving large parameter and activation datasets. Specialized hardware improves efficiency by exploiting parallelism, locality and dataflow rather than treating every operation as an independent general-purpose instruction." },
          ]}
          disclaimer="NORMALIZED EDUCATIONAL COMPARISON · A × B = C is an intentionally small teaching example, not a representation of a commercial accelerator's full workload."
        />
        <MemorySection />
        <EngineeringGuide
          chapter="04"
          eyebrow="MEMORY WALL"
          title="WHEN COMPUTE HAS TO WAIT"
          intro="A processor can be capable of enormous arithmetic throughput and still spend time waiting for data. Memory hierarchy exists because speed, capacity, distance and cost pull in different directions."
          accent="#8b5cf6"
          items={[
            { title: "Registers", tag: "FASTEST", body: "Registers sit directly inside execution logic and hold values currently being operated on. They are extremely fast but limited in capacity because they must remain close to the computation itself." },
            { title: "L1 / L2 cache", tag: "SRAM", body: "Caches keep recently or frequently used data closer to the processor. SRAM is faster and denser in circuitry than DRAM, but it consumes more die area, so cache capacity is limited and organized in levels." },
            { title: "HBM", tag: "WIDE INTERFACE", body: "HBM increases memory bandwidth by using stacked DRAM and a very wide connection to the compute package. It is still much slower than local registers and caches, but it can feed large accelerators with far more data than a narrow interface." },
            { title: "DRAM", tag: "CAPACITY", body: "Main memory provides much more capacity than on-chip storage, but the physical and electrical distance makes accesses slower. Data that misses local caches may therefore cost many more cycles to retrieve." },
            { title: "Latency vs bandwidth", tag: "TRADE-OFF", body: "Latency is the delay before useful data arrives; bandwidth is the rate at which data can be transferred once the path is moving. A system can have high bandwidth and still suffer from latency, or have low latency and still be limited by insufficient total bandwidth." },
            { title: "The memory wall", tag: "BOTTLENECK", body: "As compute throughput grows, feeding the arithmetic units becomes increasingly important. When the data path cannot supply operands fast enough, compute resources sit idle. This is the core idea behind the memory-wall problem." },
          ]}
          disclaimer="LOW-ORDER EDUCATIONAL MEMORY MODEL · Latency and bandwidth relationships are illustrative teaching values, not measurements of a specific system."
        />
        <VlsiSection />
        <EngineeringGuide
          chapter="05"
          eyebrow="VLSI FOUNDRY"
          title="FROM LOGIC TO PHYSICAL GEOMETRY"
          intro="VLSI design is the process of turning a hardware description into a physical arrangement of devices and wires that can eventually be manufactured. Each stage adds physical constraints and information."
          accent="#f59e0b"
          items={[
            { title: "RTL", tag: "INTENT", body: "Register-transfer level design describes what hardware should do using registers, combinational logic and clocked behaviour. At this point the design expresses intent, not the final physical geometry of the chip." },
            { title: "Synthesis", tag: "MAPPING", body: "Synthesis transforms the RTL description into a network of logic structures chosen from a technology library. The abstract behaviour becomes a gate-level implementation that can be physically placed." },
            { title: "Gate level", tag: "STRUCTURE", body: "The design is now represented as interconnected standard cells and other logic elements. The exact physical locations are still being determined, but the logical connectivity has become explicit." },
            { title: "Floorplan + placement", tag: "GEOMETRY", body: "Floorplanning assigns major regions and resources across the die. Placement then gives individual cells coordinates, balancing area, congestion, power and timing constraints." },
            { title: "Routing", tag: "METAL", body: "Routing creates the physical metal connections between placed cells. Multiple metal layers are used because thousands or millions of signals cannot share the same physical plane without conflicts." },
            { title: "Timing analysis", tag: "CLOCK", body: "Signals need to arrive within the required timing windows. Paths that take too long relative to the clock can become critical, so designers analyze delay, setup/hold behaviour and clock relationships." },
            { title: "GDSII", tag: "LAYOUT", body: "GDSII is a layout database format used to represent physical geometry layer by layer. It captures the shapes and structures needed for downstream manufacturing preparation rather than describing the original high-level behaviour." },
            { title: "Why the flow matters", tag: "PHYSICAL DESIGN", body: "Every step reduces abstraction and introduces new constraints. A logically correct design is not automatically manufacturable or fast; physical implementation determines whether the intended circuit can actually fit, connect, power and meet timing." },
          ]}
          disclaimer="CONCEPTUAL VLSI FLOW · The visualization communicates the design-flow hierarchy and physical-design ideas; it is not a complete industrial EDA flow."
        />
        <LabSection />
        <EngineeringGuide
          chapter="06"
          eyebrow="ACCELERATOR LAB"
          title="WHY THE KNOBS MATTER"
          intro="The laboratory turns architecture trade-offs into an interactive first-principles model. The controls intentionally expose the competing resources that determine whether a workload is compute-bound, memory-bound or constrained by other modeled effects."
          accent="#10b981"
          items={[
            { title: "Core count", tag: "PARALLELISM", body: "More cores provide more potential parallel compute resources. They only improve useful throughput when the workload exposes enough parallel work and the memory system can keep those resources supplied with data." },
            { title: "Memory bandwidth", tag: "DATA RATE", body: "Bandwidth determines how quickly operands and results can move between memory and compute. If demand exceeds available bandwidth, additional arithmetic capacity may remain underutilized because the data path becomes the bottleneck." },
            { title: "Precision", tag: "FP32 → INT4", body: "Lower numerical precision can reduce the number of bits moved and stored per value, and specialized hardware can often process more low-precision values in parallel. The trade-off is reduced numerical resolution and workload-dependent accuracy implications." },
            { title: "Cache size", tag: "LOCALITY", body: "A larger cache can retain more frequently reused data close to compute, reducing expensive trips to slower memory. The benefit depends on whether the workload actually has reuse that fits the cache." },
            { title: "Clock frequency", tag: "TIME", body: "Clock frequency describes how quickly synchronous hardware advances through cycles. Increasing it can raise potential throughput, but power, thermal limits, memory delays and other bottlenecks mean performance does not automatically scale linearly with frequency." },
            { title: "Workload size", tag: "DEMAND", body: "Workload size represents the amount of modeled computation to complete. Increasing it changes total work and therefore completion time and the amount of data movement represented by the simulation." },
            { title: "Utilisation + pressure", tag: "OUTPUT", body: "Utilisation estimates how much of the modeled compute capacity is being used. Memory pressure compares data demand with the available data path; high pressure can leave compute resources waiting even when arithmetic capacity is available." },
            { title: "Thermal load", tag: "LIMIT", body: "More activity generally means more energy is dissipated as heat. The lab uses a simplified relative thermal model to show that an accelerator cannot increase every resource indefinitely without encountering physical limits." },
          ]}
          disclaimer="EDUCATIONAL FIRST-PRINCIPLES MODEL · NOT A BENCHMARK OF ANY COMMERCIAL ACCELERATOR. All outputs are relative model values intended to demonstrate architectural trade-offs."
        />
        <OutroSection />
      </main>

      <div className="grain" aria-hidden />
      <BootScreen />
    </>
  );
}

import { useEffect, useState } from "react";
import { CHAPTERS, NAV_CTA } from "@/lib/constants";
import { motion, useUI } from "@/state/store";
import { cn } from "@/utils/cn";
import { clamp } from "@/lib/math";

/* ==================================================================
 * FIXED NAVIGATION + VERTICAL CHAPTER INDICATOR
 * ================================================================== */

export function Nav() {
  const chapter = useUI((s) => s.chapter);
  const menuOpen = useUI((s) => s.menuOpen);
  const setMenuOpen = useUI((s) => s.setMenuOpen);
  const reduced = useUI((s) => s.reducedMotion);
  const [solid, setSolid] = useState(false);

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (i: number) => {
    setMenuOpen(false);
    const el = document.querySelector<HTMLElement>(`[data-chapter="${i}"]`);
    el?.scrollIntoView({ behavior: reduced ? "auto" : "smooth", block: "start" });
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-colors duration-500",
        solid ? "border-b border-white/[0.06] bg-[#0a0a0b]/88 backdrop-blur-xl" : "bg-transparent"
      )}
      style={{ height: 80 }}
    >
      <nav className="mx-auto flex h-full max-w-[1680px] items-center justify-between px-5 sm:px-8" aria-label="Primary">
        <button
          type="button"
          onClick={() => go(0)}
          className="font-display text-[13px] font-bold tracking-[0.18em] text-white transition-opacity hover:opacity-70 sm:text-[15px]"
        >
          NEURAL<span className="text-[#38bdf8]">//</span>FORGE
        </button>

        <ul className="hidden items-center gap-1 xl:flex">
          {CHAPTERS.slice(0, 7).map((c) => {
            const active = chapter === Number(c.index);
            return (
              <li key={c.id}>
                <button
                  type="button"
                  onClick={() => go(Number(c.index))}
                  aria-current={active ? "true" : undefined}
                  className={cn(
                    "group flex items-center gap-2 px-3 py-2 font-mono text-[9px] tracking-[0.24em] uppercase transition-colors",
                    active ? "text-[#38bdf8]" : "text-white/40 hover:text-white/80"
                  )}
                >
                  <span className="opacity-50">{c.index}</span>
                  {c.nav}
                </button>
              </li>
            );
          })}
        </ul>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => go(1)}
            className="hidden min-h-[38px] items-center rounded-full border border-[#38bdf8]/50 bg-[#38bdf8]/10 px-5 font-display text-[10px] font-semibold tracking-[0.18em] text-[#dff1ff] uppercase transition-all hover:border-[#38bdf8] hover:bg-[#38bdf8]/20 sm:inline-flex"
          >
            {NAV_CTA}
          </button>
          <button
            type="button"
            aria-label="Toggle chapter menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(!menuOpen)}
            className="inline-flex h-[38px] w-[38px] items-center justify-center border border-white/10 xl:hidden"
          >
            <span className="relative block h-[9px] w-[16px]">
              <span
                className={cn(
                  "absolute left-0 h-[1px] w-full bg-white/80 transition-all",
                  menuOpen ? "top-[4px] rotate-45" : "top-0"
                )}
              />
              <span
                className={cn(
                  "absolute left-0 h-[1px] w-full bg-white/80 transition-all",
                  menuOpen ? "top-[4px] -rotate-45" : "top-[8px]"
                )}
              />
            </span>
          </button>
        </div>
      </nav>

      {menuOpen && (
        <div className="glass absolute inset-x-0 top-[80px] max-h-[calc(100vh-80px)] overflow-y-auto border-t border-white/[0.06] xl:hidden">
          <ul className="px-5 py-3">
            {CHAPTERS.map((c) => (
              <li key={c.id} className="border-b border-white/[0.05] last:border-0">
                <button
                  type="button"
                  onClick={() => go(Number(c.index))}
                  className={cn(
                    "flex w-full items-center gap-4 py-4 font-mono text-[10px] tracking-[0.24em] uppercase",
                    chapter === Number(c.index) ? "text-[#38bdf8]" : "text-white/55"
                  )}
                >
                  <span className="opacity-50">{c.index}</span>
                  {c.nav}
                  <span className="ml-auto text-white/25">↓</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </header>
  );
}

export function ChapterRail() {
  const chapter = useUI((s) => s.chapter);
  const reduced = useUI((s) => s.reducedMotion);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      setProgress(clamp(motion.scroll));
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const go = (i: number) => {
    document
      .querySelector<HTMLElement>(`[data-chapter="${i}"]`)
      ?.scrollIntoView({ behavior: reduced ? "auto" : "smooth", block: "start" });
  };

  return (
    <>
      {/* scroll progress */}
      <div className="pointer-events-none fixed top-0 left-0 z-50 h-[2px] w-full bg-white/[0.04]">
        <div
          className="h-full bg-[#38bdf8]"
          style={{ width: `${progress * 100}%`, boxShadow: "0 0 12px #38bdf8" }}
        />
      </div>

      <nav
        aria-label="Chapters"
        className="fixed top-1/2 right-3 z-50 hidden -translate-y-1/2 flex-col items-center gap-[10px] md:flex"
      >
        {CHAPTERS.map((c, i) => {
          const active = chapter === i;
          return (
            <button
              key={c.id}
              type="button"
              onClick={() => go(i)}
              aria-label={`Chapter ${c.index} — ${c.nav}`}
              aria-current={active ? "true" : undefined}
              className="group flex items-center justify-end gap-3"
            >
              <span className="pointer-events-none font-mono text-[8px] tracking-[0.22em] text-white/0 uppercase transition-colors group-hover:text-white/45">
                {c.nav}
              </span>
              <span
                className="block rounded-full transition-all duration-500"
                style={{
                  width: active ? 3 : 3,
                  height: active ? 26 : 6,
                  background: active ? "#38bdf8" : "rgba(255,255,255,0.22)",
                  boxShadow: active ? "0 0 12px rgba(56,189,248,0.9)" : "none",
                }}
              />
            </button>
          );
        })}
      </nav>
    </>
  );
}

/** Fixed HUD: quality + motion state — real state, not decoration. */
export function StatusHud() {
  const quality = useUI((s) => s.quality);
  const reduced = useUI((s) => s.reducedMotion);
  const setReduced = useUI((s) => s.setReducedMotion);
  const chapter = useUI((s) => s.chapter);
  const c = CHAPTERS[chapter];

  return (
    <div className="pointer-events-none fixed bottom-4 left-4 z-50 hidden items-center gap-4 lg:flex">
      <button
        type="button"
        onClick={() => setReduced(!reduced)}
        className="pointer-events-auto flex items-center gap-2 border border-white/10 bg-[#0a0a0b]/70 px-3 py-2 font-mono text-[8px] tracking-[0.24em] text-white/45 uppercase backdrop-blur transition-colors hover:border-[#38bdf8]/40 hover:text-white/80"
      >
        <span
          className="h-[5px] w-[5px] rounded-full"
          style={{ background: reduced ? "#f59e0b" : "#10b981", boxShadow: `0 0 8px ${reduced ? "#f59e0b" : "#10b981"}` }}
        />
        MOTION {reduced ? "REDUCED" : "FULL"}
      </button>
      <span className="font-mono text-[8px] tracking-[0.24em] text-white/30 uppercase">
        RENDER {quality.toUpperCase()}
      </span>
      <span className="font-mono text-[8px] tracking-[0.24em] text-white/30 uppercase">
        DEPTH {Math.abs(c.depth).toFixed(0)}m
      </span>
    </div>
  );
}

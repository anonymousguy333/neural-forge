import { useEffect, useMemo, useRef, useState } from "react";
import { CHAPTERS, COLORS, DISCLAIMER, PRECISIONS, VLSI_STAGES } from "@/lib/constants";
import { motion, useUI } from "@/state/store";
import { labModel } from "@/lib/sim";
import { clamp, fmt, fmtInt } from "@/lib/math";
import { Field, Meter, Panel, Reveal, Segmented, Slider, TechLabel } from "@/ui/primitives";
import { CinematicLayer } from "@/ui/primitives";
import { cn } from "@/utils/cn";

/* ==================================================================
 * CHAPTER 05 — VLSI FOUNDRY
 * ================================================================== */

export function VlsiSection() {
  const chapter = CHAPTERS[5];
  const stage = useUI((s) => s.stage);
  const setStage = useUI((s) => s.setStage);
  const manual = useUI((s) => s.stageManual);
  const setManual = useUI((s) => s.setStageManual);
  const auto = useUI((s) => s.autoStage);
  const setAuto = useUI((s) => s.setAutoStage);
  const chapterNow = useUI((s) => s.chapter);
  const [shown, setShown] = useState(0);

  // scroll-derived stage (unless the user took control)
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const s = clamp(motion.camT - 5) * 7.35;
      const idx = clamp(Math.floor(s), 0, VLSI_STAGES.length - 1);
      setShown(idx);
      if (!manual && Math.floor(s) !== useUI.getState().stage) setStage(idx);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [manual, setStage]);

  // releasing manual control when the chapter is left
  useEffect(() => {
    if (chapterNow !== 5 && manual) setManual(false);
  }, [chapterNow, manual, setManual]);

  // optional auto-play through the pipeline
  useEffect(() => {
    if (!auto) return;
    const id = window.setInterval(() => {
      const s = useUI.getState();
      const next = (s.stage + 1) % VLSI_STAGES.length;
      setStage(next);
      setManual(true);
    }, 1900);
    return () => window.clearInterval(id);
  }, [auto, setStage, setManual]);

  const activeIdx = manual ? stage : shown;
  const note = VLSI_STAGES[activeIdx];

  return (
    <section id="vlsi" data-chapter="5" className="relative h-[195vh]" aria-label="VLSI foundry">
      <div className="sticky top-0 flex h-screen flex-col justify-between px-5 pt-24 pb-6 sm:px-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
          <Reveal className="max-w-xl">
            <TechLabel className="tech-sig">WATCH AN IDEA BECOME PHYSICAL · 05 · {chapter.nav}</TechLabel>
            <h2 className="mt-4 font-display text-[10vw] leading-[0.88] font-bold text-white sm:text-[6.4vw] lg:text-[3.9vw]">
              RTL BECOMES
              <br />
              PHYSICAL
            </h2>
            <p className="mt-4 max-w-md text-[14px] leading-relaxed font-light text-white/50">
              A chip is not drawn, it is compiled. Behaviour becomes gates, gates become coordinates,
              coordinates become metal, metal becomes a mask set.
            </p>
            <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2">
              {[
                { c: "#38bdf8", t: "NORMAL STRUCTURE" },
                { c: "#f59e0b", t: "ACTIVE TRANSFORMATION" },
                { c: "#ef4444", t: "CRITICAL / TIMING" },
              ].map((l) => (
                <span key={l.t} className="flex items-center gap-2 font-mono text-[8.5px] tracking-[0.22em] text-white/45 uppercase">
                  <span className="h-[6px] w-[6px] rounded-full" style={{ background: l.c, boxShadow: `0 0 8px ${l.c}` }} />
                  {l.t}
                </span>
              ))}
            </div>
          </Reveal>

          <Reveal delay={2} className="w-full lg:max-w-[330px]">
            <Panel label={`STAGE ${String(activeIdx + 1).padStart(2, "0")} / 08`} accent="rgba(245,158,11,0.5)">
              <div className="font-display text-[22px] font-bold tracking-[-0.02em] text-white">{note.label}</div>
              <p className="mt-2 text-[12.5px] leading-relaxed font-light text-white/50">{note.note}</p>
              <div className="hairline my-4" />
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => setAuto(!auto)}
                  className="min-h-[32px] border px-3 font-mono text-[9px] tracking-[0.2em] uppercase transition-colors"
                  style={{
                    borderColor: auto ? "#f59e0b" : "rgba(255,255,255,0.12)",
                    color: auto ? "#f59e0b" : "rgba(255,255,255,0.5)",
                  }}
                >
                  {auto ? "AUTO PLAY ON" : "AUTO PLAY"}
                </button>
                <button
                  type="button"
                  onClick={() => setManual(false)}
                  className="min-h-[32px] border border-white/12 px-3 font-mono text-[9px] tracking-[0.2em] text-white/50 uppercase transition-colors hover:text-white"
                >
                  FOLLOW SCROLL
                </button>
              </div>
              <p className="mt-3 font-mono text-[8.5px] leading-relaxed tracking-[0.2em] text-white/30 uppercase">
                SCROLL TO ADVANCE THE PIPELINE
              </p>
            </Panel>
          </Reveal>
        </div>

        <Reveal delay={3} fade>
          <div className="no-scrollbar -mx-1 flex gap-[6px] overflow-x-auto px-1 pb-1">
            {VLSI_STAGES.map((s, i) => {
              const done = i < activeIdx;
              const on = i === activeIdx;
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => {
                    setStage(i);
                    setManual(true);
                  }}
                  className="group relative min-h-[46px] min-w-[86px] flex-1 border px-3 py-2 text-left transition-all duration-300"
                  style={{
                    borderColor: on ? COLORS.amber : done ? "rgba(56,189,248,0.35)" : "rgba(255,255,255,0.08)",
                    background: on ? "rgba(245,158,11,0.1)" : done ? "rgba(56,189,248,0.05)" : "rgba(255,255,255,0.015)",
                  }}
                >
                  <span
                    className="mono-num block text-[9px]"
                    style={{ color: on ? COLORS.amber : done ? "rgba(56,189,248,0.8)" : "rgba(255,255,255,0.28)" }}
                  >
                    {String(i).padStart(2, "0")}
                  </span>
                  <span
                    className="mt-[2px] block font-mono text-[9px] tracking-[0.16em] uppercase"
                    style={{ color: on ? "#ffffff" : done ? "rgba(249,249,249,0.7)" : "rgba(249,249,249,0.35)" }}
                  >
                    {s.label}
                  </span>
                  {on && (
                    <span
                      className="absolute inset-x-0 bottom-0 h-[2px]"
                      style={{ background: COLORS.amber, boxShadow: `0 0 12px ${COLORS.amber}` }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ==================================================================
 * CHAPTER 06 — ACCELERATOR LAB
 * ================================================================== */

const RUN_SCALE = 0.55;

export function LabSection() {
  const chapter = CHAPTERS[6];
  const cfg = useUI((s) => s.lab);
  const setLab = useUI((s) => s.setLab);
  const running = useUI((s) => s.running);
  const setRunning = useUI((s) => s.setRunning);
  const result = useMemo(() => labModel(cfg), [cfg]);

  const barRef = useRef<HTMLDivElement>(null);
  const pctRef = useRef<HTMLSpanElement>(null);
  const etaRef = useRef<HTMLSpanElement>(null);
  const progress = useRef(0);
  const cfgKey = JSON.stringify(cfg);

  useEffect(() => {
    progress.current = 0;
  }, [cfgKey]);

  useEffect(() => {
    if (!running) return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      // completion advances on the model's own runtime, compressed for viewing
      const eta = Math.max(0.35, result.runtime * RUN_SCALE);
      progress.current = clamp(progress.current + dt / eta);
      const p = progress.current;
      if (barRef.current) barRef.current.style.width = `${p * 100}%`;
      if (pctRef.current) pctRef.current.textContent = `${fmt(p * 100, 1)}%`;
      if (etaRef.current)
        etaRef.current.textContent = p >= 0.999 ? "COMPLETE" : `${fmt((eta * (1 - p)) / 1, 2)} s`;
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [running, result.runtime]);

  return (
    <section id="lab" data-chapter="6" className="relative h-[165vh]" aria-label="Accelerator lab">
      <CinematicLayer
        src={chapter.media}
        alt=""
        opacity={0.14}
        blend="screen"
        className="inset-0"
        speed={0.05}
        grayscale={0.3}
      />
      <div className="sticky top-0 flex h-screen flex-col justify-between px-5 pt-24 pb-6 sm:px-8">
        <Reveal className="max-w-2xl">
          <TechLabel className="tech-sig">06 · {chapter.nav}</TechLabel>
          <h2 className="mt-4 font-display text-[10vw] leading-[0.88] font-bold text-white sm:text-[6.4vw] lg:text-[3.9vw]">
            BUILD YOUR
            <br />
            ACCELERATOR
          </h2>
          <p className="mt-4 max-w-lg text-[14px] leading-relaxed font-light text-white/50">
            Six decisions. Every control below feeds the same first-principles model that drives the
            floorplan behind this panel — add more cores and watch the array light up, starve the
            bandwidth and watch it stall.
          </p>
        </Reveal>

        <div className="mt-6 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <Reveal delay={2} className="w-full lg:max-w-[380px]">
            <Panel label="CONFIGURATION" accent="rgba(56,189,248,0.5)">
              <Slider
                label="CORE COUNT"
                value={cfg.cores}
                min={8}
                max={256}
                step={4}
                onChange={(v) => setLab({ cores: v })}
                display={`${cfg.cores}`}
                caption="More parallel compute resources can increase potential throughput."
              />
              <Slider
                label="MEMORY BANDWIDTH"
                value={cfg.bandwidth}
                min={0.2}
                max={2}
                step={0.01}
                onChange={(v) => setLab({ bandwidth: v })}
                display={`${fmt(cfg.bandwidth, 2)}×`}
                color="#f59e0b"
                caption="Controls how quickly data can move between memory and compute."
              />
              <Segmented
                label="PRECISION"
                value={cfg.precision}
                onChange={(v) => setLab({ precision: v })}
                options={PRECISIONS.map((p) => ({ id: p.id, label: p.label }))}
                color="#d946ef"
              />
              <p className="-mt-1 mb-1 text-[11px] leading-relaxed font-light text-white/35">
                Lower precision reduces data size and can raise dense throughput, depending on the workload.
              </p>
              <Slider
                label="CACHE SIZE"
                value={cfg.cache}
                min={1}
                max={64}
                step={1}
                onChange={(v) => setLab({ cache: v })}
                display={`${cfg.cache} MB`}
                color="#8b5cf6"
                caption="Larger local storage reduces repeated trips to slower memory."
              />
              <Slider
                label="CLOCK FREQUENCY"
                value={cfg.clock}
                min={0.8}
                max={2.6}
                step={0.05}
                onChange={(v) => setLab({ clock: v })}
                display={`${fmt(cfg.clock, 2)} GHz`}
                caption="Controls the modeled operating rate of the compute system."
              />
              <Slider
                label="WORKLOAD SIZE"
                value={cfg.workload}
                min={1}
                max={10}
                step={0.5}
                onChange={(v) => setLab({ workload: v })}
                display={`${fmt(cfg.workload, 1)} kOP`}
                caption="Determines how much computation the accelerator must process."
              />
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setRunning(!running)}
                  className="min-h-[34px] border px-3 font-mono text-[9px] tracking-[0.2em] uppercase transition-colors"
                  style={{
                    borderColor: running ? "#10b981" : "rgba(255,255,255,0.12)",
                    color: running ? "#10b981" : "rgba(255,255,255,0.5)",
                  }}
                >
                  {running ? "RUN PAUSED" : "RESUME RUN"}
                </button>
                <span className="font-mono text-[8.5px] tracking-[0.2em] text-white/30 uppercase">
                  {result.precision.label} · {result.bound} BOUND
                </span>
              </div>
            </Panel>
          </Reveal>

          <Reveal delay={3} className="w-full lg:max-w-[420px]">
            <Panel label="TELEMETRY · MODEL OUTPUT" accent="rgba(16,185,129,0.5)">
              <Meter
                label="COMPUTE UTILISATION"
                value={result.utilisation}
                color={COLORS.sig}
                danger={result.utilisation < 0.4}
              />
              <Meter
                label="MEMORY PRESSURE"
                value={clamp(result.memoryPressure / 2)}
                color={result.memoryPressure > 1.1 ? COLORS.red : COLORS.amber}
                danger={result.memoryPressure > 1.1}
                suffix={` · ${fmt(result.memoryPressure, 2)}× demand`}
              />
              <Meter label="THERMAL LOAD" value={result.thermal} color={result.thermal > 0.85 ? COLORS.red : COLORS.amber} danger={result.thermal > 0.95} />

              <div className="mt-3 py-[7px]">
                <div className="mb-[6px] flex items-baseline justify-between">
                  <span className="font-mono text-[9px] tracking-[0.24em] text-white/38 uppercase">
                    WORKLOAD COMPLETION
                  </span>
                  <span ref={pctRef} className="mono-num text-[11px] text-[#10b981]">
                    0.0%
                  </span>
                </div>
                <div className="h-[3px] w-full overflow-hidden bg-white/[0.07]">
                  <div ref={barRef} className="h-full w-0 bg-[#10b981]" style={{ boxShadow: "0 0 10px #10b981" }} />
                </div>
              </div>

              <div className="mt-3 flex items-center gap-3">
                {[
                  { k: "MEMORY PRESSURE", w: result.memoryPressure > 1.1 ? "HIGH" : result.memoryPressure > 0.85 ? "MODERATE" : "LOW", c: result.memoryPressure > 1.1 ? COLORS.red : result.memoryPressure > 0.85 ? COLORS.amber : COLORS.emerald },
                  { k: "UTILISATION", w: result.utilisation > 0.8 ? "HIGH" : result.utilisation > 0.5 ? "MODERATE" : "LOW", c: COLORS.sig },
                  { k: "THERMAL", w: result.thermal > 0.85 ? "HIGH" : result.thermal > 0.5 ? "MODERATE" : "LOW", c: result.thermal > 0.85 ? COLORS.red : COLORS.amber },
                ].map((s) => (
                  <span key={s.k} className="flex flex-1 flex-col">
                    <span className="font-mono text-[8px] tracking-[0.2em] text-white/35 uppercase">{s.k}</span>
                    <span className="mt-1 font-mono text-[10px] tracking-[0.16em]" style={{ color: s.c }}>
                      {s.w}
                    </span>
                  </span>
                ))}
              </div>

              <div className="hairline my-3" />
              <Field k="PEAK THROUGHPUT" v={`${fmtInt(result.peak)} op/s`} accent={COLORS.sig} />
              <Field
                k="ACHIEVED THROUGHPUT"
                v={`${fmtInt(result.achieved)} op/s`}
                accent={result.bound === "MEMORY" ? COLORS.amber : COLORS.emerald}
              />
              <Field k="BYTES / OP" v={fmt(result.bytesPerOp, 2)} />
              <Field k="CACHE HIT RATE" v={`${fmt(result.hitRate * 100, 0)}%`} accent={COLORS.violet} />
              <Field k="REQUIRED BANDWIDTH" v={`${fmtInt(result.requiredBandwidth)} B/s`} />
              <Field k="AVAILABLE BANDWIDTH" v={`${fmtInt(result.availableBandwidth)} B/s`} />
              <Field k="DATA MOVEMENT ENERGY" v={`${fmt(result.energyPerWork, 2)} rel`} />
              <Field
                k="ESTIMATED REMAINING"
                v={<span ref={etaRef}>—</span>}
                accent={COLORS.emerald}
              />

              <div className="mt-4 space-y-2 border-t border-white/[0.06] pt-3">
                <p className="font-mono text-[8.5px] tracking-[0.22em] text-white/40 uppercase">
                  {DISCLAIMER.lab}
                </p>
                <p className="font-mono text-[8.5px] leading-relaxed tracking-[0.18em] text-white/28 uppercase">
                  {DISCLAIMER.noBenchmark}
                </p>
              </div>
            </Panel>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

export { cn };

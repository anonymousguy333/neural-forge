import { ReactNode } from "react";
import { TechLabel } from "@/ui/primitives";

export type GuideItem = {
  title: string;
  body: ReactNode;
  tag?: string;
};

export function EngineeringGuide({
  chapter,
  eyebrow,
  title,
  intro,
  items,
  accent = "#38bdf8",
  disclaimer,
}: {
  chapter: string;
  eyebrow: string;
  title: string;
  intro: string;
  items: GuideItem[];
  accent?: string;
  disclaimer?: string;
}) {
  return (
    <div className="engineering-guide relative mx-auto max-w-[1680px] px-5 pb-28 pt-20 sm:px-8 sm:pt-24 lg:pb-36">
      <div className="grid gap-10 lg:grid-cols-[minmax(0,0.72fr)_minmax(0,1.28fr)] lg:gap-20">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <div>
            <TechLabel className="tech-sig" style={{ color: accent }}>
              {chapter} · {eyebrow}
            </TechLabel>
            <h3 className="mt-5 max-w-2xl font-display text-[11vw] font-bold leading-[0.88] tracking-[-0.045em] text-white sm:text-[7vw] lg:text-[4.5vw]">
              {title}
            </h3>
            <p className="mt-6 max-w-xl text-[15px] leading-[1.75] font-light text-white/78 sm:text-[16px]">
              {intro}
            </p>
            <div className="mt-7 h-px w-20" style={{ background: accent }} />
            <p className="mt-4 max-w-sm font-mono text-[9px] leading-[1.7] tracking-[0.18em] text-white/48 uppercase">
              Read the explanation while the 3D system remains visible. Each block corresponds to a real concept represented by the scene.
            </p>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {items.map((item, i) => (
            <div key={item.title} className="h-full">
              <article className="h-full border border-white/[0.10] bg-[#0d0e11]/88 p-5 shadow-[0_20px_70px_rgba(0,0,0,0.28)] backdrop-blur-md sm:p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="font-mono text-[9px] tracking-[0.22em] uppercase" style={{ color: accent }}>
                    {String(i + 1).padStart(2, "0")}
                  </div>
                  {item.tag && <div className="font-mono text-[8px] tracking-[0.18em] text-white/40 uppercase">{item.tag}</div>}
                </div>
                <h4 className="mt-5 font-display text-[22px] font-semibold tracking-[-0.02em] text-white sm:text-[24px]">
                  {item.title}
                </h4>
                <div className="mt-3 text-[13.5px] leading-[1.72] font-light text-white/72">{item.body}</div>
              </article>
            </div>
          ))}
        </div>
      </div>

      {disclaimer && (
        <div className="mt-10 border-t border-white/[0.08] pt-5">
          <p className="max-w-4xl font-mono text-[9px] leading-[1.7] tracking-[0.18em] text-white/45 uppercase">{disclaimer}</p>
        </div>
      )}
    </div>
  );
}

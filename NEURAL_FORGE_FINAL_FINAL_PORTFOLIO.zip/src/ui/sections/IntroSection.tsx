import { useEffect, useRef } from "react";
import { useUI } from "@/state/store";
import { motion } from "@/state/store";

/** Minimal product-launch opening: typography leads, the existing 3D world waits behind it. */
export function IntroSection() {
  const reduced = useUI((s) => s.reducedMotion);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (reduced) return;
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const el = ref.current;
      if (!el) return;
      const p = Math.min(1, Math.max(0, motion.scroll / 0.035));
      el.style.opacity = String(1 - p * 1.15);
      el.style.transform = `translate3d(0, ${-p * 90}px, 0) scale(${1 - p * 0.025})`;
      el.style.filter = `blur(${p * 5}px)`;
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [reduced]);

  const scrollToIgnition = () => {
    document.querySelector<HTMLElement>('[data-chapter="0"]')?.scrollIntoView({ behavior: reduced ? "auto" : "smooth" });
  };

  return (
    <section className="nf-opening relative z-20 flex min-h-screen items-center justify-center overflow-hidden" aria-label="Introduction">
      <div ref={ref} className="nf-opening-inner w-full max-w-[1500px] px-6 py-28 sm:px-10 lg:px-16" style={{ willChange: "transform, opacity, filter" }}>
        <div className="mb-8 flex items-center gap-3 text-[10px] font-medium uppercase tracking-[0.24em] text-white/70 sm:text-[11px]">
          <span className="h-[6px] w-[6px] rounded-full bg-[#38bdf8] shadow-[0_0_16px_rgba(56,189,248,.9)]" />
          An interactive study of computation in silicon
        </div>

        <h1 className="nf-opening-title font-display font-medium text-white">
          AI starts as an idea.
          <br />
          <span className="text-white/78">Silicon makes it real.</span>
        </h1>

        <p className="nf-opening-copy mt-8 max-w-2xl text-[17px] leading-[1.55] text-white/72 sm:text-[19px]">
          Follow a computation from software to physical hardware — from the package and silicon die down to the transistor, memory, logic and accelerator that make modern AI possible.
        </p>

        <div className="mt-12 flex items-center gap-5">
          <button type="button" onClick={scrollToIgnition} className="nf-opening-cta group inline-flex items-center gap-3 rounded-full bg-white px-6 py-3 text-[12px] font-semibold tracking-[0.08em] text-black transition-transform duration-300 hover:scale-[1.03]">
            ENTER THE EXPERIENCE
            <span className="transition-transform duration-300 group-hover:translate-x-1">↓</span>
          </button>
          <span className="hidden text-[11px] tracking-[0.08em] text-white/55 sm:inline">SCROLL TO DESCEND</span>
        </div>
      </div>

      <button type="button" onClick={scrollToIgnition} className="nf-scroll-cue absolute bottom-8 left-1/2 -translate-x-1/2 text-[9px] uppercase tracking-[0.3em] text-white/60 transition-colors hover:text-white" aria-label="Scroll to begin">
        <span>Scroll</span>
        <span className="mt-2 block text-center text-white/80">↓</span>
      </button>
    </section>
  );
}

import { useEffect, useRef } from "react";
import { CHAPTERS, COLORS } from "@/lib/constants";
import { ActionButton, CinematicLayer, Reveal, TechLabel } from "@/ui/primitives";
import { useUI } from "@/state/store";
import { motion } from "@/state/store";
import { clamp, pad2 } from "@/lib/math";

const CHAPTER = CHAPTERS[0];

/* ==================================================================
 * CHAPTER 00 — IGNITION
 * Hero text is scroll-linked to the camera: as the descent begins the
 * typography recedes (fade + scale + blur) so the 3D takes over.
 * ================================================================== */

export function IgnitionSection() {
  const reduced = useUI((s) => s.reducedMotion);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (reduced) return;
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const el = heroRef.current;
      if (!el) return;
      const e = clamp(motion.scroll / 0.045);
      el.style.opacity = String(1 - e);
      el.style.transform = `translate3d(0, ${-e * 64}px, 0) scale(${1 - e * 0.05})`;
      el.style.filter = `blur(${e * 7}px)`;
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [reduced]);

  return (
    <section data-chapter="0" className="relative min-h-screen overflow-hidden" aria-label="Ignition">
      <CinematicLayer
        src={CHAPTER.media}
        alt=""
        opacity={0.34}
        blend="screen"
        className="inset-0"
        speed={reduced ? 0 : 0.1}
        grayscale={0.1}
      />

      <div className="relative mx-auto flex min-h-screen max-w-[1680px] flex-col justify-center px-5 pt-28 pb-16 sm:px-8 lg:pt-24">
        <div ref={heroRef} className="max-w-[1500px]" style={{ willChange: "transform, opacity, filter" }}>
          <Reveal>
            <div className="mb-8 flex flex-wrap items-center gap-x-5 gap-y-2">
              <TechLabel className="tech-sig">SEMICONDUCTOR / AI HARDWARE EXPERIENCE</TechLabel>
              <span className="h-[1px] w-10 bg-[#38bdf8]/40" />
              <TechLabel>DESCENT · {CHAPTER.modeLabel}</TechLabel>
            </div>
          </Reveal>

          <Reveal delay={1}>
            <h1 className="font-display text-[15vw] leading-[0.82] font-bold text-white sm:text-[12vw] lg:text-[9.5vw] xl:text-[8.6vw]">
              NEURAL<span className="text-[#38bdf8]">//</span>FORGE
            </h1>
          </Reveal>

          <Reveal delay={2}>
            <h2 className="mt-4 font-display text-[6.4vw] leading-[0.95] font-bold tracking-[-0.04em] text-white/90 sm:text-[4.4vw] lg:text-[2.9vw]">
              WHERE INTELLIGENCE
              <br />
              BECOMES HARDWARE.
            </h2>
          </Reveal>

          <Reveal delay={3}>
            <p className="mt-7 max-w-xl text-[15px] leading-relaxed font-light text-white/55">
              AI may begin as software, but every computation eventually becomes electrical activity inside
              silicon. Descend through the stack — package, die, device, arithmetic, memory, layout — and
              operate each layer yourself.
            </p>
          </Reveal>

          <Reveal delay={4}>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <ActionButton href="#chip">ENTER THE DIE →</ActionButton>
              <ActionButton href="#vlsi" variant="ghost">
                EXPLORE THE SYSTEM
              </ActionButton>
            </div>
          </Reveal>

          <Reveal delay={5}>
            <div className="mt-8 flex flex-wrap items-center gap-x-3 gap-y-1">
              {["COMPUTATION", "SILICON", "TRANSISTORS", "MEMORY", "ARCHITECTURE"].map((t, i) => (
                <span key={t} className="flex items-center gap-3">
                  <span className="font-mono text-[8.5px] tracking-[0.26em] text-white/35 uppercase">{t}</span>
                  {i < 4 && <span className="h-[3px] w-[3px] rounded-full bg-[#38bdf8]/50" />}
                </span>
              ))}
            </div>
          </Reveal>
        </div>

        <Reveal delay={5} fade className="mt-16 lg:mt-24">
          <div className="grid grid-cols-2 gap-x-6 gap-y-5 border-t border-white/[0.07] pt-6 sm:grid-cols-4">
            {[
              { k: "SYSTEM", v: "NEURAL//FORGE" },
              { k: "STACK DEPTH", v: "8 LAYERS" },
              { k: "PASS", v: CHAPTER.modeLabel },
              { k: "STATUS", v: "ONLINE" },
            ].map((f) => (
              <div key={f.k}>
                <TechLabel>{f.k}</TechLabel>
                <div className="mono-num mt-2 text-[12px] text-white/80">{f.v}</div>
              </div>
            ))}
          </div>
        </Reveal>
      </div>

      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#0a0a0b] to-transparent" />
    </section>
  );
}

/* ==================================================================
 * CHAPTER 07 — SILICON IS REAL
 * ================================================================== */

export function OutroSection() {
  const chapter = CHAPTERS[7];
  return (
    <section
      data-chapter="7"
      className="relative min-h-[115vh] overflow-hidden"
      aria-label="Closing statement: software is the idea, silicon is where it becomes real"
    >
      <CinematicLayer
        src={chapter.media}
        alt=""
        opacity={0.34}
        blend="screen"
        className="inset-0"
        speed={0.04}
        grayscale={0.15}
      />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_68%_42%,rgba(56,189,248,0.12),transparent_34%),linear-gradient(180deg,rgba(10,10,11,0.35),rgba(10,10,11,0.82))]" aria-hidden="true" />

      <div className="relative z-10 mx-auto flex min-h-[115vh] max-w-[1680px] flex-col justify-center px-5 py-28 sm:px-8 lg:px-12">
        <div className="max-w-[1250px]">
          <TechLabel className="tech-sig text-white/80">07 · SILICON / FINAL DESCENT</TechLabel>

          <h2 className="mt-8 font-display text-[12vw] leading-[0.86] font-bold tracking-[-0.055em] text-white sm:text-[8vw] lg:text-[5.6vw]">
            SOFTWARE IS THE IDEA.
          </h2>
          <h2 className="mt-1 font-display text-[12vw] leading-[0.86] font-bold tracking-[-0.055em] text-[#38bdf8] sm:text-[8vw] lg:text-[5.6vw]">
            SILICON IS WHERE THE
            <br />
            IDEA BECOMES REAL.
          </h2>

          <p className="mt-10 max-w-4xl font-display text-[clamp(24px,3vw,44px)] leading-[1.08] font-medium tracking-[-0.025em] text-white">
            You did not just look at a chip. You followed computation all the way down to the physical machine that makes it possible.
          </p>

          <div className="mt-10 max-w-3xl space-y-4 text-[15px] leading-relaxed font-light text-white/72 sm:text-[16px]">
            <p>
              Every layer you operated is an abstraction someone chose: a language, a netlist, a floorplan,
              a mask, a switch, a voltage. Take one away and the idea stops existing physically.
            </p>
            <p className="text-white/58">
              NEURAL//FORGE is built from simplified educational models — intentionally simplified so the
              engineering structure stays visible, understandable and interactive.
            </p>
          </div>

          <div className="mt-12 flex flex-wrap gap-3">
            <ActionButton onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
              RESTART THE DESCENT
            </ActionButton>
            <ActionButton href="#lab" variant="ghost">
              BACK TO THE LAB
            </ActionButton>
          </div>
        </div>

        <div className="mt-20 border-t border-white/15 pt-6">
          <div className="grid grid-cols-2 gap-6 sm:grid-cols-4">
            {[
              { k: "INDEX", v: `${pad2(7)} / ${pad2(7)}` },
              { k: "MODEL", v: "EDUCATIONAL" },
              { k: "RENDERER", v: "WEBGL / THREE" },
              { k: "SYSTEM", v: "AI · SILICON · VLSI" },
            ].map((f) => (
              <div key={f.k}>
                <TechLabel>{f.k}</TechLabel>
                <div className="mono-num mt-2 text-[12px] text-white/80">{f.v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

import { useMemo } from "react";
import { ARCHETYPES, CHAPTERS, COLORS, DISCLAIMER, MEMORY_LEVELS } from "@/lib/constants";
import { useUI } from "@/state/store";
import { MAT_N, matmulValues, memoryModel } from "@/lib/sim";
import { clamp, fmt } from "@/lib/math";
import { useStageIndex, useVisibleAfter } from "@/lib/hooks";
import { CinematicLayer, Field, Meter, Panel, Reveal, Slider, Statement, TechLabel } from "@/ui/primitives";
import { cn } from "@/utils/cn";

/* ==================================================================
 * CHAPTER 03 — AI ENGINE
 * Three scroll bands, each with its own narrative:
 *   1. the network + the four stages a signal passes through
 *   2. the matrix multiply + the four arithmetic steps
 *   3. CPU / GPU / NPU execution models
 * ================================================================== */

const NETWORK_STEPS = [
  { t: "INPUT", d: "Data enters the first layer as a vector of values." },
  { t: "WEIGHTS", d: "Every connection carries a learned weight — the only learned thing in the network." },
  { t: "ACTIVATION", d: "A non-linear function decides whether a node fires. Without it the stack is just one big multiply." },
  { t: "OUTPUT", d: "The final layer produces a prediction or a probability." },
];

const MATH_STEPS = ["MULTIPLY", "ACCUMULATE", "ACTIVATE", "PASS FORWARD"];

export function EngineSection() {
  const chapter = CHAPTERS[3];
  const values = useMemo(() => matmulValues(7), []);
  const sub = useStageIndex(3, 3);
  const showMath = useVisibleAfter(3, 0.28);
  const phases = ["NETWORK", "A × B = C", "EXECUTION MODELS"];

  return (
    <section id="engine" data-chapter="3" className="relative h-[220vh]" aria-label="AI engine">
      <CinematicLayer
        src={chapter.media}
        alt=""
        opacity={0.16}
        blend="screen"
        className="inset-0"
        speed={0.05}
        grayscale={0.25}
      />
      <div className="sticky top-0 flex h-screen flex-col justify-between px-5 pt-24 pb-6 sm:px-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
          <Reveal className="max-w-xl">
            <TechLabel className="tech-sig">THE AI ENGINE · 03 · {chapter.nav}</TechLabel>
            <h2 className="mt-4 font-display text-[10vw] leading-[0.88] font-bold text-white sm:text-[6.4vw] lg:text-[3.9vw]">
              MATH BECOMES
              <br />
              MOTION
            </h2>
            <p className="mt-4 max-w-md text-[14px] leading-relaxed font-light text-white/50">
              A network is not a metaphor. It is a schedule of multiplications and additions, laid out in
              silicon, timed against a clock.
            </p>

            <div className="mt-5 flex flex-wrap gap-2">
              {phases.map((p, i) => (
                <span
                  key={p}
                  className={cn(
                    "border px-3 py-[6px] font-mono text-[8.5px] tracking-[0.2em] uppercase transition-all duration-300",
                    i === sub ? "border-[#38bdf8]/70 bg-[#38bdf8]/12 text-[#9ad9ff]" : "border-white/[0.08] text-white/35"
                  )}
                >
                  {p}
                </span>
              ))}
            </div>

            {/* data pipeline steps — the four stages a signal traverses */}
            <div className="mt-6 flex flex-col gap-[2px]">
              {NETWORK_STEPS.map((s, i) => {
                const active = sub === 0 && showMath === false;
                const on = sub === 0;
                return (
                  <div
                    key={s.t}
                    className={cn(
                      "flex items-baseline gap-3 border-l-2 py-[3px] pl-3 transition-all duration-500",
                      on ? "border-[#d946ef]/60 opacity-100" : "border-transparent opacity-15"
                    )}
                  >
                    <span className="mono-num text-[9px] text-[#d946ef]/80">{`0${i + 1}`}</span>
                    <span
                      className={cn(
                        "font-mono text-[10px] tracking-[0.22em] uppercase transition-all duration-500",
                        active ? "text-white" : "text-white/60"
                      )}
                    >
                      {s.t}
                    </span>
                    <span
                      className={cn(
                        "text-[11px] font-light text-white/45 transition-opacity duration-500",
                        active ? "max-w-xs opacity-100" : "hidden opacity-0"
                      )}
                    >
                      {s.d}
                    </span>
                    <span className="ml-auto text-[#d946ef]/60">↓</span>
                  </div>
                );
              })}
            </div>

            {/* multiply-accumulate annotations */}
            {showMath && (
              <div className="mt-6 flex flex-wrap items-center gap-x-4 gap-y-1">
                {MATH_STEPS.map((m, i) => (
                  <span key={m} className="flex items-center gap-3">
                    <span className="font-mono text-[9px] tracking-[0.24em] text-[#38bdf8]/85 uppercase">{m}</span>
                    {i < MATH_STEPS.length - 1 && <span className="text-[#38bdf8]/50">→</span>}
                  </span>
                ))}
              </div>
            )}
          </Reveal>

          <Reveal delay={2} className="w-full lg:max-w-[430px]">
            <Panel label="A × B = C · 4×4 EDUCATIONAL TILE" accent="rgba(217,70,239,0.5)">
              <div className="grid grid-cols-3 gap-3">
                {[
                  { k: "A", m: values.a, c: COLORS.sig },
                  { k: "B", m: values.b, c: COLORS.violet },
                  { k: "C", m: values.c, c: COLORS.magenta },
                ].map((g) => (
                  <div key={g.k}>
                    <div className="mb-2 font-mono text-[9px] tracking-[0.24em]" style={{ color: g.c }}>
                      {g.k}
                    </div>
                    <div className="grid gap-[2px]" style={{ gridTemplateColumns: `repeat(${MAT_N}, minmax(0, 1fr))` }}>
                      {g.m.flat().map((v, i) => (
                        <div
                          key={i}
                          className="mono-num flex h-[19px] items-center justify-center border text-[9px]"
                          style={{
                            borderColor: `${g.c}22`,
                            background: `${g.c}${Math.round(clamp(Math.abs(v) / 12) * 40 + 6)
                              .toString(16)
                              .padStart(2, "0")}`,
                            color: "rgba(249,249,249,0.85)",
                          }}
                        >
                          {v}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <div className="hairline my-4" />
              <Field k="OPERATION" v="MATRIX MULTIPLY" />
              <Field k="ACCUMULATION" v="k = 0 → 3, PER OUTPUT" />
              <Field k="MACS REQUIRED" v={`${MAT_N * MAT_N * MAT_N}`} />
              <Field k="MODEL" v="CONCEPTUAL" />
            </Panel>
          </Reveal>
        </div>

        <Reveal delay={3} className="w-full lg:max-w-[760px]">
          <Panel label="EXECUTION MODELS" accent="rgba(16,185,129,0.45)">
            <div className="grid gap-5 sm:grid-cols-3">
              {ARCHETYPES.map((a) => (
                <div key={a.id} className="border border-white/[0.06] p-3">
                  <div className="flex items-baseline justify-between">
                    <span className="font-display text-[13px] font-semibold tracking-[0.06em]" style={{ color: a.color }}>
                      {a.label}
                    </span>
                    <span className="font-mono text-[8px] tracking-[0.2em] text-white/30 uppercase">
                      {a.lanes.split(" ")[0]}
                    </span>
                  </div>
                  <p className="mt-2 text-[12px] leading-relaxed font-light text-white/45">{a.note}</p>
                  <div className="mt-3">
                    <Meter label="PARALLEL LANES" value={clamp(a.parallel / 1.4)} color={a.color} />
                    <Meter label="CONTROL LOGIC" value={a.control} color={COLORS.sig} />
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-4 font-mono text-[8.5px] tracking-[0.22em] text-white/35 uppercase">
              {DISCLAIMER.normalized} · STRUCTURAL DIFFERENCE, NOT A SPEED CLAIM
            </p>
          </Panel>
        </Reveal>
      </div>
    </section>
  );
}

/* ==================================================================
 * CHAPTER 04 — MEMORY WALL
 * The explanation responds to the bandwidth control and the model.
 * ================================================================== */

export function MemorySection() {
  const chapter = CHAPTERS[4];
  const bandwidth = useUI((s) => s.bandwidth);
  const setBandwidth = useUI((s) => s.setBandwidth);
  const model = useMemo(() => memoryModel(bandwidth), [bandwidth]);
  const showStatement = useVisibleAfter(4, 0.55);

  const stateLine =
    model.congestion > 0.6
      ? "Congestion is rising at the interface. The compute units are spending more cycles waiting for data — throughput is falling even though the arithmetic is ready."
      : model.utilisation < 0.62
        ? "Traffic is flowing but the interface is the limit. Efficient as the array is, it is being starved by the trip to memory."
        : "Bandwidth is ample. The arithmetic units stay fed and busy — this is the configuration where compute, not data movement, sets the ceiling.";

  const stateColor = model.congestion > 0.6 ? COLORS.red : model.utilisation < 0.62 ? COLORS.amber : COLORS.emerald;

  return (
    <section id="memory" data-chapter="4" className="relative h-[165vh]" aria-label="Memory wall">
      <div className="sticky top-0 flex h-screen flex-col justify-between px-5 pt-24 pb-6 sm:px-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
          <Reveal className="max-w-xl">
            <TechLabel className="tech-sig">THE MEMORY WALL · 04 · {chapter.nav}</TechLabel>
            <h2 className="mt-4 font-display text-[10vw] leading-[0.88] font-bold text-white sm:text-[6.4vw] lg:text-[3.9vw]">
              COMPUTE IS FAST.
              <br />
              <span className="text-[#f59e0b]">DATA MOVEMENT</span>
              <br />
              BECOMES THE WALL.
            </h2>
            <p className="mt-4 max-w-md text-[14px] leading-relaxed font-light text-white/50">
              Pull the bandwidth control down. The arithmetic units do not get slower — they start waiting,
              and the queue at the interface is where your performance goes.
            </p>

            <p
              className="mt-5 max-w-md border-l-2 pl-3 text-[13px] leading-relaxed font-light transition-colors duration-500"
              style={{ borderColor: stateColor }}
            >
              <span className="font-mono text-[8.5px] tracking-[0.22em] uppercase" style={{ color: stateColor }}>
                LIVE ·
              </span>{" "}
              <span className="text-white/65">{stateLine}</span>
            </p>

            {showStatement && (
              <Reveal fade className="mt-5">
                <Statement className="text-[16px] sm:text-[19px] text-white/75">
                  Data movement is part of computation.
                </Statement>
              </Reveal>
            )}
          </Reveal>

          <Reveal delay={2} className="w-full lg:max-w-[400px]">
            <Panel label="INTERFACE CONTROL" accent="rgba(245,158,11,0.5)">
              <Slider
                label="MEMORY BANDWIDTH (RELATIVE)"
                value={bandwidth}
                min={0.15}
                max={1.9}
                step={0.01}
                onChange={setBandwidth}
                display={`${fmt(bandwidth, 2)}×`}
                color="#f59e0b"
                caption="Raise it to feed faster — lower it to watch the queue grow."
              />
              <div className="hairline my-3" />
              <Meter label="COMPUTE UTILISATION" value={model.utilisation} color={COLORS.sig} />
              <Meter
                label="STALL CYCLES"
                value={model.stall}
                color={model.stall > 0.5 ? COLORS.red : COLORS.amber}
                danger={model.stall > 0.55}
              />
              <Meter label="QUEUE PRESSURE" value={model.congestion} color={COLORS.red} danger={model.congestion > 0.6} />
              <div className="hairline my-3" />
              <Field k="DEMAND" v={`${fmt(model.demand, 2)} B/op`} accent={COLORS.sig} />
              <Field k="SUPPLIED" v={`${fmt(model.supplied, 2)} B/op`} accent={COLORS.amber} />
              <Field k="THROUGHPUT" v={`${fmt(model.throughput * 100, 0)}%`} />
              <Field
                k="LIMITING LEVEL"
                v={MEMORY_LEVELS[model.levelIndex].label}
                accent={MEMORY_LEVELS[model.levelIndex].color}
              />
              <Field k="MODEL" v="LOW-ORDER" />
            </Panel>
          </Reveal>
        </div>

        <Reveal delay={3} className="w-full">
          <Panel label="HIERARCHY · DISTANCE IS LATENCY" accent="rgba(139,92,246,0.45)">
            <div className="grid gap-x-6 gap-y-2 sm:grid-cols-2 lg:grid-cols-5">
              {MEMORY_LEVELS.map((l, i) => {
                const active = i === model.levelIndex;
                return (
                  <div
                    key={l.id}
                    className="border-l py-1 pl-3 transition-colors"
                    style={{ borderColor: active ? l.color : "rgba(255,255,255,0.09)" }}
                  >
                    <div className="font-mono text-[9px] tracking-[0.2em] uppercase" style={{ color: active ? l.color : "rgba(249,249,249,0.6)" }}>
                      {l.label}
                    </div>
                    <div className="mono-num mt-1 text-[11px] text-white/50">~{l.latency} cyc</div>
                    <div className="mt-1 font-mono text-[8px] tracking-[0.18em] text-white/30 uppercase">{l.capacity}</div>
                    <p className="mt-2 text-[11.5px] leading-relaxed font-light text-white/40">{l.note}</p>
                  </div>
                );
              })}
            </div>
            <p className="mt-4 font-mono text-[8.5px] tracking-[0.22em] text-white/35 uppercase">
              {DISCLAIMER.memory} · LATENCIES ARE ORDER-OF-MAGNITUDE TEACHING VALUES
            </p>
          </Panel>
        </Reveal>

        <div className="pointer-events-none absolute right-0 bottom-0 hidden h-[22vh] w-[30vw] opacity-30 xl:block">
          <div className="scanlines media-mask relative h-full w-full overflow-hidden">
            <img src={chapter.media} alt="" className="h-full w-full object-cover mix-blend-screen" loading="lazy" />
          </div>
        </div>
      </div>
    </section>
  );
}

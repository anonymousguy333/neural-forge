import { useEffect, useMemo } from "react";
import { CHAPTERS, COLORS, DISCLAIMER, PACKAGE_PARTS, TRANSISTOR_LEVELS } from "@/lib/constants";
import { useUI } from "@/state/store";
import { motion } from "@/state/store";
import { transistorModel } from "@/lib/sim";
import { clamp, fmt } from "@/lib/math";
import { useStageIndex, useVisibleAfter } from "@/lib/hooks";
import { CinemaBand, Field, Meter, Panel, Reveal, Segmented, Slider, Statement, TechLabel } from "@/ui/primitives";
import { cn } from "@/utils/cn";

/* ==================================================================
 * CHAPTER 01 — THE CHIP
 * The narrative sequence drives the 3D: as you scroll, each layer of
 * the exploded package is introduced through the animation itself.
 * ================================================================== */

const CHIP_FLOW = [
  { id: "lid", n: "01", label: "PACKAGE", text: "Protects the silicon and provides the physical interface to the outside world." },
  { id: "substrate", n: "02", label: "SUBSTRATE", text: "Routes electrical connections between the package and the silicon die." },
  { id: "die", n: "03", label: "COMPUTE DIE", text: "The silicon layer where billions of transistors form logic, memory interfaces and processing structures." },
  { id: "hbm", n: "04", label: "MEMORY / I/O", text: "Stacked memory and interface logic sit beside the die to keep data close and fast." },
] as const;

export function ChipSection() {
  const chapter = CHAPTERS[1];
  const selected = useUI((s) => s.selectedPart);
  const selectPart = useUI((s) => s.selectPart);
  const exploded = useUI((s) => s.exploded);
  const setExploded = useUI((s) => s.setExploded);
  const part = PACKAGE_PARTS.find((p) => p.id === selected) ?? PACKAGE_PARTS.find((p) => p.id === "die")!;

  const step = useStageIndex(1, CHIP_FLOW.length);
  const showStatement = useVisibleAfter(1, 0.56);

  // feed the 3D auto-focus from the narrative stage (reset outside the chapter)
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const p = clamp(motion.camT - 1);
      motion.autoFocus = p >= 0 && p < 1 ? (CHIP_FLOW[Math.floor(p * CHIP_FLOW.length)]?.id ?? null) : null;
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <section id="chip" data-chapter="1" className="relative h-[150vh]" aria-label="The chip">
      <div className="sticky top-0 flex h-screen flex-col justify-between px-5 pt-24 pb-6 sm:px-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
          <Reveal className="max-w-xl">
            <TechLabel className="tech-sig">01 · {chapter.nav}</TechLabel>
            <h2 className="mt-4 font-display text-[10vw] leading-[0.88] font-bold text-white sm:text-[6.4vw] lg:text-[3.6vw]">
              DISASSEMBLE
              <br />
              THE PACKAGE
            </h2>
            <p className="mt-4 max-w-md text-[14px] leading-relaxed font-light text-white/50">
              A modern processor is not one chip. It is a stack — assembled within a millimetre. Scroll to
              follow each layer as the camera descends into the package.
            </p>

            {/* narrative sequence: one layer at a time */}
            <div className="mt-6 space-y-[2px]">
              {CHIP_FLOW.map((s, i) => {
                const active = i === step;
                const done = i < step;
                return (
                  <div
                    key={s.id}
                    className={cn(
                      "flex gap-4 border-l-2 py-2 pl-3 transition-all duration-500",
                      active ? "border-[#38bdf8] opacity-100" : done ? "border-[#38bdf8]/25 opacity-60" : "border-transparent opacity-20"
                    )}
                  >
                    <span className="mono-num pt-[1px] text-[9px] text-[#38bdf8]/70">{s.n}</span>
                    <div>
                      <div
                        className="font-mono text-[10px] tracking-[0.22em] uppercase transition-colors duration-300"
                        style={{ color: active ? "#9ad9ff" : done ? "rgba(249,249,249,0.6)" : "rgba(249,249,249,0.4)" }}
                      >
                        {s.label}
                      </div>
                      <p
                        className={cn(
                          "max-w-md text-[12px] leading-relaxed font-light transition-all duration-500",
                          active ? "text-white/60 opacity-100" : "max-h-0 overflow-hidden opacity-0"
                        )}
                      >
                        {s.text}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {showStatement && (
              <Reveal fade className="mt-5">
                <Statement className="text-[16px] sm:text-[19px] text-white/75">
                  An integrated circuit is not one object. It is a hierarchy of structures built on top of one
                  another.
                </Statement>
              </Reveal>
            )}
            <p className="mt-4 font-mono text-[8.5px] tracking-[0.2em] text-white/30 uppercase">
              DRAG TO ORBIT · CLICK A COMPONENT TO FOCUS
            </p>
          </Reveal>

          <Reveal delay={2} className="w-full lg:max-w-[380px]">
            <Panel label="PACKAGE EXPLORER" accent="rgba(56,189,248,0.5)">
              <div className="mb-4 flex items-center justify-between">
                <span className="font-mono text-[9px] tracking-[0.22em] text-white/40 uppercase">
                  {PACKAGE_PARTS.length} COMPONENTS
                </span>
                <button
                  type="button"
                  onClick={() => setExploded(!exploded)}
                  aria-pressed={exploded}
                  className="min-h-[32px] border px-3 font-mono text-[9px] tracking-[0.2em] uppercase transition-colors"
                  style={{
                    borderColor: exploded ? "#38bdf8" : "rgba(255,255,255,0.12)",
                    color: exploded ? "#38bdf8" : "rgba(255,255,255,0.55)",
                  }}
                >
                  {exploded ? "COLLAPSE" : "EXPLODE"}
                </button>
              </div>

              <ul className="mb-4 grid grid-cols-2 gap-[6px]">
                {PACKAGE_PARTS.map((p) => {
                  const on = p.id === selected;
                  return (
                    <li key={p.id}>
                      <button
                        type="button"
                        onClick={() => selectPart(on ? null : p.id)}
                        className="min-h-[40px] w-full border px-[10px] py-2 text-left font-mono text-[8.5px] leading-[1.3] tracking-[0.14em] uppercase transition-all"
                        style={{
                          borderColor: on ? p.accent : "rgba(255,255,255,0.08)",
                          background: on ? `${p.accent}18` : "rgba(255,255,255,0.015)",
                          color: on ? p.accent : "rgba(249,249,249,0.5)",
                        }}
                      >
                        {p.label}
                      </button>
                    </li>
                  );
                })}
              </ul>

              <div className="hairline mb-4" />
              <Field k="COMPONENT" v={part.label} accent={part.accent} />
              <Field k="PROCESS" v={part.sub} />
              <p className="mt-3 text-[12.5px] leading-relaxed font-light text-white/55">{part.body}</p>
            </Panel>
          </Reveal>
        </div>

        <Reveal delay={3} fade className="hidden lg:block lg:max-w-[520px]">
          <CinemaBand src={chapter.media} label={chapter.modeLabel} caption="PACKAGE-LEVEL MACRO PASS" />
        </Reveal>
      </div>
    </section>
  );
}

/* ==================================================================
 * CHAPTER 02 — TRANSISTOR
 * The state readout is driven by the same gate value as the 3D, so ON
 * and OFF text change at the exact moment the animation responds.
 * ================================================================== */

export function TransistorSection() {
  const chapter = CHAPTERS[2];
  const gate = useUI((s) => s.gate);
  const setGate = useUI((s) => s.setGate);
  const model = useMemo(() => transistorModel(gate), [gate]);
  const level = gate < 0.02 ? TRANSISTOR_LEVELS[0] : gate > 0.9 ? TRANSISTOR_LEVELS[2] : TRANSISTOR_LEVELS[1];
  const showScale = useVisibleAfter(2, 0.5);

  const flowColor = model.flow === "ACTIVE" ? COLORS.emerald : model.flow === "WEAK" ? COLORS.amber : COLORS.red;
  const stateWord = level.id === "on" ? "CONDUCTIVE PATH FORMS" : level.id === "off" ? "NO CONDUCTIVE PATH" : "CONDUCTION BEGINS";

  return (
    <section id="transistor" data-chapter="2" className="relative h-[180vh]" aria-label="Transistor">
      <div className="sticky top-0 flex h-screen flex-col justify-between px-5 pt-24 pb-4 sm:px-8">
        <Reveal className="max-w-xl">
          <TechLabel className="tech-sig">02 · {chapter.nav}</TechLabel>
          <h2 className="mt-4 font-display text-[11vw] leading-[0.86] font-bold text-white sm:text-[6.6vw] lg:text-[3.9vw]">
            THE SMALLEST
            <br />
            SWITCH
          </h2>
          <p className="mt-4 max-w-md text-[14px] leading-relaxed font-light text-white/50">
            Modern processors are built from enormous networks of transistors — microscopic devices that
            control the flow of electrical charge. Drive the gate and watch the channel answer.
          </p>

          <div className="mt-5 flex items-center gap-4">
            <span
              className="inline-flex min-h-[42px] items-center gap-3 border px-4 font-display text-[15px] font-bold tracking-[0.14em] transition-all duration-300"
              style={{
                borderColor: level.id === "on" ? COLORS.emerald : level.id === "off" ? COLORS.red : COLORS.amber,
                color: level.id === "on" ? COLORS.emerald : level.id === "off" ? COLORS.red : COLORS.amber,
                boxShadow: `0 0 22px ${level.id === "on" ? COLORS.emerald : level.id === "off" ? COLORS.red : COLORS.amber}33`,
              }}
            >
              {level.label}
            </span>
            <span className="max-w-[260px] font-mono text-[8.5px] leading-relaxed tracking-[0.2em] text-white/45 uppercase">
              {stateWord}
            </span>
          </div>
        </Reveal>

        {showScale && (
          <div className="pointer-events-none absolute inset-0 hidden items-center justify-center lg:flex">
            <Statement className="text-center text-[10vw] text-white/90 sm:text-[6vw] lg:text-[3.5vw]">
              ONE TRANSISTOR IS SIMPLE.
              <br />
              <span className="text-[#38bdf8]">BILLIONS OF THEM FORM COMPUTATION.</span>
            </Statement>
          </div>
        )}

        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <Reveal delay={2} className="w-full lg:max-w-[400px]">
            <Panel label="DEVICE CONTROL" accent="rgba(56,189,248,0.5)">
              <Segmented
                label="GATE STATE"
                value={level.id}
                onChange={(id) => setGate(TRANSISTOR_LEVELS.find((l) => l.id === id)!.v)}
                options={TRANSISTOR_LEVELS.map((l) => ({ id: l.id, label: l.label }))}
              />
              <Slider
                label="GATE VOLTAGE (NORMALISED)"
                value={gate}
                min={0}
                max={1}
                step={0.01}
                onChange={setGate}
                display={`${fmt(gate * 100, 0)}%`}
                caption="Raise the gate voltage to create an inversion layer in the channel."
              />
              <div className="hairline my-3" />
              <Field k="DEVICE" v="NMOS CONCEPT" />
              <Field
                k="STATE"
                v={level.label}
                accent={level.id === "on" ? COLORS.emerald : level.id === "off" ? COLORS.red : COLORS.amber}
              />
              <Field k="FLOW" v={model.flow} accent={flowColor} />
              <Field k="CHANNEL" v={`${fmt(model.channel * 100, 0)}% INVERSION`} />
              <Field k="DRIVE CURRENT" v={`${fmt(model.current * 100, 0)}%`} />
              <Meter label="CONDUCTION" value={model.channel} color={flowColor} />
              <p className="mt-3 text-[12px] leading-relaxed font-light text-white/45">{level.note}</p>
            </Panel>
          </Reveal>

          <Reveal delay={3} className="w-full lg:max-w-[430px]">
            <Panel label="FROM SWITCH TO COMPUTATION" accent="rgba(217,70,239,0.45)">
              <ol className="space-y-[10px]">
                {[
                  { t: "SWITCH", d: "A gate voltage creates a channel. Current flows, or it does not." },
                  { t: "GATE (LOGIC)", d: "A few switches wired together make NAND / NOR — universal gates." },
                  { t: "WORD", d: "Gates in rows become adders, registers, multiplexers." },
                  { t: "COMPUTE", d: "Millions of those words become a multiply-accumulate array." },
                ].map((s, i) => (
                  <li key={s.t} className="flex gap-3">
                    <span className="mono-num mt-[2px] text-[10px]" style={{ color: i === 3 ? "#d946ef" : "#38bdf8" }}>
                      {`0${i + 1}`}
                    </span>
                    <div>
                      <div className="font-mono text-[9.5px] tracking-[0.2em] text-white/75 uppercase">{s.t}</div>
                      <div className="text-[12.5px] leading-relaxed font-light text-white/45">{s.d}</div>
                    </div>
                  </li>
                ))}
              </ol>
              <div className="hairline my-4" />
              <p className="font-mono text-[8.5px] tracking-[0.22em] text-white/35 uppercase">
                {DISCLAIMER.device}
              </p>
            </Panel>
          </Reveal>
        </div>

        <div className="pointer-events-none absolute right-0 bottom-0 hidden h-[24vh] w-[32vw] opacity-[0.32] xl:block">
          <div className="scanlines media-mask relative h-full w-full overflow-hidden">
            <img src={chapter.media} alt="" className="h-full w-full object-cover mix-blend-screen" loading="lazy" />
          </div>
        </div>
      </div>
    </section>
  );
}

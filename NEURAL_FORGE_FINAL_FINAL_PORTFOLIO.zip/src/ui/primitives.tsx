import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { cn } from "@/utils/cn";
import { clamp, fmt } from "@/lib/math";

/* ==================================================================
 * UI PRIMITIVES — technical instrumentation language
 * ================================================================== */

export function TechLabel({ children, className, style }: { children: ReactNode; className?: string; style?: CSSProperties }) {
  return <div className={cn("tech", className)} style={style}>{children}</div>;
}

export function Panel({
  children,
  className,
  label,
  accent = "rgba(56,189,248,0.55)",
  tone,
}: {
  children: ReactNode;
  className?: string;
  label?: string;
  accent?: string;
  tone?: "glass" | "flat";
}) {
  return (
    <div className={cn("relative", tone === "flat" ? "glass-flat" : "glass", "corner-cut p-5 sm:p-6", className)}>
      <span
        className="pointer-events-none absolute top-0 left-0 h-[2px] w-16"
        style={{ background: `linear-gradient(90deg, ${accent}, transparent)` }}
      />
      <span
        className="pointer-events-none absolute right-0 bottom-0 h-[2px] w-10"
        style={{ background: `linear-gradient(270deg, ${accent}, transparent)` }}
      />
      {label && <TechLabel className="mb-4">{label}</TechLabel>}
      {children}
    </div>
  );
}

export function Field({
  k,
  v,
  accent = "#F9F9F9",
  mono = true,
}: {
  k: string;
  v: ReactNode;
  accent?: string;
  mono?: boolean;
}) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-white/[0.05] py-[7px] last:border-0">
      <span className="font-mono text-[9px] tracking-[0.24em] text-white/38 uppercase">{k}</span>
      <span
        className={cn("text-right text-[11px] tracking-[0.06em]", mono && "mono-num")}
        style={{ color: accent }}
      >
        {v}
      </span>
    </div>
  );
}

export function Meter({
  value,
  label,
  color = "#38bdf8",
  danger = false,
  suffix,
}: {
  value: number;
  label: string;
  color?: string;
  danger?: boolean;
  suffix?: string;
}) {
  const pct = clamp(value) * 100;
  return (
    <div className="py-[7px]">
      <div className="mb-[6px] flex items-baseline justify-between">
        <span className="font-mono text-[9px] tracking-[0.24em] text-white/38 uppercase">{label}</span>
        <span className="mono-num text-[11px]" style={{ color: danger ? "#ef4444" : color }}>
          {fmt(pct, 0)}%{suffix}
        </span>
      </div>
      <div className="h-[3px] w-full overflow-hidden bg-white/[0.07]">
        <div
          className="h-full transition-[width] duration-200 ease-out"
          style={{
            width: `${pct}%`,
            background: danger ? "#ef4444" : color,
            boxShadow: `0 0 10px ${danger ? "#ef4444" : color}`,
          }}
        />
      </div>
    </div>
  );
}

export function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
  display,
  color = "#38bdf8",
  caption,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  display: string;
  color?: string;
  caption?: string;
}) {
  return (
    <label className="block py-[9px]">
      <span className="mb-[6px] flex items-baseline justify-between">
        <span className="font-mono text-[9px] tracking-[0.24em] text-white/45 uppercase">{label}</span>
        <span className="mono-num text-[11px]" style={{ color }}>
          {display}
        </span>
      </span>
      <input
        className="nf"
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        aria-label={label}
        onChange={(e) => onChange(parseFloat(e.target.value))}
      />
      {caption && (
        <span className="mt-[3px] block text-[11px] leading-relaxed font-light text-white/35">{caption}</span>
      )}
    </label>
  );
}

/** Short editorial statement — a single cinematic sentence in display type. */
export function Statement({
  children,
  className,
  accent,
}: {
  children: ReactNode;
  className?: string;
  accent?: string;
}) {
  return (
    <p
      className={cn(
        "font-display text-[7.5vw] leading-[0.98] font-bold tracking-[-0.04em] sm:text-[4vw] lg:text-[2.4vw]",
        className
      )}
      style={accent ? { color: accent } : undefined}
    >
      {children}
    </p>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  label,
  color = "#38bdf8",
}: {
  options: { id: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  label?: string;
  color?: string;
}) {
  return (
    <div className="py-[9px]">
      {label && (
        <span className="mb-[7px] block font-mono text-[9px] tracking-[0.24em] text-white/45 uppercase">{label}</span>
      )}
      <div className="flex flex-wrap gap-[6px]" role="group">
        {options.map((o) => {
          const on = o.id === value;
          return (
            <button
              key={o.id}
              type="button"
              onClick={() => onChange(o.id)}
              aria-pressed={on}
              className="min-h-[34px] border px-3 py-[7px] font-mono text-[9px] tracking-[0.2em] uppercase transition-all duration-200"
              style={{
                borderColor: on ? color : "rgba(255,255,255,0.09)",
                color: on ? "#0a0a0b" : "rgba(249,249,249,0.6)",
                background: on ? color : "rgba(255,255,255,0.02)",
                boxShadow: on ? `0 0 18px ${color}55` : "none",
              }}
            >
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function ActionButton({
  children,
  onClick,
  variant = "primary",
  href,
  className,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost";
  href?: string;
  className?: string;
}) {
  const base =
    "group relative inline-flex min-h-[48px] items-center justify-center overflow-hidden px-7 font-display text-[12px] font-semibold tracking-[0.16em] uppercase transition-all duration-300";
  const style =
    variant === "primary"
      ? "border border-[#38bdf8]/60 bg-[#38bdf8]/10 text-[#eaf7ff] hover:bg-[#38bdf8]/20 hover:border-[#38bdf8]"
      : "border border-white/10 text-white/60 hover:text-white hover:border-white/25";
  const inner = (
    <>
      <span className="relative z-10">{children}</span>
      <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-[#38bdf8]/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
    </>
  );
  if (href) {
    return (
      <a href={href} className={cn(base, style, className)}>
        {inner}
      </a>
    );
  }
  return (
    <button type="button" onClick={onClick} className={cn(base, style, className)}>
      {inner}
    </button>
  );
}

/** Parallax cinematic media layer — masked, blended, scroll-reactive. */
export function CinematicLayer({
  src,
  alt,
  opacity = 0.5,
  blend = "screen",
  className,
  speed = 0.12,
  scale = 1.12,
  grayscale = 0,
}: {
  src: string;
  alt: string;
  opacity?: number;
  blend?: string;
  className?: string;
  speed?: number;
  scale?: number;
  grayscale?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const el = ref.current;
        if (!el) return;
        const r = el.getBoundingClientRect();
        const centre = r.top + r.height / 2 - window.innerHeight / 2;
        el.style.setProperty("--nf-par", `${(-centre * speed).toFixed(1)}px`);
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [speed]);

  return (
    <div
      ref={ref}
      aria-hidden={alt === ""}
      className={cn("pointer-events-none absolute overflow-hidden", className)}
      style={{ opacity: ready ? opacity : 0, transition: "opacity 1.6s ease-out" }}
    >
      <img
        src={src}
        alt={alt}
        loading="lazy"
        decoding="async"
        onLoad={() => setReady(true)}
        className="h-full w-full object-cover"
        style={{
          mixBlendMode: blend as React.CSSProperties["mixBlendMode"],
          transform: `translate3d(0, var(--nf-par, 0px), 0) scale(${1.05 * scale})`,
          filter: `saturate(1.05) contrast(1.05) grayscale(${grayscale})`,
          willChange: "transform",
        }}
      />
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 50% 45%, transparent 35%, rgba(10,10,11,0.85) 100%), linear-gradient(180deg, rgba(10,10,11,0.7), transparent 35%, rgba(10,10,11,0.75))",
        }}
      />
    </div>
  );
}

/** Letterboxed cinematic band with scanlines + vignette. */
export function CinemaBand({ src, label, caption }: { src: string; label: string; caption: string }) {
  return (
    <figure className="scanlines vignette relative aspect-[21/9] w-full overflow-hidden border border-white/[0.06] media-mask">
      <CinematicLayer src={src} alt="" opacity={0.9} blend="normal" className="inset-0" speed={0.06} />
      <figcaption className="absolute bottom-3 left-4 flex items-center gap-3">
        <span className="h-[5px] w-[5px] rounded-full bg-[#38bdf8] pulse-sig" />
        <span className="tech text-[8px]">{label}</span>
        <span className="hidden font-mono text-[9px] text-white/35 sm:inline">{caption}</span>
      </figcaption>
    </figure>
  );
}

/** Fade-up reveal wrapper */
export function Reveal({
  children,
  className,
  delay = 0,
  fade = false,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: 0 | 1 | 2 | 3 | 4 | 5;
  fade?: boolean;
  as?: "div" | "section" | "header" | "figure" | "p" | "h2";
}) {
  return (
    <Tag className={cn("rv", fade && "rv-fade", delay && `rv-d${delay}`, className)}>{children}</Tag>
  );
}

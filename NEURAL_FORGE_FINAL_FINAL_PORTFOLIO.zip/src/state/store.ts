import { create } from "zustand";
import { CHAPTERS, type Quality } from "@/lib/constants";
import { LAB_DEFAULTS, type LabConfig, type LabResult, labModel } from "@/lib/sim";

/**
 * UI STATE (low frequency, React-driven).
 * High-frequency animation values live in `motion` — never in React state.
 */

export type ChapterId = (typeof CHAPTERS)[number]["id"];

interface UIState {
  ready: boolean;
  webgl: boolean;
  chapter: number;
  quality: Quality;
  reducedMotion: boolean;
  menuOpen: boolean;

  /* chapter 01 */
  selectedPart: string | null;
  exploded: boolean;

  /* chapter 02 */
  gate: number;

  /* chapter 04 */
  bandwidth: number;

  /* chapter 05 */
  stage: number;
  autoStage: boolean;
  stageManual: boolean;

  /* chapter 06 */
  lab: LabConfig;
  running: boolean;

  setReady: (v: boolean) => void;
  setWebgl: (v: boolean) => void;
  setChapter: (n: number) => void;
  setQuality: (q: Quality) => void;
  setReducedMotion: (v: boolean) => void;
  setMenuOpen: (v: boolean) => void;
  selectPart: (id: string | null) => void;
  setExploded: (v: boolean) => void;
  setGate: (v: number) => void;
  setBandwidth: (v: number) => void;
  setStage: (v: number) => void;
  setAutoStage: (v: boolean) => void;
  setStageManual: (v: boolean) => void;
  setLab: (patch: Partial<LabConfig>) => void;
  setRunning: (v: boolean) => void;
}

export const useUI = create<UIState>((set) => ({
  ready: false,
  webgl: true,
  chapter: 0,
  quality: "medium",
  reducedMotion: false,
  menuOpen: false,

  selectedPart: null,
  exploded: true,

  gate: 1,
  bandwidth: 0.85,

  stage: 0,
  autoStage: false,
  stageManual: false,

  lab: { ...LAB_DEFAULTS },
  running: true,

  setReady: (v) => set({ ready: v }),
  setWebgl: (v) => set({ webgl: v }),
  setChapter: (n) => set({ chapter: n }),
  setQuality: (q) => set({ quality: q }),
  setReducedMotion: (v) => set({ reducedMotion: v }),
  setMenuOpen: (v) => set({ menuOpen: v }),
  selectPart: (id) => set({ selectedPart: id }),
  setExploded: (v) => set({ exploded: v }),
  setGate: (v) => set({ gate: v }),
  setBandwidth: (v) => set({ bandwidth: v }),
  setStage: (v) => set({ stage: v }),
  setAutoStage: (v) => set({ autoStage: v }),
  setStageManual: (v) => set({ stageManual: v }),
  setLab: (patch) => set((s) => ({ lab: { ...s.lab, ...patch } })),
  setRunning: (v) => set({ running: v }),
}));

/** Convenience: latest accelerator result for the UI (memo-free, cheap model). */
export function labResult(cfg: LabConfig, completion: number): LabResult {
  return { ...labModel(cfg), completion };
}

/* ------------------------------------------------------------------ *
 * MOTION — mutable, read every frame inside the canvas. No rerenders.
 * ------------------------------------------------------------------ */

export const motion = {
  /** continuous scroll-derived camera parameter (0..CHAPTERS-1) */
  camT: 0,
  /** raw scroll progress of the document 0..1 */
  scroll: 0,
  /** scroll velocity, normalised */
  velocity: 0,
  /** pointer, normalised -1..1 */
  px: 0,
  py: 0,
  /** user drag orbit offsets */
  az: 0,
  pol: 0,
  azTarget: 0,
  polTarget: 0,
  dragging: false,
  /** backdrop energy 0..1 */
  energy: 0.35,
  /** dt clamp helper */
  time: 0,
  /** per-chapter reveal weights, updated by the camera rig */
  reveal: CHAPTERS.map(() => 0),
  /** continuous VLSI stage 0..7 (scroll derived unless overridden) */
  stageF: 0,
  /** pointer ray in NDC for raycast-driven highlights */
  ndcX: 0,
  ndcY: 0,
  /** scroll-driven emphasis target (chapter 01) — text drives the 3D */
  autoFocus: null as string | null,
};

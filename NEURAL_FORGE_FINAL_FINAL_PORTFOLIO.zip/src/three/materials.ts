import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";

/* ==================================================================
 * MATERIAL + SHADER SYSTEM
 * All cinematic motion that is not geometry lives here.
 *  - backdrop  : full-frame procedural "footage" (7 programs)
 *  - cells     : instanced static glowing structures with birth animation
 *  - flow      : instanced packets travelling A -> B (data / signals)
 * ================================================================== */

const COMMON = /* glsl */ `
float hash21(vec2 p){
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}
float vnoise(vec2 p){
  vec2 i = floor(p); vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash21(i), b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0)), d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
float fbm(vec2 p){
  float s = 0.0; float a = 0.5;
  for (int i = 0; i < 4; i++){ s += a * vnoise(p); p = p * 2.03 + vec2(11.3, 7.7); a *= 0.5; }
  return s;
}
`;

/** manhattan routing field — the visual basis of silicon */
const TRACES = /* glsl */ `
float traces(vec2 uv, float scale, float t, float thr){
  vec2 g = uv * scale;
  vec2 id = floor(g);
  vec2 f = fract(g) - 0.5;
  float h = hash21(id);
  float off = (hash21(id + 3.7) - 0.5) * 0.8;
  float w = 0.05 + 0.035 * hash21(id + 9.1);
  float horiz = step(0.5, h);
  float d = mix(abs(f.y - off), abs(f.x - off), horiz);
  float line = 1.0 - smoothstep(0.0, w, d);
  float travel = 0.5 + 0.5 * sin(mix(f.x, f.y, horiz) * 5.0 - t * 2.0 + h * 6.2831);
  return line * smoothstep(thr, 1.0, travel);
}
`;

const BACKDROP_FRAG = /* glsl */ `
uniform float uTime, uOpacity, uMode, uZoom, uEnergy, uStatic, uFocus;
uniform vec2 uAspect;
varying vec2 vUv;
${COMMON}
${TRACES}

/* 00 — WAFER : rotating die grid, iridescence, specular sweep */
vec3 modeWafer(vec2 uv, float t){
  vec2 p = uv * 1.35;
  float r = length(p);
  float a = atan(p.y, p.x);
  float rot = t * 0.06;
  vec2 q = vec2(cos(rot) * p.x - sin(rot) * p.y, sin(rot) * p.x + cos(rot) * p.y);
  vec2 g = q * 7.0;
  vec2 id = floor(g); vec2 f = fract(g);
  float inWafer = smoothstep(1.28, 1.12, r);
  float edge = min(min(f.x, f.y), min(1.0 - f.x, 1.0 - f.y));
  float grid = 1.0 - smoothstep(0.0, 0.06, edge);
  float alive = step(0.34, hash21(id));
  float shimmer = 0.35 + 0.65 * fbm(id * 0.55 + t * 0.12);
  vec3 c = vec3(0.012, 0.016, 0.022);
  vec3 irid = 0.5 + 0.5 * cos(vec3(0.0, 2.1, 4.2) + a * 2.4 + r * 6.0 - t * 0.3);
  c += irid * inWafer * (0.05 + 0.14 * shimmer);
  c += vec3(0.10, 0.42, 0.72) * grid * inWafer * alive * (0.2 + 0.9 * shimmer);
  float sweep = exp(-pow((p.y * 0.9 + p.x * 0.35 - sin(t * 0.22) * 0.9) * 1.7, 2.0));
  c += vec3(0.28, 0.5, 0.85) * sweep * inWafer * 0.55;
  float rim = smoothstep(1.02, 1.14, r) * smoothstep(1.3, 1.14, r);
  c += vec3(0.18, 0.45, 0.8) * rim;
  c *= inWafer;
  return c;
}

/* 01 — DIE DESCENT : endless zoom into routing */
vec3 modeDescent(vec2 uv, float t){
  float z = 1.0 + fract(t * 0.05) * 2.6;
  vec2 p = uv * z;
  float acc = traces(p, 6.0, t, 0.55);
  acc += 0.65 * traces(p, 14.0, t * 1.25, 0.72);
  acc += 0.4 * traces(p, 27.0, t * 1.6, 0.85);
  vec3 c = vec3(0.008, 0.012, 0.018);
  c += vec3(0.08, 0.5, 0.95) * acc * 1.25;
  c += vec3(0.42, 0.18, 0.9) * traces(p, 3.4, t * 0.5, 0.9) * 0.85;
  c += vec3(0.04, 0.07, 0.12) * fbm(uv * 3.0 + t * 0.04);
  float blocks = step(0.62, hash21(floor(p * 9.0))) * (0.25 + 0.3 * fbm(floor(p * 9.0) * 0.7 + t * 0.1));
  c += vec3(0.1, 0.22, 0.4) * blocks;
  return c;
}

/* 02 — TRANSISTOR : layer stack, gate bar, carrier injection */
vec3 modeTransistor(vec2 uv, float t, float energy){
  vec3 c = vec3(0.008, 0.011, 0.015);
  float l1 = 1.0 - smoothstep(0.0, 0.014, abs(uv.y + 0.4));
  float l2 = 1.0 - smoothstep(0.0, 0.009, abs(uv.y + 0.16));
  float l3 = 1.0 - smoothstep(0.0, 0.009, abs(uv.y - 0.52));
  c += vec3(0.08, 0.13, 0.19) * l1 * 0.8 + vec3(0.3, 0.16, 0.44) * l2 * 0.7 + vec3(0.5, 0.34, 0.14) * l3 * 0.5;
  float gate = smoothstep(0.055, 0.044, abs(uv.x + 0.02 * sin(t * 0.5))) * step(abs(uv.y - 0.3), 0.24);
  c += vec3(0.62, 0.72, 0.9) * gate * 0.45;
  float ch = smoothstep(0.2, 0.0, abs(uv.y - 0.02));
  float dots = smoothstep(0.72, 1.0, vnoise(vec2(uv.x * 46.0 - t * (1.2 + 3.4 * energy), uv.y * 46.0)));
  c += mix(vec3(0.02, 0.08, 0.16), vec3(0.32, 0.9, 1.0), energy) * dots * ch * (0.25 + 1.6 * energy);
  c += vec3(0.16, 0.55, 1.0) * ch * 0.1 * (0.15 + energy);
  float grain = smoothstep(0.9, 1.0, vnoise(uv * 120.0));
  c += vec3(0.25, 0.4, 0.6) * grain * 0.15;
  return c;
}

/* 03 — NEURAL : travelling field lines + node lattice */
vec3 modeNeural(vec2 uv, float t){
  vec3 c = vec3(0.006, 0.008, 0.016);
  float acc = 0.0; vec3 tint = vec3(0.0);
  for (int i = 0; i < 5; i++){
    float fi = float(i);
    float y = uv.y + 0.32 * sin(uv.x * (1.5 + fi * 0.45) + t * (0.45 + fi * 0.2) + fi * 1.7);
    float line = 0.014 / (abs(y) + 0.014);
    float pulse = 0.5 + 0.5 * sin(uv.x * 6.0 - t * (1.5 + fi * 0.28) + fi * 2.1);
    acc += line * pulse;
    tint += mix(vec3(0.2, 0.5, 1.0), vec3(0.75, 0.22, 1.0), fi / 4.0) * line * pulse;
  }
  c += tint * 0.42 + vec3(0.08, 0.16, 0.34) * acc * 0.12;
  vec2 g = uv * 3.4; vec2 id = floor(g); vec2 f = fract(g) - 0.5;
  float h = hash21(id);
  float n = 0.022 / (length(f) + 0.022);
  c += mix(vec3(0.2, 0.6, 1.0), vec3(0.85, 0.3, 1.0), h) * n * step(0.58, h) * 0.55;
  return c;
}

/* 04 — MEMORY : stacked banks with burst traffic */
vec3 modeMemory(vec2 uv, float t){
  vec3 c = vec3(0.007, 0.009, 0.013);
  float rows = 15.0;
  float ri = floor(uv.y * rows);
  float f = fract(uv.y * rows);
  float band = 1.0 - smoothstep(0.24, 0.5, abs(f - 0.5));
  float glow = 0.3 + 0.7 * hash21(vec2(ri, floor(t * 0.7)));
  float streak = 0.0;
  for (int i = 0; i < 3; i++){
    float fi = float(i);
    float x = fract(uv.x - t * (0.1 + 0.08 * fi) + hash21(vec2(ri, fi * 2.0)));
    streak += smoothstep(0.02, 0.0, abs(x - 0.5));
  }
  streak /= 3.0;
  vec3 tint = mix(vec3(0.12, 0.55, 1.0), vec3(0.85, 0.5, 0.15), hash21(vec2(ri, 3.3)));
  c += tint * band * streak * glow * 1.35;
  c += tint * band * 0.045;
  float depth = smoothstep(1.2, 0.2, length(uv * vec2(0.6, 1.0)));
  c *= mix(0.35, 1.0, depth);
  return c;
}

/* 05 — VLSI : abstract intent densifying into physical layout */
vec3 modeVlsi(vec2 uv, float t){
  vec3 c = vec3(0.006, 0.008, 0.012);
  vec2 g = uv * 8.0; vec2 id = floor(g); vec2 f = fract(g) - 0.5;
  float h = hash21(id);
  float node = 0.055 / (length(f) + 0.035) * step(0.55, h);
  float link = traces(uv, 5.0, t * 0.35, 0.88);
  float dense = traces(uv, 24.0, t * 0.5, 0.55) * 0.9 + traces(uv, 48.0, t * 0.7, 0.8) * 0.45;
  float m = clamp(uZoom, 0.0, 1.0);
  c += vec3(0.25, 0.75, 1.0) * node * (1.0 - m) * 0.8;
  c += vec3(0.3, 0.6, 1.0) * link * (1.0 - m) * 0.7;
  c += vec3(0.1, 0.55, 0.95) * dense * m;
  c += vec3(0.5, 0.2, 0.95) * dense * m * 0.35;
  float crit = (1.0 - smoothstep(0.0, 0.006, abs(uv.y - 0.12 + 0.05 * sin(uv.x * 3.0)))) * smoothstep(0.7, 1.0, m);
  c += vec3(0.95, 0.2, 0.2) * crit * (0.5 + 0.5 * sin(t * 3.0));
  return c;
}

/* 06 — ACCELERATOR : tile array under load, thermal ramp */
vec3 modeLab(vec2 uv, float t, float energy){
  vec3 c = vec3(0.007, 0.008, 0.011);
  vec2 g = uv * 9.0; vec2 id = floor(g); vec2 f = fract(g) - 0.5;
  float h = hash21(id);
  float temp = clamp(0.35 + 0.65 * sin(t * 0.5 + h * 6.2831) * 0.5 + 0.35, 0.0, 1.0) * (0.35 + energy);
  float cell = 1.0 - smoothstep(0.34, 0.46, length(f));
  vec3 hot = mix(vec3(0.1, 0.5, 0.95), vec3(1.0, 0.42, 0.1), clamp(temp - 0.35, 0.0, 1.0));
  c += hot * cell * temp * 0.55;
  c += vec3(0.6, 0.35, 0.1) * traces(uv, 20.0, t, 0.85) * 0.35;
  return c;
}

void main(){
  vec2 uv = (vUv - 0.5) * 2.0;
  uv.x *= uAspect.x;
  float m = clamp(uMode, 0.0, 6.0);
  vec3 c;
  if (m < 0.5)      c = modeWafer(uv, uTime);
  else if (m < 1.5) c = modeDescent(uv, uTime);
  else if (m < 2.5) c = modeTransistor(uv, uTime, uEnergy);
  else if (m < 3.5) c = modeNeural(uv, uTime);
  else if (m < 4.5) c = modeMemory(uv, uTime);
  else if (m < 5.5) c = modeVlsi(uv, uTime);
  else              c = modeLab(uv, uTime, uEnergy);

  float vig = smoothstep(2.1, 0.3, length(uv));
  c *= mix(0.15, 1.0, vig);
  c *= mix(1.0, 0.55, uStatic);
  c *= 0.9 + uFocus * 0.5;
  gl_FragColor = vec4(c * uOpacity, uOpacity);
}
`;

const BACKDROP_VERT = /* glsl */ `
varying vec2 vUv;
void main(){
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

export interface BackdropUniforms {
  uTime: { value: number };
  uOpacity: { value: number };
  uMode: { value: number };
  uZoom: { value: number };
  uEnergy: { value: number };
  uStatic: { value: number };
  uFocus: { value: number };
  uAspect: { value: THREE.Vector2 };
}

export function createBackdropMaterial(): THREE.ShaderMaterial {
  const uniforms: BackdropUniforms = {
    uTime: { value: 0 },
    uOpacity: { value: 0 },
    uMode: { value: 0 },
    uZoom: { value: 0 },
    uEnergy: { value: 0.4 },
    uStatic: { value: 0 },
    uFocus: { value: 0 },
    uAspect: { value: new THREE.Vector2(1.7, 1) },
  };
  const mat = new THREE.ShaderMaterial({
    uniforms: uniforms as unknown as Record<string, THREE.IUniform>,
    vertexShader: BACKDROP_VERT,
    fragmentShader: BACKDROP_FRAG,
    transparent: true,
    depthWrite: false,
    depthTest: false,
    blending: THREE.AdditiveBlending,
    toneMapped: false,
  });
  return mat;
}

/* ------------------------------------------------------------------ *
 * INSTANCED CELLS — birth/scale animation + pulse, GPU driven
 * ------------------------------------------------------------------ */

const CELL_VERT = /* glsl */ `
attribute vec3 aTint;
attribute vec3 aAnim;   // x = birth stage, y = death stage, z = pulse rate
uniform float uTime, uProgress, uOpacity, uSpeed;
varying vec3 vTint;
varying float vAlpha;
varying vec3 vN;
varying vec3 vV;
void main(){
  vec3 pos = position;
  #ifdef USE_INSTANCING
    mat4 im = instanceMatrix;
  #else
    mat4 im = mat4(1.0);
  #endif
  float local = clamp((uProgress - aAnim.x) * uSpeed, 0.0, 1.0);
  float gone = 1.0 - clamp((uProgress - aAnim.y) * uSpeed * 0.8, 0.0, 1.0);
  float pop = local * local * (3.0 - 2.0 * local) * gone;
  pos *= pop;
  float pulse = 0.72 + 0.28 * sin(uTime * aAnim.z + aAnim.y * 6.2831);
  vTint = aTint;
  vAlpha = uOpacity * pop * pulse;
  vec4 mv = modelViewMatrix * im * vec4(pos, 1.0);
  vN = normalize(normalMatrix * mat3(im) * normal);
  vV = normalize(-mv.xyz);
  gl_Position = projectionMatrix * mv;
}
`;

const CELL_FRAG = /* glsl */ `
varying vec3 vTint;
varying float vAlpha;
varying vec3 vN;
varying vec3 vV;
void main(){
  float fres = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 2.0);
  float top = 0.55 + 0.45 * max(dot(normalize(vN), normalize(vec3(0.3, 0.9, 0.4))), 0.0);
  vec3 c = vTint * (0.22 * top + 1.15 * fres) + vTint * vAlpha * 0.75;
  gl_FragColor = vec4(c, vAlpha);
}
`;

export function createCellMaterial(opts: { progress?: number; speed?: number } = {}) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uProgress: { value: opts.progress ?? 99 },
      uOpacity: { value: 1 },
      uSpeed: { value: opts.speed ?? 3 },
    },
    vertexShader: CELL_VERT,
    fragmentShader: CELL_FRAG,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    toneMapped: false,
  });
}

/* ------------------------------------------------------------------ *
 * FLOW — instanced packets travelling start -> end
 * ------------------------------------------------------------------ */

const FLOW_VERT = /* glsl */ `
attribute vec3 aStart;
attribute vec3 aEnd;
attribute vec3 aTint;
attribute vec3 aMeta;   // x = offset, y = speed, z = size
uniform float uTime, uOpacity, uDensity;
varying float vAlpha;
varying vec3 vTint;
varying float vT;
void main(){
  float speed = max(aMeta.y, 0.001);
  float t = fract(aMeta.x + uTime * speed * uDensity);
  float ease = t * t * (3.0 - 2.0 * t);
  vec3 p = mix(aStart, aEnd, ease);
  // slight arc so packets feel like they travel over the structure
  p += vec3(0.0, 1.0, 0.0) * sin(ease * 3.14159) * aMeta.z * 0.12;
  vec3 pos = position * aMeta.z * (0.6 + 0.6 * sin(ease * 3.14159));
  vT = ease;
  vTint = aTint;
  vAlpha = uOpacity * (0.25 + 0.75 * sin(ease * 3.14159));
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p + pos, 1.0);
}
`;

const FLOW_FRAG = /* glsl */ `
varying float vAlpha;
varying vec3 vTint;
varying float vT;
void main(){
  vec3 c = vTint * (0.55 + 1.5 * vAlpha);
  gl_FragColor = vec4(c, vAlpha);
}
`;

export function createFlowMaterial(density = 1) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uOpacity: { value: 1 },
      uDensity: { value: density },
    },
    vertexShader: FLOW_VERT,
    fragmentShader: FLOW_FRAG,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    toneMapped: false,
  });
}

/* ------------------------------------------------------------------ *
 * DUST — atmospheric particle field for the descent shafts
 * ------------------------------------------------------------------ */

const DUST_VERT = /* glsl */ `
attribute float aSeed;
attribute float aSize;
uniform float uTime, uOpacity, uStatic;
varying float vA;
void main(){
  vec3 p = position;
  p.y += mod(uTime * (2.0 + aSeed * 4.0) * (1.0 - uStatic * 0.85) + aSeed * 400.0, 260.0);
  p.x += sin(uTime * 0.3 + aSeed * 20.0) * 0.7;
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_PointSize = aSize * (240.0 / max(-mv.z, 0.001));
  vA = uOpacity * (0.25 + 0.5 * fract(aSeed * 7.3));
  gl_Position = projectionMatrix * mv;
}
`;

const DUST_FRAG = /* glsl */ `
varying float vA;
void main(){
  vec2 d = gl_PointCoord - 0.5;
  float a = smoothstep(0.5, 0.0, length(d));
  gl_FragColor = vec4(vec3(0.45, 0.72, 1.0) * a, a * vA);
}
`;

export function createDustMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 }, uOpacity: { value: 1 }, uStatic: { value: 0 } },
    vertexShader: DUST_VERT,
    fragmentShader: DUST_FRAG,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    toneMapped: false,
  });
}

/* ------------------------------------------------------------------ *
 * IMAGE-BASED LIGHTING — local, no network fetches
 * ------------------------------------------------------------------ */

let envTexture: THREE.Texture | null = null;

export function getEnvironment(renderer: THREE.WebGLRenderer): THREE.Texture {
  if (envTexture) return envTexture;
  const pmrem = new THREE.PMREMGenerator(renderer);
  const scene = new RoomEnvironment();
  envTexture = pmrem.fromScene(scene, 0.04).texture;
  pmrem.dispose();
  return envTexture;
}

export function disposeEnvironment() {
  envTexture?.dispose();
  envTexture = null;
}

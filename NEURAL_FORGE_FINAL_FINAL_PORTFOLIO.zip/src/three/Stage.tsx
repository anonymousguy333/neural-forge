import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { COLORS, QUALITY_PROFILE } from "@/lib/constants";
import { motion, useUI } from "@/state/store";
import { Backdrop, CameraRig, DescentShaft, Lighting } from "@/three/CameraRig";
import { createBackdropMaterial, disposeEnvironment, getEnvironment } from "@/three/materials";
import { Reveal } from "@/three/kit";
import { IgnitionScene } from "@/three/scenes/Ignition";
import { ChipScene } from "@/three/scenes/Chip";
import { TransistorScene } from "@/three/scenes/Transistor";
import { NeuralScene } from "@/three/scenes/Neural";
import { MemoryScene } from "@/three/scenes/Memory";
import { VlsiScene } from "@/three/scenes/Vlsi";
import { LabScene } from "@/three/scenes/Lab";

/* ------------------------------------------------------------------
 * Scene windowing: only chapters near the camera are mounted at all.
 * ------------------------------------------------------------------ */
function SceneWindow({ index, children }: { index: number; children: ReactNode }) {
  const [near, setNear] = useState(index === 0);
  const prev = useRef(near);
  useFrame(() => {
    const n = Math.abs(motion.camT - index) < 1.45;
    if (n !== prev.current) {
      prev.current = n;
      setNear(n);
    }
  });
  if (!near) return null;
  return <Reveal index={index}>{children}</Reveal>;
}

function SceneContent({ backdrop }: { backdrop: THREE.ShaderMaterial }) {
  const quality = useUI((s) => s.quality);
  const profile = QUALITY_PROFILE[quality];

  useEffect(() => {
    const onVisibility = () => {
      document.body.style.setProperty("--nf-paused", document.hidden ? "1" : "0");
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, []);

  return (
    <>
      <CameraRig backdrop={backdrop} />
      <Backdrop material={backdrop} />
      <Lighting shadows={profile.shadows} />
      <DescentShaft dust={profile.dust} />
      <SceneWindow index={0}>
        <group position={[0, 0, 0]}>
          <IgnitionScene slot={0} dies={profile.dies} dust={profile.dust} />
        </group>
      </SceneWindow>
      <SceneWindow index={1}>
        <group position={[0, -34, 0]}>
          <ChipScene cells={profile.cells} />
        </group>
      </SceneWindow>
      <SceneWindow index={2}>
        <group position={[0, -68, 0]}>
          <TransistorScene />
        </group>
      </SceneWindow>
      <SceneWindow index={3}>
        <group position={[0, -104, 0]}>
          <NeuralScene nodes={profile.nodes} pulses={profile.pulses} />
        </group>
      </SceneWindow>
      <SceneWindow index={4}>
        <group position={[0, -140, 0]}>
          <MemoryScene pulses={profile.pulses} />
        </group>
      </SceneWindow>
      <SceneWindow index={5}>
        <group position={[0, -178, 0]}>
          <VlsiScene cells={profile.cells} />
        </group>
      </SceneWindow>
      <SceneWindow index={6}>
        <group position={[0, -214, 0]}>
          <LabScene />
        </group>
      </SceneWindow>
      <SceneWindow index={7}>
        <group position={[0, -248, 0]}>
          <IgnitionScene slot={7} dies={Math.round(profile.dies * 0.5)} dust={Math.round(profile.dust * 0.5)} far />
        </group>
      </SceneWindow>
    </>
  );
}

export function Stage() {
  const quality = useUI((s) => s.quality);
  const setReady = useUI((s) => s.setReady);
  const webgl = useUI((s) => s.webgl);
  const profile = QUALITY_PROFILE[quality];
  const backdrop = useMemo(() => createBackdropMaterial(), []);
  const drag = useRef<{ x: number; y: number } | null>(null);

  useEffect(
    () => () => {
      backdrop.dispose();
      disposeEnvironment();
    },
    [backdrop]
  );

  const onPointerDown = (e: React.PointerEvent) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    motion.dragging = true;
    drag.current = { x: e.clientX, y: e.clientY };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!motion.dragging || !drag.current) return;
    const dx = e.clientX - drag.current.x;
    const dy = e.clientY - drag.current.y;
    drag.current = { x: e.clientX, y: e.clientY };
    motion.azTarget -= dx * 0.005;
    motion.polTarget = Math.max(-0.7, Math.min(0.7, motion.polTarget + dy * 0.004));
  };
  const endDrag = () => {
    motion.dragging = false;
    drag.current = null;
  };

  if (!webgl) {
    return (
      <div className="fixed inset-0 z-0" aria-hidden>
        <div
          className="absolute inset-0 opacity-60"
          style={{
            background:
              "radial-gradient(ellipse at 50% 30%, rgba(56,189,248,0.16), transparent 60%), radial-gradient(ellipse at 70% 80%, rgba(139,92,246,0.14), transparent 60%)",
          }}
        />
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-0"
      style={{ touchAction: "pan-y" }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={endDrag}
      onPointerLeave={endDrag}
      onDoubleClick={() => {
        motion.azTarget = 0;
        motion.polTarget = 0;
      }}
    >
      <Canvas
        dpr={profile.dpr}
        shadows={profile.shadows}
        gl={{
          antialias: quality !== "low",
          powerPreference: "high-performance",
          alpha: false,
          stencil: false,
        }}
        camera={{ fov: 44, position: [0, 3, 16], near: 0.1, far: 420 }}
        onCreated={({ gl, scene }) => {
          gl.toneMapping = THREE.ACESFilmicToneMapping;
          gl.toneMappingExposure = 1.08;
          scene.environment = getEnvironment(gl);
          scene.environmentIntensity = 0.34;
          scene.fog = new THREE.Fog(new THREE.Color(COLORS.void), 34, 130);
          requestAnimationFrame(() => setReady(true));
        }}
      >
        <color attach="background" args={[COLORS.void]} />
        <SceneContent backdrop={backdrop} />
      </Canvas>
    </div>
  );
}

/** Small helper re-export so scenes can read canvas size without prop drilling */
export function useCanvasAspect() {
  return useThree((s) => s.size.width / s.size.height);
}

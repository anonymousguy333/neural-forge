import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { COLORS, MEMORY_LEVELS } from "@/lib/constants";
import { clamp, damp, rng } from "@/lib/math";
import { motion, useUI } from "@/state/store";
import { memoryModel } from "@/lib/sim";
import { dieTexture, stackTexture } from "@/lib/textures";
import { createFlowField, useRevealOpacity, type FlowPath } from "@/three/kit";

/* ==================================================================
 * CHAPTER 04 — MEMORY WALL
 * Registers → L1 → L2 → HBM → DRAM as real geometry, with traffic that
 * responds to the bandwidth control. The wall itself is a shader plane
 * whose colour reports interface pressure.
 * ================================================================== */

const LEVEL_GEO = [
  { id: "reg", size: [0.46, 0.3, 0.46] as [number, number, number], pos: [2.35, 0.75, 0] as [number, number, number], layers: 1 },
  { id: "l1", size: [0.8, 0.42, 0.8] as [number, number, number], pos: [1.15, 0.85, 0] as [number, number, number], layers: 2 },
  { id: "l2", size: [1.3, 0.62, 1.3] as [number, number, number], pos: [-0.55, 1.0, 0] as [number, number, number], layers: 3 },
  { id: "hbm", size: [1.05, 1.15, 1.05] as [number, number, number], pos: [-2.95, 1.25, 0] as [number, number, number], layers: 6 },
  { id: "dram", size: [1.5, 1.7, 1.5] as [number, number, number], pos: [-5.6, 1.5, 0] as [number, number, number], layers: 8 },
];

export function MemoryScene({ pulses }: { pulses: number }) {
  const index = 4;
  const bandwidth = useUI((s) => s.bandwidth);
  const model = memoryModel(bandwidth);

  const dieTex = useMemo(() => dieTexture(768, 17), []);
  const hbmTex = useMemo(() => stackTexture(512, 8, "217,70,239"), []);
  const dramTex = useMemo(() => stackTexture(512, 10, "245,158,11"), []);

  const mats = useMemo(() => {
    const mk = (o: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial({ transparent: true, ...o });
    return {
      die: mk({
        map: dieTex,
        emissiveMap: dieTex,
        color: "#1b2028",
        emissive: new THREE.Color(COLORS.sig),
        emissiveIntensity: 0.7,
        metalness: 0.72,
        roughness: 0.26,
      }),
      sram: mk({
        color: "#161d26",
        emissive: new THREE.Color(COLORS.emerald),
        emissiveIntensity: 0.4,
        metalness: 0.6,
        roughness: 0.35,
      }),
      mid: mk({
        color: "#1a1830",
        emissive: new THREE.Color(COLORS.violet),
        emissiveIntensity: 0.4,
        metalness: 0.6,
        roughness: 0.35,
      }),
      hbm: mk({
        map: hbmTex,
        emissiveMap: hbmTex,
        color: "#221a2e",
        emissive: new THREE.Color(COLORS.magenta),
        emissiveIntensity: 0.55,
        metalness: 0.6,
        roughness: 0.4,
      }),
      dram: mk({
        map: dramTex,
        emissiveMap: dramTex,
        color: "#2a2016",
        emissive: new THREE.Color(COLORS.amber),
        emissiveIntensity: 0.5,
        metalness: 0.55,
        roughness: 0.45,
      }),
      queue: mk({ color: "#26303c", emissive: new THREE.Color(COLORS.red), emissiveIntensity: 0.4, metalness: 0.5, roughness: 0.5 }),
    };
  }, [dieTex, hbmTex, dramTex]);

  useRevealOpacity(index, Object.values(mats));

  useEffect(
    () => () => {
      Object.values(mats).forEach((m) => m.dispose());
      [dieTex, hbmTex, dramTex].forEach((t) => t.dispose());
    },
    [mats, dieTex, hbmTex, dramTex]
  );

  /* traffic lanes: memory level -> compute die */
  const flows = useMemo(() => {
    const die: [number, number, number] = [4.2, 0.9, 0];
    const rand = rng(4321);
    return LEVEL_GEO.map((lvl, li) => {
      const info = MEMORY_LEVELS[li];
      const paths: FlowPath[] = [];
      const count = Math.max(6, Math.round((pulses / LEVEL_GEO.length) * (0.6 + info.bw)));
      for (let i = 0; i < count; i++) {
        const jitter = () => (rand() - 0.5) * 0.7;
        const start: [number, number, number] = [lvl.pos[0] + lvl.size[0] / 2, lvl.pos[1] + jitter() * 0.4, jitter()];
        paths.push({
          start,
          end: [die[0] - 0.9, die[1] + jitter() * 0.3, jitter()],
          tint: new THREE.Color(info.color),
          speed: 0.35 + rand() * 0.5 + info.bw * 0.4,
          size: 0.5 + rand() * 0.8,
        });
      }
      return { id: lvl.id, geometry: createFlowField(paths), color: info.color, weight: info.bw };
    });
  }, [pulses]);

  const flowMats = useMemo(
    () =>
      flows.map(
        () =>
          new THREE.ShaderMaterial({
            uniforms: { uTime: { value: 0 }, uOpacity: { value: 0 }, uDensity: { value: 0.5 } },
            vertexShader: /* glsl */ `
              attribute vec3 aStart; attribute vec3 aEnd; attribute vec3 aTint; attribute vec3 aMeta;
              uniform float uTime, uOpacity, uDensity;
              varying float vA; varying vec3 vTint;
              void main(){
                float sp = max(aMeta.y, 0.001);
                float tt = fract(aMeta.x + uTime * sp * uDensity);
                float e = tt * tt * (3.0 - 2.0 * tt);
                vec3 p = mix(aStart, aEnd, e);
                vec3 pos = position * aMeta.z;
                vTint = aTint; vA = uOpacity * sin(e * 3.14159);
                gl_Position = projectionMatrix * modelViewMatrix * vec4(p + pos, 1.0);
              }`,
            fragmentShader: /* glsl */ `
              varying float vA; varying vec3 vTint;
              void main(){ gl_FragColor = vec4(vTint * (0.55 + 1.5 * vA), vA); }`,
            transparent: true,
            depthWrite: false,
            blending: THREE.AdditiveBlending,
            toneMapped: false,
          })
      ),
    [flows]
  );

  useEffect(
    () => () => {
      flows.forEach((f) => f.geometry.dispose());
      flowMats.forEach((m) => m.dispose());
    },
    [flows, flowMats]
  );

  const dieMat = mats.die;
  const queue = useRef<THREE.InstancedMesh>(null);
  const QUEUE_MAX = 18;

  useEffect(() => {
    const m = queue.current;
    if (!m) return;
    m.frustumCulled = false;
    m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  }, []);

  useFrame((s, dt) => {
    const reveal = motion.reveal[index] ?? 0;
    const t = s.clock.elapsedTime;

    flows.forEach((f, i) => {
      const mat = flowMats[i];
      mat.uniforms.uTime.value = t;
      const target = reveal * (0.35 + model.utilisation * 0.65) * (0.5 + f.weight);
      mat.uniforms.uOpacity.value = damp(mat.uniforms.uOpacity.value, target, 4, dt);
      mat.uniforms.uDensity.value = damp(mat.uniforms.uDensity.value, 0.25 + bandwidth * 0.75, 4, dt);
    });

    // compute die utilisation + stall flash
    dieMat.emissiveIntensity = damp(
      dieMat.emissiveIntensity,
      0.25 + model.utilisation * 1.5 + (model.stall > 0.5 ? Math.sin(t * 9) * 0.12 * model.stall : 0),
      5,
      dt
    );
    mats.sram.emissiveIntensity = 0.3 + model.utilisation * 0.6;
    mats.hbm.emissiveIntensity = 0.3 + (1 - model.utilisation) * 0.7;
    mats.dram.emissiveIntensity = 0.25 + model.congestion * 0.9;

    // congestion queue at the memory interface
    const m = queue.current;
    if (m) {
      const count = Math.round(model.congestion * QUEUE_MAX);
      const mat4 = new THREE.Matrix4();
      const v = new THREE.Vector3();
      const sc = new THREE.Vector3(0.12, 0.1, 0.3);
      const q = new THREE.Quaternion();
      for (let i = 0; i < QUEUE_MAX; i++) {
        const on = i < count;
        v.set(3.15 - Math.floor(i / 5) * 0.16, 0.45 + (i % 5) * 0.13, -0.55 + Math.floor(i / 5) * 0.35);
        sc.setScalar(on ? 1 : 0.0001);
        mat4.compose(v, q, sc);
        m.setMatrixAt(i, mat4);
      }
      m.instanceMatrix.needsUpdate = true;
      mats.queue.emissiveIntensity = 0.2 + model.congestion * 1.6;
    }
  });

  return (
    <group>
      {/* compute die */}
      <mesh material={mats.die} position={[4.2, 0.9, 0]} castShadow>
        <boxGeometry args={[2.1, 0.22, 2.1]} />
      </mesh>
      <mesh material={mats.die} position={[4.2, 0.66, 0]}>
        <boxGeometry args={[2.3, 0.22, 2.3]} />
      </mesh>

      {/* memory levels */}
      {LEVEL_GEO.map((lvl, i) => (
        <group key={lvl.id} position={lvl.pos}>
          <mesh material={(mats as Record<string, THREE.MeshStandardMaterial>)[lvl.id === "l1" || lvl.id === "reg" ? "sram" : lvl.id === "l2" ? "mid" : lvl.id]} castShadow>
            <boxGeometry args={lvl.size} />
          </mesh>
          <mesh position={[0, -lvl.size[1] / 2 - 0.06, 0]}>
            <boxGeometry args={[lvl.size[0] * 1.12, 0.06, lvl.size[2] * 1.12]} />
            <meshStandardMaterial color="#0f1419" metalness={0.8} roughness={0.3} transparent />
          </mesh>
          <mesh position={[0, lvl.size[1] / 2 + 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[lvl.size[0] * 0.92, lvl.size[2] * 0.92]} />
            <meshBasicMaterial color={MEMORY_LEVELS[i].color} transparent opacity={0.12} blending={THREE.AdditiveBlending} toneMapped={false} />
          </mesh>
        </group>
      ))}

      {/* waiting packets at the interface */}
      <instancedMesh ref={queue} args={[undefined, mats.queue, QUEUE_MAX]}>
        <boxGeometry args={[1, 1, 1]} />
      </instancedMesh>

      {/* lanes */}
      {flows.map((f, i) => (
        <mesh key={f.id} geometry={f.geometry} material={flowMats[i]} frustumCulled={false} />
      ))}

      {/* the wall itself */}
      <MemoryWall pressure={model.memoryPressure} index={index} />
    </group>
  );
}

/** The interface boundary: a shader grid whose colour reports pressure. */
function MemoryWall({ pressure, index }: { pressure: number; index: number }) {
  const mat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: {
          uTime: { value: 0 },
          uOpacity: { value: 0 },
          uPressure: { value: 1 },
        },
        vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
        fragmentShader: /* glsl */ `
          uniform float uTime, uOpacity, uPressure;
          varying vec2 vUv;
          float hash21(vec2 p){ p = fract(p*vec2(123.34,456.21)); p += dot(p,p+45.32); return fract(p.x*p.y); }
          void main(){
            vec2 g = vUv * vec2(26.0, 16.0);
            vec2 f = abs(fract(g) - 0.5);
            float line = smoothstep(0.48, 0.5, max(f.x, f.y));
            vec3 cool = vec3(0.12, 0.45, 0.75);
            vec3 hot  = vec3(0.95, 0.28, 0.12);
            float heat = clamp((uPressure - 0.9) / 0.9, 0.0, 1.0);
            vec3 col = mix(cool, hot, heat);
            float pulse = 0.55 + 0.45 * sin(vUv.y * 26.0 - uTime * (2.0 + uPressure * 5.0));
            float a = uOpacity * (0.05 + line * (0.35 + pulse * 0.4));
            gl_FragColor = vec4(col * (0.5 + pulse), a);
          }`,
        transparent: true,
        depthWrite: false,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        toneMapped: false,
      }),
    []
  );

  useEffect(() => () => mat.dispose(), [mat]);

  useFrame((s, dt) => {
    mat.uniforms.uTime.value = s.clock.elapsedTime;
    mat.uniforms.uPressure.value = damp(mat.uniforms.uPressure.value, clamp(pressure, 0.2, 2.4), 4, dt);
    mat.uniforms.uOpacity.value = damp(mat.uniforms.uOpacity.value, motion.reveal[index] ?? 0, 5, dt);
  });

  return (
    <mesh material={mat} position={[0.35, 1.1, 0]} rotation={[0, Math.PI / 2, 0]}>
      <planeGeometry args={[5.2, 3.2]} />
    </mesh>
  );
}

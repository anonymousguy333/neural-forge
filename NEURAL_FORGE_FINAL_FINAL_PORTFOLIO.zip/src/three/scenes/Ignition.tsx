import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { COLORS } from "@/lib/constants";
import { damp, rng } from "@/lib/math";
import { motion } from "@/state/store";
import { waferTexture, layoutTexture } from "@/lib/textures";
import { createFlowField, useRevealOpacity, type FlowPath } from "@/three/kit";

/* ==================================================================
 * CHAPTER 00 / 07 — IGNITION
 * A real wafer, real dies separating from it, and signal pulses leaving
 * the surface. The pointer lifts dies locally: the surface is touchable.
 * ================================================================== */

export function IgnitionScene({
  slot,
  dies,
  dust: _dust,
  far = false,
}: {
  slot: number;
  dies: number;
  dust?: number;
  far?: boolean;
}) {
  const wafer = useRef<THREE.Mesh>(null);
  const dieMesh = useRef<THREE.InstancedMesh>(null);
  const lift = useRef<number[]>([]);
  const pointerCell = useRef({ x: 99, z: 99, active: 0 });
  const spin = useRef(0.06);

  const waferTex = useMemo(() => waferTexture(1024, 22), []);
  const boardTex = useMemo(() => layoutTexture(1024, 1.1, 5), []);

  const waferMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        map: waferTex,
        emissiveMap: waferTex,
        emissive: new THREE.Color(COLORS.sig),
        emissiveIntensity: 0.42,
        metalness: 0.88,
        roughness: 0.26,
        transparent: true,
        envMapIntensity: 1.2,
      }),
    [waferTex]
  );
  const dieMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#1b2028",
        emissive: new THREE.Color(COLORS.sig),
        emissiveIntensity: 0.5,
        metalness: 0.85,
        roughness: 0.32,
        transparent: true,
      }),
    []
  );
  const boardMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        map: boardTex,
        emissiveMap: boardTex,
        emissive: new THREE.Color(COLORS.sig),
        emissiveIntensity: 0.3,
        metalness: 0.7,
        roughness: 0.5,
        transparent: true,
      }),
    [boardTex]
  );
  const rimMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#8b929c",
        metalness: 1,
        roughness: 0.18,
        transparent: true,
      }),
    []
  );

  useRevealOpacity(slot, [waferMat, dieMat, boardMat, rimMat]);

  /* ---- die lattice above the wafer ---- */
  const grid = useMemo(() => {
    const rand = rng(2024);
    const spacing = 0.62;
    const n = Math.max(4, Math.round(Math.sqrt(dies)));
    const items: { x: number; z: number; seed: number; alive: boolean }[] = [];
    const half = ((n - 1) * spacing) / 2;
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        const x = i * spacing - half;
        const z = j * spacing - half;
        const r = Math.hypot(x, z);
        if (r > 5.0) continue;
        items.push({ x, z, seed: rand(), alive: rand() > 0.18 });
      }
    }
    lift.current = new Array(items.length).fill(0);
    return { items, spacing };
  }, [dies]);

  useEffect(() => {
    const mesh = dieMesh.current;
    if (!mesh) return;
    mesh.frustumCulled = false;
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  }, [grid]);

  /* ---- signal pulses radiating from the wafer ---- */
  const flow = useMemo(() => {
    const paths: FlowPath[] = [];
    const count = Math.min(190, Math.max(50, Math.round(dies * 0.7)));
    const rand = rng(99);
    const cyan = new THREE.Color(COLORS.sig);
    const violet = new THREE.Color(COLORS.violet);
    for (let i = 0; i < count; i++) {
      const a = rand() * Math.PI * 2;
      const r0 = 1 + rand() * 3.4;
      const h = -1.4 + rand() * 2.6;
      const p: FlowPath = {
        start: [Math.cos(a) * r0, h, Math.sin(a) * r0],
        end: [Math.cos(a) * (r0 + 5.5), h + 1.2, Math.sin(a) * (r0 + 5.5)],
        tint: rand() > 0.78 ? violet : cyan,
        speed: 0.14 + rand() * 0.24,
        size: 0.5 + rand() * 1.3,
      };
      paths.push(p);
    }
    return { geometry: createFlowField(paths), count: paths.length };
  }, [dies]);
  useEffect(() => () => flow.geometry.dispose(), [flow]);

  useFrame((state, dt) => {
    const t = state.clock.elapsedTime;
    const reveal = motion.reveal[slot] ?? 0;
    if (wafer.current) {
      spin.current = damp(spin.current, pointerCell.current.active > 0 ? 0.16 : 0.06, 2, dt);
      wafer.current.rotation.z += spin.current * dt * (far ? 0.4 : 1) * (reveal > 0.1 ? 1 : 0);
    }

    // dies lift in travelling waves + respond to the pointer
    const mesh = dieMesh.current;
    if (mesh) {
      const m = new THREE.Matrix4();
      const q = new THREE.Quaternion();
      const e = new THREE.Euler(0, 0, 0);
      const pos = new THREE.Vector3();
      const scl = new THREE.Vector3(0.5, 0.07, 0.5);
      for (let i = 0; i < grid.items.length; i++) {
        const it = grid.items[i];
        const dist = Math.hypot(it.x, it.z);
        const wave = Math.max(0, Math.sin(t * 0.75 - dist * 0.55 + it.seed * 2.2));
        const target =
          it.alive === false
            ? 0.02
            : 0.08 + wave * 0.55 * (0.5 + motion.reveal[slot] * 0.5) * (far ? 0.35 : 1);
        const dp = Math.hypot(it.x - pointerCell.current.x, it.z - pointerCell.current.z);
        const hover = pointerCell.current.active > 0 ? Math.max(0, 1 - dp / 1.6) : 0;
        const prev = lift.current[i] ?? 0;
        const next = damp(prev, target + hover * 1.5, 5, dt);
        lift.current[i] = next;
        pos.set(it.x, 0.25 + next, it.z);
        e.set(0, it.seed * 0.2, 0);
        q.setFromEuler(e);
        scl.set(0.5, 0.07 + next * 0.05, 0.5);
        m.compose(pos, q, scl);
        mesh.setMatrixAt(i, m);
      }
      mesh.instanceMatrix.needsUpdate = true;
    }
  });

  const onWaferMove = (e: { point: THREE.Vector3; stopPropagation: () => void }) => {
    if (far) return;
    // dies live in the untransformed group frame, so world x/z is the grid frame
    pointerCell.current = { x: e.point.x, z: e.point.z, active: 1 };
    e.stopPropagation();
  };

  return (
    <group>
      {/* wafer */}
      <mesh
        ref={wafer}
        rotation={[-Math.PI / 2, 0, 0]}
        material={waferMat}
        onPointerMove={onWaferMove}
        onPointerOut={() => (pointerCell.current.active = 0)}
        onPointerDown={onWaferMove}
      >
        <cylinderGeometry args={[5.4, 5.4, 0.09, 128]} />
      </mesh>
      {/* rim */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} material={rimMat} position={[0, 0, 0]}>
        <torusGeometry args={[5.4, 0.045, 8, 160]} />
      </mesh>
      {/* dies */}
      <instancedMesh ref={dieMesh} args={[undefined, dieMat, Math.max(1, grid.items.length)]} material={dieMat}>
        <boxGeometry args={[1, 1, 1]} />
      </instancedMesh>
      {/* process deck below */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.9, 0]} material={boardMat}>
        <planeGeometry args={[26, 26]} />
      </mesh>
      <SignalDeck flowGeometry={flow.geometry} slot={slot} />
    </group>
  );
}

/** Radiating signal pulses + guidance rails under the wafer. */
function SignalDeck({ flowGeometry, slot }: { flowGeometry: THREE.BufferGeometry; slot: number }) {
  const mat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: { uTime: { value: 0 }, uOpacity: { value: 0 }, uDensity: { value: 0.35 } },
        vertexShader: /* glsl */ `
          attribute vec3 aStart; attribute vec3 aEnd; attribute vec3 aTint; attribute vec3 aMeta;
          uniform float uTime, uOpacity, uDensity;
          varying float vA; varying vec3 vTint;
          void main(){
            float sp = max(aMeta.y, 0.001);
            float tt = fract(aMeta.x + uTime * sp * uDensity);
            float e = tt * tt * (3.0 - 2.0 * tt);
            vec3 p = mix(aStart, aEnd, e);
            vec3 pos = position * aMeta.z;
            vTint = aTint;
            vA = uOpacity * sin(e * 3.14159);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(p + pos, 1.0);
          }
        `,
        fragmentShader: /* glsl */ `
          varying float vA; varying vec3 vTint;
          void main(){ gl_FragColor = vec4(vTint * (0.5 + 1.6 * vA), vA); }
        `,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        toneMapped: false,
      }),
    []
  );

  useFrame((state) => {
    mat.uniforms.uTime.value = state.clock.elapsedTime;
    mat.uniforms.uOpacity.value = motion.reveal[slot] ?? 0;
  });

  return <mesh geometry={flowGeometry} material={mat} frustumCulled={false} />;
}

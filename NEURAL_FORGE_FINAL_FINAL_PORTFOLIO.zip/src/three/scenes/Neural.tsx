import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { ARCHETYPES, COLORS } from "@/lib/constants";
import { clamp, damp, rng, smoothstep } from "@/lib/math";
import { motion } from "@/state/store";
import { MAT_N, matmulValues } from "@/lib/sim";
import { Cells, createCellField, createFlowField, Tag, windowFade, writeTint, type FlowPath } from "@/three/kit";

/* ==================================================================
 * CHAPTER 03 — AI ENGINE
 * Three scroll-windowed sub-scenes:
 *   1. spatial neural network with travelling activations
 *   2. the matrix multiply that network is actually performing
 *   3. CPU / GPU / NPU execution models, compared structurally
 * ================================================================== */

const LAYERS = [4, 7, 10, 7, 4];

export function NeuralScene({ nodes, pulses }: { nodes: number; pulses: number }) {
  return (
    <group>
      <NetworkField nodes={nodes} pulses={pulses} />
      <MatMul />
      <ArchetypeTiles />
    </group>
  );
}

/* ---------------------------- 1. network ---------------------------- */

function NetworkField({ nodes: _nodes, pulses }: { nodes: number; pulses: number }) {
  const group = useRef<THREE.Group>(null);
  const nodePos = useMemo(() => {
    const out: { x: number; y: number; z: number; layer: number; i: number }[] = [];
    const total = LAYERS.length;
    LAYERS.forEach((count, layer) => {
      const x = -4.4 + (layer / (total - 1)) * 8.8;
      const spread = 1.1 + layer * 0.28;
      for (let i = 0; i < count; i++) {
        const y = (i - (count - 1) / 2) * (spread / Math.max(1, count - 1) + 0.42);
        out.push({ x, y: y * 0.9, z: (layer - 2) * 0.7, layer, i });
      }
    });
    return out;
  }, []);

  const field = useMemo(
    () => createCellField({ count: nodePos.length, base: "octa", size: [0.22, 0.22, 0.22], speed: 4 }),
    [nodePos.length]
  );

  const tint = useMemo(() => {
    const c = new THREE.Color();
    return (i: number) => {
      const layer = nodePos[i].layer;
      c.set(layer <= 1 ? COLORS.sig : layer === 2 ? "#22d3ee" : layer === 3 ? COLORS.violet : COLORS.magenta);
      return c;
    };
  }, [nodePos]);

  const lines = useMemo(() => {
    const arr: number[] = [];
    for (let l = 0; l < LAYERS.length - 1; l++) {
      const a = nodePos.filter((n) => n.layer === l);
      const b = nodePos.filter((n) => n.layer === l + 1);
      a.forEach((na) => {
        b.forEach((nb) => {
          if ((na.i * 7 + nb.i * 3) % 3 !== 0) return;
          arr.push(na.x, na.y, na.z, nb.x, nb.y, nb.z);
        });
      });
    }
    return new Float32Array(arr);
  }, [nodePos]);

  const lineObj = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(lines, 3));
    const m = new THREE.LineBasicMaterial({
      color: new THREE.Color(COLORS.sig),
      transparent: true,
      opacity: 0.13,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    });
    return new THREE.LineSegments(g, m);
  }, [lines]);

  const flow = useMemo(() => {
    const rand = rng(1201);
    const paths: FlowPath[] = [];
    for (let l = 0; l < LAYERS.length - 1; l++) {
      const a = nodePos.filter((n) => n.layer === l);
      const b = nodePos.filter((n) => n.layer === l + 1);
      const per = Math.max(2, Math.round(pulses / (LAYERS.length - 1)));
      for (let k = 0; k < per; k++) {
        const na = a[Math.floor(rand() * a.length)];
        const nb = b[Math.floor(rand() * b.length)];
        paths.push({
          start: [na.x, na.y, na.z],
          end: [nb.x, nb.y, nb.z],
          tint: new THREE.Color(rand() > 0.7 ? COLORS.violet : COLORS.sig),
          speed: 0.5 + rand() * 0.9,
          size: 0.55 + rand() * 0.9,
        });
      }
    }
    return createFlowField(paths);
  }, [nodePos, pulses]);

  const flowMat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: { uTime: { value: 0 }, uOpacity: { value: 1 }, uDensity: { value: 0.55 } },
        vertexShader: /* glsl */ `
          attribute vec3 aStart; attribute vec3 aEnd; attribute vec3 aTint; attribute vec3 aMeta;
          uniform float uTime, uOpacity, uDensity;
          varying float vA; varying vec3 vTint;
          void main(){
            float sp = max(aMeta.y, 0.001);
            float tt = fract(aMeta.x + uTime * sp * uDensity);
            float e = tt * tt * (3.0 - 2.0 * tt);
            vec3 p = mix(aStart, aEnd, e);
            vec3 pos = position * aMeta.z * (0.5 + 0.8 * sin(e * 3.14159));
            vTint = aTint; vA = uOpacity * sin(e * 3.14159);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(p + pos, 1.0);
          }`,
        fragmentShader: /* glsl */ `
          varying float vA; varying vec3 vTint;
          void main(){ gl_FragColor = vec4(vTint * (0.6 + 1.6 * vA), vA); }`,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        toneMapped: false,
      }),
    []
  );

  useEffect(
    () => () => {
      field.geometry.dispose();
      field.material.dispose();
      flow.dispose();
      flowMat.dispose();
      lineObj.geometry.dispose();
      (lineObj.material as THREE.Material).dispose();
    },
    [field, flow, flowMat, lineObj]
  );

  const wave = useRef(0);

  useFrame((s, dt) => {
    const p = clamp(motion.camT - 3);
    const fade = windowFade(p, 0.0, 0.52, 0.16);
    const g = group.current;
    if (!g) return;
    g.visible = fade > 0.02 && (motion.reveal[3] ?? 0) > 0.05;
    g.position.y = -0.4 * smoothstep((p - 0.3) / 0.3);
    g.position.z = -2.2 * smoothstep((p - 0.3) / 0.35);
    const m = field.material.uniforms;
    m.uOpacity.value = damp(m.uOpacity.value, fade, 5, dt);
    m.uTime.value = s.clock.elapsedTime;
    flowMat.uniforms.uTime.value = s.clock.elapsedTime;
    flowMat.uniforms.uOpacity.value = fade;
    (lineObj.material as THREE.LineBasicMaterial).opacity = 0.13 * fade;

    // forward-pass wavefront: nodes light up layer by layer
    wave.current = (wave.current + dt * 0.55) % 1.35;
    for (let i = 0; i < nodePos.length; i++) {
      const layer = nodePos[i].layer;
      const d = Math.abs(wave.current * LAYERS.length - layer);
      const boost = Math.max(0, 1 - d * 0.9);
      writeTint(field.geometry.getAttribute("aTint") as THREE.InstancedBufferAttribute, i, tint(i), 0.5 + boost * 1.8);
    }
    (field.geometry.getAttribute("aTint") as THREE.InstancedBufferAttribute).needsUpdate = true;
  });

  return (
    <group ref={group}>
      <Cells
        field={field}
        count={nodePos.length}
        place={(i) => ({ p: [nodePos[i].x, nodePos[i].y, nodePos[i].z], s: [1, 1, 1] })}
      />
      <primitive object={lineObj} />
      <mesh geometry={flow} material={flowMat} frustumCulled={false} />
    </group>
  );
}

/* ---------------------------- 2. matmul ---------------------------- */

function MatMul() {
  const group = useRef<THREE.Group>(null);
  const values = useMemo(() => matmulValues(7), []);
  const norm = (v: number) => clamp(Math.abs(v) / 12, 0.05, 1);

  const cellPos = useMemo(() => {
    const out: { x: number; y: number; z: number; grid: 0 | 1 | 2; r: number; c: number }[] = [];
    const spacing = 0.42;
    const origins: [number, number][] = [
      [-3.2, 0.6],
      [-0.9, 0.6],
      [1.6, 0.6],
    ];
    for (let grid = 0 as 0 | 1 | 2; grid < 3; grid++) {
      const [ox, oy] = origins[grid];
      for (let r = 0; r < MAT_N; r++) {
        for (let c = 0; c < MAT_N; c++) {
          out.push({ x: ox + c * spacing, y: oy - r * spacing, z: grid === 1 ? 0.6 : 0, grid, r, c });
        }
      }
    }
    return out;
  }, []);

  const field = useMemo(
    () => createCellField({ count: cellPos.length, base: "box", size: [0.32, 0.32, 0.06], speed: 6 }),
    [cellPos.length]
  );

  const labels = useMemo(
    () => [
      { p: [-3.75, 1.45, 0] as [number, number, number], t: "A" },
      { p: [-1.45, 1.45, 0] as [number, number, number], t: "B" },
      { p: [1.35, 1.45, 0] as [number, number, number], t: "C = A × B" },
    ],
    []
  );

  useEffect(
    () => () => {
      field.geometry.dispose();
      field.material.dispose();
    },
    [field]
  );

  useFrame((s, dt) => {
    const p = clamp(motion.camT - 3);
    const fade = windowFade(p, 0.28, 0.8, 0.14);
    const g = group.current;
    if (!g) return;
    g.visible = fade > 0.02 && (motion.reveal[3] ?? 0) > 0.05;
    g.position.z = 2.4 * smoothstep((p - 0.28) / 0.3);
    const u = field.material.uniforms;
    u.uOpacity.value = damp(u.uOpacity.value, fade, 5, dt);
    u.uTime.value = s.clock.elapsedTime;

    // k-loop wavefront: the accumulation order of a real matmul
    const k = Math.floor((s.clock.elapsedTime * 1.6) % MAT_N);
    const rowWave = (s.clock.elapsedTime * 0.7) % 1;
    const attr = field.geometry.getAttribute("aTint") as THREE.InstancedBufferAttribute;
    cellPos.forEach((cell, i) => {
      const v =
        cell.grid === 0 ? values.a[cell.r][cell.c] : cell.grid === 1 ? values.b[cell.r][cell.c] : values.c[cell.r][cell.c];
      const base = norm(v) * 0.85;
      const hot = cell.grid === 2 && cell.c === k ? 1.5 : 1;
      const rowFlash = cell.grid === 0 ? 0.6 + rowWave * 1.6 : 1;
      writeTint(attr, i, new THREE.Color(cell.grid === 2 ? COLORS.magenta : COLORS.sig), base * hot * rowFlash + 0.06);
    });
    attr.needsUpdate = true;

  });

  return (
    <group ref={group}>
      <Cells field={field} count={cellPos.length} place={(i) => ({ p: [cellPos[i].x, cellPos[i].y, cellPos[i].z] })} />
      {labels.map((l) => (
        <Tag key={l.t} position={l.p} color="rgba(217,70,239,0.9)">
          {l.t}
        </Tag>
      ))}
    </group>
  );
}

/* ------------------------ 3. CPU / GPU / NPU ------------------------ */

function ArchetypeTiles() {
  const group = useRef<THREE.Group>(null);
  const tiles = useMemo(() => {
    const specs = [
      { id: "cpu", w: 4, h: 3, color: ARCHETYPES[0].color },
      { id: "gpu", w: 18, h: 12, color: ARCHETYPES[1].color },
      { id: "npu", w: 10, h: 10, color: ARCHETYPES[2].color },
    ];
    return specs.map((s, idx) => {
      const count = s.w * s.h;
      const field = createCellField({ count, base: "box", size: [0.17, 0.09, 0.17], speed: 5 });
      const tint = new THREE.Color(s.color);
      const rand = rng(idx * 31 + 5);
      for (let i = 0; i < count; i++) {
        writeTint(field.geometry.getAttribute("aTint") as THREE.InstancedBufferAttribute, i, tint, 0.25 + rand() * 0.5);
        const a = field.anim;
        a[i * 3] = 0;
        a[i * 3 + 1] = rand();
        a[i * 3 + 2] = 1.2 + rand() * (s.id === "gpu" ? 5 : s.id === "npu" ? 3 : 1.1);
      }
      (field.geometry.getAttribute("aTint") as THREE.InstancedBufferAttribute).needsUpdate = true;
      (field.geometry.getAttribute("aAnim") as THREE.InstancedBufferAttribute).needsUpdate = true;
      return { ...s, field, count };
    });
  }, []);

  useEffect(
    () => () => {
      tiles.forEach((t) => {
        t.field.geometry.dispose();
        t.field.material.dispose();
      });
    },
    [tiles]
  );

  useFrame((s, dt) => {
    const p = clamp(motion.camT - 3);
    const fade = windowFade(p, 0.56, 1.3, 0.16);
    const g = group.current;
    if (!g) return;
    g.visible = fade > 0.02 && (motion.reveal[3] ?? 0) > 0.05;
    g.position.y = -3.2 * (1 - smoothstep((p - 0.56) / 0.3));
    tiles.forEach((t, idx) => {
      const u = t.field.material.uniforms;
      u.uOpacity.value = damp(u.uOpacity.value, fade, 5, dt);
      u.uTime.value = s.clock.elapsedTime;
      // wavefront cadence differs by execution model
      if (t.id === "npu") {
        const wave = (s.clock.elapsedTime * 1.1) % (t.w + t.h);
        const attr = t.field.geometry.getAttribute("aAnim") as THREE.InstancedBufferAttribute;
        const arr = attr.array as Float32Array;
        for (let i = 0; i < t.count; i++) {
          const x = i % t.w;
          const y = Math.floor(i / t.w);
          const d = Math.abs(x + y - wave);
          arr[i * 3 + 2] = 1.2 + Math.max(0, 3.2 - d * 0.9);
        }
        attr.needsUpdate = true;
      }
      void idx;
    });
  });

  const tileOrigin: Record<string, [number, number]> = { cpu: [-4.4, 0], gpu: [0, 0], npu: [4.4, 0] };

  return (
    <group ref={group} position={[0, 0, 1.5]}>
      {tiles.map((t) => {
        const [ox] = tileOrigin[t.id];
        return (
          <group key={t.id} position={[ox, -2.6, 0]}>
            <Cells
              field={t.field}
              count={t.count}
              place={(i) => ({
                p: [(i % t.w) - t.w / 2 + 0.5, -Math.floor(i / t.w) * 0.18 + t.h * 0.09, 0],
                s: [1, 1, 1],
              })}
            />
          </group>
        );
      })}
    </group>
  );
}

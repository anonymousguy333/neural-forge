import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { COLORS } from "@/lib/constants";
import { clamp, damp, rng, smoothstep } from "@/lib/math";
import { motion, useUI } from "@/state/store";
import { transistorModel } from "@/lib/sim";
import { Tag, useRevealOpacity, windowFade } from "@/three/kit";

/* ==================================================================
 * CHAPTER 02 — TRANSISTOR
 * A real 3D MOS structure: substrate, n+ source/drain, channel, gate
 * oxide, gate, contacts. Carriers are simulated on the CPU and respond
 * to the gate control. Scrolling pulls in the logic chain.
 * ================================================================== */

const CARRIERS = 150;

export function TransistorScene() {
  const index = 2;
  const gate = useUI((s) => s.gate);
  const device = useRef<THREE.Group>(null);
  const chain = useRef<THREE.Group>(null);
  const channelMat = useRef<THREE.Mesh>(null);
  const carriers = useRef<THREE.InstancedMesh>(null);
  const fieldMat = useRef<THREE.MeshBasicMaterial>(null);
  const state = useRef({ xs: [] as number[], ys: [] as number[], zs: [] as number[] });

  const mats = useMemo(() => {
    const mk = (o: THREE.MeshStandardMaterialParameters & { transparent?: boolean }) =>
      new THREE.MeshStandardMaterial({ transparent: true, ...o });
    return {
      sub: mk({ color: "#2b323b", metalness: 0.35, roughness: 0.62 }),
      nd: mk({ color: "#3a4a5c", metalness: 0.55, roughness: 0.4, emissive: new THREE.Color(COLORS.sig), emissiveIntensity: 0.12 }),
      channel: mk({
        color: "#0d2b3a",
        emissive: new THREE.Color(COLORS.sig),
        emissiveIntensity: 0.1,
        metalness: 0.3,
        roughness: 0.35,
      }),
      oxide: mk({
        color: "#6d5bd0",
        metalness: 0.2,
        roughness: 0.25,
        transparent: true,
        opacity: 0.42,
        emissive: new THREE.Color(COLORS.violet),
        emissiveIntensity: 0.4,
      }),
      gate: mk({ color: "#c3cbd6", metalness: 1, roughness: 0.14, emissive: new THREE.Color("#9ad9ff"), emissiveIntensity: 0.2 }),
      metal: mk({ color: "#c98a5a", metalness: 1, roughness: 0.28 }),
      carrier: new THREE.MeshBasicMaterial({
        color: new THREE.Color("#bff0ff"),
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        toneMapped: false,
      }),
      field: new THREE.MeshBasicMaterial({
        color: new THREE.Color(COLORS.violet),
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        toneMapped: false,
      }),
    };
  }, []);

  useRevealOpacity(index, [mats.sub, mats.nd, mats.channel, mats.gate, mats.metal, mats.carrier]);

  useEffect(
    () => () => {
      Object.values(mats).forEach((m) => m.dispose());
    },
    [mats]
  );

  useEffect(() => {
    const rand = rng(5150);
    state.current.xs = Array.from({ length: CARRIERS }, () => -1.6 + rand() * 3.2);
    state.current.ys = Array.from({ length: CARRIERS }, () => (rand() - 0.5) * 0.09);
    state.current.zs = Array.from({ length: CARRIERS }, () => (rand() - 0.5) * 1.1);
    const mesh = carriers.current;
    if (mesh) mesh.frustumCulled = false;
  }, []);

  const model = transistorModel(gate);

  useFrame((_, dt) => {
    const p = clamp(motion.camT - index);
    const reveal = motion.reveal[index] ?? 0;
    const devFade = windowFade(p, 0.0, 0.52, 0.16);
    const chainFade = windowFade(p, 0.34, 1.0, 0.16);

    if (device.current) {
      device.current.position.z = -1.5 * smoothstep((p - 0.3) / 0.4);
      device.current.position.y = 0.35 * smoothstep((p - 0.3) / 0.4);
      device.current.scale.setScalar(1 - 0.22 * smoothstep((p - 0.3) / 0.4));
      device.current.visible = reveal > 0.05 && devFade > 0.02;
    }
    if (chain.current) {
      chain.current.position.set(0.6 * (1 - chainFade), -2.1 + 2.0 * smoothstep((p - 0.34) / 0.3), 1.5);
      chain.current.scale.setScalar(0.85 + 0.15 * chainFade);
      chain.current.visible = reveal > 0.05 && chainFade > 0.02;
    }

    const chMat = channelMat.current?.material as THREE.MeshStandardMaterial | undefined;
    if (chMat) {
      chMat.emissiveIntensity = damp(chMat.emissiveIntensity, 0.08 + model.channel * 2.4, 6, dt);
      chMat.emissive.lerpColors(new THREE.Color(COLORS.sig), new THREE.Color("#a8f0ff"), model.channel);
    }
    if (fieldMat.current) fieldMat.current.opacity = model.channel * 0.5;

    // ---- carrier transport ----
    const mesh = carriers.current;
    if (mesh) {
      const blocked = model.gate < 0.28;
      const speed = 0.55 + model.gate * 1.5;
      const m = new THREE.Matrix4();
      const q = new THREE.Quaternion();
      const v = new THREE.Vector3();
      const sc = new THREE.Vector3(0.035, 0.035, 0.035);
      for (let i = 0; i < CARRIERS; i++) {
        let x = state.current.xs[i];
        if (blocked) {
          if (x > -0.62) x = -0.62 - (i % 24) * 0.006;
        } else {
          x += speed * dt * (0.75 + ((i * 37) % 50) / 100);
          if (x > 1.62) x = -1.62;
        }
        state.current.xs[i] = x;
        v.set(x, 0.26 + state.current.ys[i], state.current.zs[i]);
        m.compose(v, q, sc);
        mesh.setMatrixAt(i, m);
      }
      mesh.instanceMatrix.needsUpdate = true;
      mats.carrier.opacity = 0.25 + model.channel * 0.85;
    }
  });

  return (
    <group>
      {/* ---------------- device ---------------- */}
      <group ref={device}>
        <mesh material={mats.sub} position={[0, 0.02, 0]}>
          <boxGeometry args={[3.9, 0.5, 1.7]} />
        </mesh>
        <mesh material={mats.nd} position={[-1.18, 0.09, 0]}>
          <boxGeometry args={[0.78, 0.36, 1.58]} />
        </mesh>
        <mesh material={mats.nd} position={[1.18, 0.09, 0]}>
          <boxGeometry args={[0.78, 0.36, 1.58]} />
        </mesh>
        <mesh ref={channelMat} material={mats.channel} position={[0, 0.28, 0]}>
          <boxGeometry args={[0.8, 0.09, 1.56]} />
        </mesh>
        <mesh material={mats.oxide} position={[0, 0.35, 0]}>
          <boxGeometry args={[0.86, 0.04, 1.5]} />
        </mesh>
        <mesh material={mats.gate} position={[0, 0.45, 0]}>
          <boxGeometry args={[0.92, 0.15, 1.42]} />
        </mesh>
        {/* capacitive field lines from gate into the channel */}
        <mesh material={mats.field} position={[0, 0.35, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[0.84, 1.45]} />
        </mesh>
        {/* contacts */}
        {[-1.18, 1.18].map((x) => (
          <group key={x} position={[x, 0, 0]}>
            <mesh material={mats.metal} position={[0, 0.36, 0]}>
              <cylinderGeometry args={[0.1, 0.1, 0.36, 14]} />
            </mesh>
            <mesh material={mats.metal} position={[0, 0.55, 0]}>
              <boxGeometry args={[0.26, 0.06, 1.4]} />
            </mesh>
          </group>
        ))}
        {/* poly gate extension */}
        <mesh material={mats.gate} position={[0, 0.53, 0]}>
          <boxGeometry args={[0.34, 0.05, 1.9]} />
        </mesh>

        <instancedMesh ref={carriers} args={[undefined, mats.carrier, CARRIERS]}>
          <sphereGeometry args={[1, 6, 5]} />
        </instancedMesh>

        <Tag position={[0, 0.72, 0.85]} color="rgba(154,217,255,0.95)">
          GATE
        </Tag>
        <Tag position={[-1.5, 0.2, 0.95]} color="rgba(56,189,248,0.8)">
          SOURCE (n+)
        </Tag>
        <Tag position={[1.6, 0.2, 0.95]} color="rgba(56,189,248,0.8)">
          DRAIN (n+)
        </Tag>
        <Tag position={[0, 0.16, 0.95]} color="rgba(139,92,246,0.9)">
          CHANNEL
        </Tag>
      </group>

      {/* ---------------- logic chain ---------------- */}
      <group ref={chain}>
        <LogicChain gate={gate} />
      </group>
    </group>
  );
}

/** TRANSISTOR → GATE → WORD → COMPUTE : signal propagation that dies if the
 *  switch cannot conduct. */
function LogicChain({ gate }: { gate: number }) {
  const pulses = useRef<THREE.InstancedMesh>(null);
  const wave = useRef<THREE.Line | null>(null);
  const nodes = useRef<THREE.Group>(null);
  const active = transistorModel(gate);
  const STAGES = [
    { x: -3.0, label: "SWITCH" },
    { x: -1.0, label: "GATE" },
    { x: 1.0, label: "WORD" },
    { x: 3.0, label: "COMPUTE" },
  ];

  const bits = useMemo(() => {
    const rand = rng(88);
    return Array.from({ length: 12 }, () => rand());
  }, []);

  const waveGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(240 * 3), 3));
    return g;
  }, []);

  const railGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute(
      "position",
      new THREE.BufferAttribute(new Float32Array([-3.0, -0.35, 0.35, 3.0, -0.35, 0.35]), 3)
    );
    return g;
  }, []);

  useEffect(
    () => () => {
      waveGeo.dispose();
      railGeo.dispose();
    },
    [waveGeo, railGeo]
  );

  useFrame((s, dt) => {
    const t = s.clock.elapsedTime;
    const conducting = active.channel > 0.02;
    const mesh = pulses.current;
    if (mesh) {
      const m = new THREE.Matrix4();
      const v = new THREE.Vector3();
      const sc = new THREE.Vector3(0.05, 0.05, 0.05);
      const q = new THREE.Quaternion();
      for (let i = 0; i < 26; i++) {
        const lane = i % 4;
        const prog = (t * (0.35 + active.channel * 0.9) + i * 0.113) % 1;
        const limit = conducting ? 1 : lane === 0 ? 0.22 : 0;
        const e = Math.min(prog, limit);
        const x = -3.0 + e * 6.0;
        const y = -0.35 + Math.sin(e * Math.PI) * 0.22 + (lane - 1.5) * 0.06;
        v.set(x, y, ((i * 13) % 7) / 7 - 0.35);
        m.compose(v, q, sc);
        mesh.setMatrixAt(i, m);
      }
      mesh.instanceMatrix.needsUpdate = true;
      (mesh.material as THREE.Material).opacity = 0.3 + active.channel * 0.8;
    }

    // square wave: high/low follows the switch state
    if (wave.current) {
      const pos = waveGeo.attributes.position as THREE.BufferAttribute;
      const arr = pos.array as Float32Array;
      const hi = 0.42 + active.channel * 0.5;
      for (let i = 0; i < 240; i++) {
        const x = -3.4 + (i / 239) * 6.8;
        const phase = (x * 1.6 - t * (conducting ? 1.8 : 0.15)) % 2;
        const level = phase > 0 ? hi : 0.02;
        arr[i * 3] = x;
        arr[i * 3 + 1] = -1.05 + level;
        arr[i * 3 + 2] = 0;
      }
      pos.needsUpdate = true;
      waveGeo.computeBoundingSphere();
      (wave.current.material as THREE.LineBasicMaterial).opacity = 0.2 + active.channel * 0.7;
    }

    if (nodes.current) {
      nodes.current.children.forEach((c, i) => {
        const mesh = c as THREE.Mesh;
        const mat = mesh.material as THREE.MeshStandardMaterial;
        if (!mat) return;
        const lit = conducting && i <= 3;
        mat.emissiveIntensity = damp(mat.emissiveIntensity, lit ? 0.5 + i * 0.35 : 0.05, 6, dt);
      });
    }
  });

  return (
    <group>
      <group ref={nodes}>
        {STAGES.map((st, i) => (
          <mesh key={st.label} position={[st.x, -0.35, 0.35]}>
            <boxGeometry args={[0.42, 0.24, 0.42]} />
            <meshStandardMaterial
              color="#1a2029"
              emissive={new THREE.Color(i === 3 ? COLORS.magenta : COLORS.sig)}
              emissiveIntensity={0.1}
              metalness={0.6}
              roughness={0.35}
              transparent
            />
          </mesh>
        ))}
      </group>
      <Wire
        geometry={railGeo}
        color={COLORS.sig}
        opacity={0.25}
      />
      <Wire geometry={waveGeo} color="#a8f0ff" opacity={0.6} refObj={wave} additive />
      <instancedMesh ref={pulses} args={[undefined, undefined, 26]}>
        <sphereGeometry args={[1, 6, 5]} />
        <meshBasicMaterial
          color={COLORS.sig}
          transparent
          opacity={0.8}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
          toneMapped={false}
        />
      </instancedMesh>
      {STAGES.map((st, i) => (
        <Tag key={st.label} position={[st.x, -0.02, 0.7]} color={i === 3 ? "rgba(217,70,239,0.85)" : "rgba(249,249,249,0.5)"}>
          {st.label}
        </Tag>
      ))}
      {bits.slice(0, 8).map((b, i) => (
        <mesh key={i} position={[3.55, -1.05 + i * 0.055, 0.35]}>
          <boxGeometry args={[0.3, 0.03, 0.14]} />
          <meshBasicMaterial
            color={active.channel > 0.35 && b > 0.5 ? COLORS.emerald : "#1c2530"}
            transparent
            opacity={0.9}
            toneMapped={false}
          />
        </mesh>
      ))}
    </group>
  );
}

/** THREE.Line wrapper (avoids the SVG <line> intrinsic element) */
function Wire({
  geometry,
  color,
  opacity,
  additive = true,
  refObj,
}: {
  geometry: THREE.BufferGeometry;
  color: string;
  opacity: number;
  additive?: boolean;
  refObj?: React.RefObject<THREE.Line | null>;
}) {
  const obj = useMemo(() => {
    const mat = new THREE.LineBasicMaterial({
      color: new THREE.Color(color),
      transparent: true,
      opacity,
      toneMapped: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
      depthWrite: false,
    });
    return new THREE.Line(geometry, mat);
  }, [geometry, color, opacity, additive]);
  useEffect(() => {
    if (refObj) refObj.current = obj;
    return () => {
      obj.geometry.dispose?.();
      (obj.material as THREE.Material).dispose();
    };
  }, [obj, refObj]);
  return <primitive object={obj} />;
}


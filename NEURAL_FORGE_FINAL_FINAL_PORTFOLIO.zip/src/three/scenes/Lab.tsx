import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { COLORS, PRECISIONS } from "@/lib/constants";
import { clamp, damp, rng } from "@/lib/math";
import { motion, useUI } from "@/state/store";
import { labModel } from "@/lib/sim";
import { layoutTexture } from "@/lib/textures";
import { Cells, createCellField, createFlowField, useRevealOpacity, writeTint, type FlowPath } from "@/three/kit";
import { Tag } from "@/three/kit";

/* ==================================================================
 * CHAPTER 06 — ACCELERATOR LAB
 * A floorplan that reconfigures with the controls: core array, cache,
 * memory controllers, live traffic and a thermal field. Every visual
 * maps to a term in the educational first-principles model.
 * ================================================================== */

export function LabScene() {
  const index = 6;
  const cfg = useUI((s) => s.lab);
  const result = useMemo(() => labModel(cfg), [cfg]);
  const live = useRef({ util: 0.5, thermal: 0.4, pressure: 1 });

  const baseTex = useMemo(() => layoutTexture(1024, 0.9, 71), []);
  const baseMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        map: baseTex,
        color: "#0c1014",
        emissiveMap: baseTex,
        emissive: new THREE.Color(COLORS.sig),
        emissiveIntensity: 0.18,
        metalness: 0.65,
        roughness: 0.4,
        transparent: true,
      }),
    [baseTex]
  );
  const ctrlMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#17222b",
        emissive: new THREE.Color(COLORS.emerald),
        emissiveIntensity: 0.5,
        metalness: 0.7,
        roughness: 0.3,
        transparent: true,
      }),
    []
  );
  const cacheMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#1d1830",
        emissive: new THREE.Color(COLORS.violet),
        emissiveIntensity: 0.45,
        metalness: 0.6,
        roughness: 0.35,
        transparent: true,
      }),
    []
  );

  useRevealOpacity(index, [baseMat, ctrlMat, cacheMat]);

  useEffect(
    () => () => {
      baseMat.dispose();
      baseTex.dispose();
      ctrlMat.dispose();
      cacheMat.dispose();
    },
    [baseMat, baseTex, ctrlMat, cacheMat]
  );

  const grid = useMemo(() => {
    const n = Math.max(2, Math.round(Math.sqrt(cfg.cores)));
    return { n, count: n * n };
  }, [cfg.cores]);

  const coreField = useMemo(
    () => createCellField({ count: grid.count, base: "box", size: [0.34, 0.1, 0.34], speed: 5 }),
    [grid.count]
  );
  const seedRef = useRef<number[]>([]);
  const rand = useMemo(() => rng(606), []);

  useEffect(() => {
    seedRef.current = Array.from({ length: grid.count }, () => rand());
  }, [grid.count, rand]);

  useEffect(
    () => () => {
      coreField.geometry.dispose();
      coreField.material.dispose();
    },
    [coreField]
  );

  /* memory controller -> core traffic */
  const flow = useMemo(() => {
    const paths: FlowPath[] = [];
    const randF = rng(8899);
    const count = 70;
    for (let i = 0; i < count; i++) {
      const lane = i % 4;
      const zx = -3.4 + lane * 2.26;
      const tx = -3.0 + randF() * 6.0;
      const fromCtrl: [number, number, number] = [zx, 0.55, 4.1];
      const toCore: [number, number, number] = [tx, 0.5, -2.2 + randF() * 4.4];
      paths.push({
        start: fromCtrl,
        end: toCore,
        tint: new THREE.Color(i % 6 === 0 ? COLORS.amber : COLORS.sig),
        speed: 0.3 + randF() * 0.6,
        size: 0.5 + randF() * 0.9,
      });
    }
    return createFlowField(paths);
  }, []);
  const flowMat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: { uTime: { value: 0 }, uOpacity: { value: 0 }, uDensity: { value: 0.5 } },
        vertexShader: /* glsl */ `
          attribute vec3 aStart; attribute vec3 aEnd; attribute vec3 aTint; attribute vec3 aMeta;
          uniform float uTime, uOpacity, uDensity;
          varying float vA; varying vec3 vTint;
          void main(){
            float sp = max(aMeta.y, 0.001);
            float tt = fract(aMeta.x + uTime * sp * uDensity);
            float e = tt * tt * (3.0 - 2.0 * tt);
            vec3 p = mix(aStart, aEnd, e);
            vec3 pos = position * aMeta.z;
            vTint = aTint; vA = uOpacity * sin(e * 3.14159);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(p + pos, 1.0);
          }`,
        fragmentShader: /* glsl */ `
          varying float vA; varying vec3 vTint;
          void main(){ gl_FragColor = vec4(vTint * (0.5 + 1.5 * vA), vA); }`,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        toneMapped: false,
      }),
    []
  );

  useEffect(
    () => () => {
      flow.dispose();
      flowMat.dispose();
    },
    [flow, flowMat]
  );

  const heatMat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: { uTime: { value: 0 }, uOpacity: { value: 0 }, uHeat: { value: 0.4 } },
        vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
        fragmentShader: /* glsl */ `
          uniform float uTime, uOpacity, uHeat;
          varying vec2 vUv;
          float hash21(vec2 p){ p = fract(p*vec2(123.34,456.21)); p += dot(p,p+45.32); return fract(p.x*p.y); }
          float vnoise(vec2 p){ vec2 i=floor(p); vec2 f=fract(p); f=f*f*(3.0-2.0*f);
            float a=hash21(i), b=hash21(i+vec2(1.0,0.0)), c=hash21(i+vec2(0.0,1.0)), d=hash21(i+vec2(1.0,1.0));
            return mix(mix(a,b,f.x), mix(c,d,f.x), f.y); }
          void main(){
            float n = vnoise(vUv * 7.0 + uTime * 0.12);
            float edge = smoothstep(0.52, 0.2, length(vUv - 0.5));
            vec3 cool = vec3(0.1, 0.45, 0.8);
            vec3 hot  = vec3(1.0, 0.34, 0.08);
            vec3 col = mix(cool, hot, clamp(uHeat - 0.25, 0.0, 1.0));
            float a = uOpacity * edge * (0.1 + n * 0.5 * uHeat);
            gl_FragColor = vec4(col * (0.4 + n), a);
          }`,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        toneMapped: false,
      }),
    []
  );

  useEffect(() => () => heatMat.dispose(), [heatMat]);

  const cacheRef = useRef<THREE.Mesh>(null);
  const cacheSize = useRef(1);

  useFrame((s, dt) => {
    const reveal = motion.reveal[index] ?? 0;
    const t = s.clock.elapsedTime;
    live.current.util = damp(live.current.util, result.utilisation, 3, dt);
    live.current.thermal = damp(live.current.thermal, clamp(result.thermal, 0.05, 1.2), 2.2, dt);
    live.current.pressure = damp(live.current.pressure, clamp(result.memoryPressure, 0.2, 3), 3, dt);

    const u = coreField.material.uniforms;
    u.uTime.value = t;
    u.uOpacity.value = damp(u.uOpacity.value, reveal, 5, dt);

    // per-core activity
    const attr = coreField.geometry.getAttribute("aTint") as THREE.InstancedBufferAttribute;
    const base = 0.15 + live.current.util * 2.1;
    const stalled = result.bound === "MEMORY";
    for (let i = 0; i < grid.count; i++) {
      const seed = seedRef.current[i] ?? 0.5;
      const flicker = 0.65 + 0.35 * Math.sin(t * (stalled ? 1.4 : 5.5) + seed * 12);
      const col = stalled && seed > live.current.util ? COLORS.amber : COLORS.sig;
      writeTint(attr, i, new THREE.Color(col), base * flicker + 0.05);
    }
    attr.needsUpdate = true;

    flowMat.uniforms.uTime.value = t;
    flowMat.uniforms.uOpacity.value = damp(flowMat.uniforms.uOpacity.value, reveal * (0.3 + clamp(live.current.pressure) * 0.7), 4, dt);
    flowMat.uniforms.uDensity.value = damp(flowMat.uniforms.uDensity.value, 0.2 + cfg.bandwidth * 0.7, 4, dt);

    heatMat.uniforms.uTime.value = t;
    heatMat.uniforms.uOpacity.value = damp(heatMat.uniforms.uOpacity.value, reveal * 0.85, 4, dt);
    heatMat.uniforms.uHeat.value = live.current.thermal;

    if (cacheRef.current) {
      cacheSize.current = damp(cacheSize.current, 0.4 + (cfg.cache / 64) * 1.8, 4, dt);
      cacheRef.current.scale.set(1, cacheSize.current, 1);
      cacheMat.emissiveIntensity = 0.3 + (1 - result.hitRate) * 0.8;
    }
    ctrlMat.emissiveIntensity = 0.3 + clamp(live.current.pressure) * 0.9;
  });

  const precision = PRECISIONS.find((p) => p.id === cfg.precision) ?? PRECISIONS[1];

  return (
    <group>
      <mesh material={baseMat} position={[0, 0, 0]} receiveShadow>
        <boxGeometry args={[8.6, 0.24, 8.6]} />
      </mesh>

      {/* core array */}
      <Cells
        field={coreField}
        count={grid.count}
        place={(i) => {
          const n = grid.n;
          const span = 5.6;
          const step = span / Math.max(1, n - 1 || 1);
          const x = (i % n) * step - span / 2;
          const z = Math.floor(i / n) * step - 1.9;
          return { p: [x, 0.32, z], s: [1, 1, 1] };
        }}
      />

      {/* cache / SRAM */}
      <mesh ref={cacheRef} material={cacheMat} position={[3.35, 0.3, -1.6]}>
        <boxGeometry args={[1.1, 1, 2.6]} />
      </mesh>

      {/* memory controllers along the front edge */}
      {[-3.4, -1.14, 1.14, 3.4].map((x) => (
        <group key={x} position={[x, 0, 0]}>
          <mesh material={ctrlMat} position={[0, 0.34, 4.1]}>
            <boxGeometry args={[0.72, 0.28, 0.42]} />
          </mesh>
        </group>
      ))}

      {/* precision ring: die size reacts to the selected format */}
      <mesh position={[0, 0.14, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[3.6, 3.72, 96]} />
        <meshBasicMaterial color={precision.bytes <= 1 ? COLORS.magenta : COLORS.sig} transparent opacity={0.28} blending={THREE.AdditiveBlending} toneMapped={false} />
      </mesh>

      {/* thermal field */}
      <mesh position={[0, 0.62, 0]} rotation={[-Math.PI / 2, 0, 0]} material={heatMat}>
        <planeGeometry args={[8.4, 8.4]} />
      </mesh>

      {/* traffic */}
      <mesh geometry={flow} material={flowMat} frustumCulled={false} />

      <Tag position={[0, 0.75, -3.1]} color="rgba(56,189,248,0.85)">
        CORE ARRAY · {cfg.cores}
      </Tag>
      <Tag position={[3.35, 1.4, -1.6]} color="rgba(139,92,246,0.9)">
        SRAM CACHE
      </Tag>
      <Tag position={[0, 0.9, 4.35]} color="rgba(16,185,129,0.9)">
        MEMORY CONTROLLERS
      </Tag>
    </group>
  );
}

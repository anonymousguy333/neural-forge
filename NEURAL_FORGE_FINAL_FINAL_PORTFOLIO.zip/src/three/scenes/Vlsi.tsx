import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Html } from "@react-three/drei";
import * as THREE from "three";
import { COLORS, VLSI_STAGES } from "@/lib/constants";
import { clamp, damp, rng, smoothstep } from "@/lib/math";
import { motion, useUI } from "@/state/store";
import { layoutTexture } from "@/lib/textures";
import { Cells, createCellField, writeTint } from "@/three/kit";

/* ==================================================================
 * CHAPTER 05 — VLSI FOUNDRY
 * One die, eight stages. Every element carries a birth stage and (for
 * the abstract RTL graph) a death stage, so the whole pipeline is a
 * single continuous GPU-driven transformation.
 * ================================================================== */

const REGIONS = [
  { x: -4.25, z: -4.25, w: 4.0, h: 4.0, label: "CORE TILE 0" },
  { x: 0.25, z: -4.25, w: 4.0, h: 4.0, label: "CORE TILE 1" },
  { x: -4.25, z: 0.25, w: 4.0, h: 4.0, label: "CORE TILE 2" },
  { x: 0.25, z: 0.25, w: 2.5, h: 2.5, label: "NPU ARRAY" },
  { x: 2.9, z: 0.25, w: 1.35, h: 4.0, label: "SRAM" },
];

export function VlsiScene({ cells }: { cells: number }) {
  const index = 5;
  const stage = useUI((s) => s.stage);
  const stageManual = useUI((s) => s.stageManual);

  const layout = useMemo(() => buildLayout(cells), [cells]);

  const logic = useMemo(
    () => createCellField({ count: layout.cells.length, base: "box", speed: 2.4 }),
    [layout]
  );
  const routes = useMemo(
    () => createCellField({ count: layout.routes.length, base: "box", speed: 2.4 }),
    [layout]
  );
  const graph = useMemo(
    () => createCellField({ count: layout.nodes.length, base: "octa", size: [0.16, 0.16, 0.16], speed: 2.4 }),
    [layout]
  );

  const baseTex = useMemo(() => layoutTexture(1024, 1.4, 33), []);
  const baseMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        map: baseTex,
        color: "#0d1014",
        emissiveMap: baseTex,
        emissive: new THREE.Color(COLORS.sig),
        emissiveIntensity: 0.22,
        metalness: 0.6,
        roughness: 0.42,
        transparent: true,
      }),
    [baseTex]
  );

  /* GDSII layer planes */
  const layers = useMemo(() => {
    const colors = [COLORS.sig, COLORS.violet, COLORS.magenta, COLORS.amber, "#22d3ee", COLORS.emerald];
    return colors.map((c, i) => ({ color: c, y: 0.12 + i * 0.06, i }));
  }, []);
  const layerMats = useMemo(
    () =>
      layers.map(
        (l) =>
          new THREE.MeshBasicMaterial({
            color: new THREE.Color(l.color),
            transparent: true,
            opacity: 0,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
            toneMapped: false,
          })
      ),
    [layers]
  );

  const graphLines = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(layout.links, 3));
    const m = new THREE.LineBasicMaterial({
      color: new THREE.Color(COLORS.sig),
      transparent: true,
      opacity: 0.25,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    });
    return new THREE.LineSegments(g, m);
  }, [layout]);

  const floorLines = useMemo(() => {
    const arr: number[] = [];
    REGIONS.forEach((r) => {
      const x0 = r.x;
      const x1 = r.x + r.w;
      const z0 = r.z;
      const z1 = r.z + r.h;
      arr.push(x0, 0.08, z0, x1, 0.08, z0);
      arr.push(x1, 0.08, z0, x1, 0.08, z1);
      arr.push(x1, 0.08, z1, x0, 0.08, z1);
      arr.push(x0, 0.08, z1, x0, 0.08, z0);
    });
    // die outline + scribe grid
    arr.push(-4.5, 0.08, -4.5, 4.5, 0.08, -4.5);
    arr.push(4.5, 0.08, -4.5, 4.5, 0.08, 4.5);
    arr.push(4.5, 0.08, 4.5, -4.5, 0.08, 4.5);
    arr.push(-4.5, 0.08, 4.5, -4.5, 0.08, -4.5);
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(arr), 3));
    const m = new THREE.LineBasicMaterial({
      color: new THREE.Color("#7dd3fc"),
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    });
    return new THREE.LineSegments(g, m);
  }, []);

  /* colour the cells: cyan = normal, amber = active, red = critical */
  useEffect(() => {
    const attr = logic.geometry.getAttribute("aTint") as THREE.InstancedBufferAttribute;
    const anim = logic.geometry.getAttribute("aAnim") as THREE.InstancedBufferAttribute;
    const cyan = new THREE.Color("#2f8fd6");
    const violet = new THREE.Color("#7c5cf0");
    const grey = new THREE.Color("#2b3a4a");
    layout.cells.forEach((c, i) => {
      const col = c.kind === 2 ? violet : c.kind === 1 ? cyan : grey;
      writeTint(attr, i, col, c.kind === 0 ? 0.4 : 0.8);
      anim.array[c.i * 3 + 0] = c.birth;
      anim.array[c.i * 3 + 1] = c.seed;
      anim.array[c.i * 3 + 2] = 1.4 + c.seed * 2.2;
    });
    attr.needsUpdate = true;
    anim.needsUpdate = true;

    const rAttr = routes.geometry.getAttribute("aTint") as THREE.InstancedBufferAttribute;
    const rAnim = routes.geometry.getAttribute("aAnim") as THREE.InstancedBufferAttribute;
    layout.routes.forEach((r, i) => {
      writeTint(rAttr, i, new THREE.Color(r.critical ? COLORS.red : COLORS.sig), r.critical ? 1.5 : 0.75);
      rAnim.array[i * 3 + 0] = r.birth;
      rAnim.array[i * 3 + 1] = r.seed;
      rAnim.array[i * 3 + 2] = r.critical ? 3.4 : 1.2;
    });
    rAttr.needsUpdate = true;
    rAnim.needsUpdate = true;

    const gAttr = graph.geometry.getAttribute("aTint") as THREE.InstancedBufferAttribute;
    const gAnim = graph.geometry.getAttribute("aAnim") as THREE.InstancedBufferAttribute;
    layout.nodes.forEach((n, i) => {
      writeTint(gAttr, i, new THREE.Color(i % 4 === 0 ? COLORS.magenta : "#8ad8ff"), 1.1);
      gAnim.array[i * 3 + 0] = 0; // birth: RTL exists first
      gAnim.array[i * 3 + 1] = 3.0 + n.seed * 1.4; // dissolves during placement
      gAnim.array[i * 3 + 2] = 1.6 + n.seed * 1.4;
    });
    gAttr.needsUpdate = true;
    gAnim.needsUpdate = true;
  }, [layout, logic, routes, graph]);

  useEffect(
    () => () => {
      [logic, routes, graph].forEach((f) => {
        f.geometry.dispose();
        f.material.dispose();
      });
      baseMat.dispose();
      baseTex.dispose();
      layerMats.forEach((m) => m.dispose());
      graphLines.geometry.dispose();
      (graphLines.material as THREE.Material).dispose();
      floorLines.geometry.dispose();
      (floorLines.material as THREE.Material).dispose();
    },
    [logic, routes, graph, baseMat, baseTex, layerMats, graphLines, floorLines]
  );

  const stageRef = useRef(0);
  const dimRef = useRef(-1);

  useFrame((s, dt) => {
    const p = clamp(motion.camT - index);
    const scrollStage = p * 7.35;
    const target = stageManual ? stage : scrollStage;
    stageRef.current = damp(stageRef.current, target, 4.5, dt);
    motion.stageF = stageRef.current;
    const st = stageRef.current;

    const reveal = motion.reveal[index] ?? 0;
    const u = (f: ReturnType<typeof createCellField>) => f.material.uniforms;
    u(logic).uProgress.value = st;
    u(routes).uProgress.value = st;
    u(graph).uProgress.value = st;
    u(logic).uOpacity.value = damp(u(logic).uOpacity.value, reveal, 5, dt);
    u(routes).uOpacity.value = damp(u(routes).uOpacity.value, reveal, 5, dt);
    u(graph).uOpacity.value = damp(u(graph).uOpacity.value, reveal, 5, dt);
    u(logic).uTime.value = s.clock.elapsedTime;
    u(routes).uTime.value = s.clock.elapsedTime;
    u(graph).uTime.value = s.clock.elapsedTime;

    // timing analysis: dim everything that is not on a critical path
    const dimKey = st > 5.6 ? 1 : 0;
    if (dimKey !== dimRef.current) {
      dimRef.current = dimKey;
      const attr = logic.geometry.getAttribute("aTint") as THREE.InstancedBufferAttribute;
      layout.cells.forEach((c, i) => {
        const col = c.critical
          ? new THREE.Color(COLORS.red)
          : dimKey
            ? new THREE.Color("#1b2a36")
            : c.kind === 2
              ? new THREE.Color("#7c5cf0")
              : c.kind === 1
                ? new THREE.Color("#2f8fd6")
                : new THREE.Color("#2b3a4a");
        writeTint(attr, i, col, c.critical ? 1.7 : dimKey ? 0.28 : c.kind === 0 ? 0.4 : 0.8);
      });
      attr.needsUpdate = true;
    }

    (graphLines.material as THREE.LineBasicMaterial).opacity = reveal * 0.3 * (1 - smoothstep((st - 2.6) / 1.2));
    (floorLines.material as THREE.LineBasicMaterial).opacity =
      reveal * smoothstep((st - 2.4) / 0.9) * (0.45 - 0.15 * smoothstep((st - 6.4) / 0.8));
    baseMat.emissiveIntensity = 0.1 + smoothstep((st - 6.2) / 1.2) * 0.75;
    layerMats.forEach((m, i) => {
      const local = clamp((st - (6.1 + i * 0.14)) / 0.5);
      m.opacity = local * 0.2 * reveal;
    });
  });

  const die = layout;

  return (
    <group>
      {/* substrate */}
      <mesh material={baseMat} position={[0, -0.16, 0]} receiveShadow>
        <boxGeometry args={[9.3, 0.28, 9.3]} />
      </mesh>

      {/* floorplan / die outline */}
      <primitive object={floorLines} />

      {/* standard cells */}
      <Cells
        field={logic}
        count={die.cells.length}
        place={(i) => {
          const c = die.cells[i];
          return { p: [c.x, 0.1 + c.layer * 0.03, c.z], s: [c.w, 0.06, c.h], r: [0, 0, 0] };
        }}
      />

      {/* routing */}
      <Cells
        field={routes}
        count={die.routes.length}
        place={(i) => {
          const r = die.routes[i];
          return { p: [r.x, 0.16 + r.layer * 0.05, r.z], s: [r.w, 0.02, r.h] };
        }}
      />

      {/* abstract RTL graph floating above the die */}
      <group position={[0, 3.1, 0]}>
        <Cells
          field={graph}
          count={die.nodes.length}
          place={(i) => ({ p: die.nodes[i].p, s: [1, 1, 1] })}
        />
        <primitive object={graphLines} />
      </group>

      {/* GDSII layer stack */}
      {layers.map((l, i) => (
        <mesh key={i} position={[0, l.y, 0]} rotation={[-Math.PI / 2, 0, 0]} material={layerMats[i]}>
          <planeGeometry args={[9, 9]} />
        </mesh>
      ))}

      {REGIONS.map((r) => (
        <Html
          key={r.label}
          position={[r.x + r.w / 2, 0.4, r.z + r.h / 2]}
          center
          style={{ pointerEvents: "none" }}
          zIndexRange={[16, 0]}
        >
          <div
            className="whitespace-nowrap font-mono text-[8px] tracking-[0.24em] uppercase transition-opacity duration-500"
            style={{ color: "rgba(125,211,252,0.7)", textShadow: "0 2px 8px rgba(0,0,0,0.9)" }}
          >
            {r.label}
          </div>
        </Html>
      ))}

      <StageReadout />
    </group>
  );
}

/** Small floating stage indicator anchored to the die edge. */
function StageReadout() {
  const stage = useUI((s) => s.stage);
  const manual = useUI((s) => s.stageManual);
  const ref = useRef<HTMLDivElement>(null);
  useFrame(() => {
    if (!ref.current) return;
    const scrollStage = clamp(motion.camT - 5) * 7.35;
    const st = manual ? stage : scrollStage;
    const i = clamp(Math.floor(st), 0, VLSI_STAGES.length - 1);
    ref.current.textContent = `${VLSI_STAGES[i].label}`;
  });
  return (
    <Html position={[0, 1.3, 5.1]} center style={{ pointerEvents: "none" }} zIndexRange={[16, 0]}>
      <div
        ref={ref}
        className="whitespace-nowrap font-mono text-[11px] tracking-[0.32em] uppercase"
        style={{ color: "rgba(249,249,249,0.85)", textShadow: "0 2px 12px rgba(0,0,0,0.95)" }}
      />
    </Html>
  );
}

/* ------------------------- layout generation ------------------------- */

interface CellDef {
  i: number;
  x: number;
  z: number;
  w: number;
  h: number;
  layer: number;
  kind: 0 | 1 | 2;
  birth: number;
  seed: number;
  critical: boolean;
}
interface RouteDef {
  x: number;
  z: number;
  w: number;
  h: number;
  layer: number;
  birth: number;
  seed: number;
  critical: boolean;
}

function buildLayout(budget: number) {
  const rand = rng(9021);
  const cellCount = Math.max(180, Math.round(budget * 0.62));
  const routeCount = Math.max(90, Math.round(budget * 0.34));

  const cells: CellDef[] = [];
  REGIONS.forEach((r, ri) => {
    const regionCells = Math.floor(cellCount * (r.w * r.h) / REGIONS.reduce((a, x) => a + x.w * x.h, 0));
    for (let i = 0; i < regionCells; i++) {
      const row = Math.floor(rand() * 14);
      const col = rand();
      const w = 0.05 + rand() * 0.16;
      const h = 0.16;
      cells.push({
        i: cells.length,
        x: r.x + 0.1 + col * (r.w - 0.25),
        z: r.z + 0.14 + row * ((r.h - 0.3) / 14),
        w,
        h,
        layer: Math.floor(rand() * 3),
        kind: (rand() > 0.86 ? 2 : rand() > 0.5 ? 1 : 0) as 0 | 1 | 2,
        birth: 3.4 + ri * 0.06 + rand() * 0.9,
        seed: rand(),
        critical: false,
      });
    }
  });

  // synthesis / gate-level cells arrive earlier, in the die centre
  const early = Math.floor(cellCount * 0.28);
  for (let i = 0; i < early; i++) {
    const a = rand() * Math.PI * 2;
    const r = 0.4 + rand() * 2.2;
    cells.push({
      i: cells.length,
      x: Math.cos(a) * r,
      z: Math.sin(a) * r,
      w: 0.06 + rand() * 0.12,
      h: 0.06 + rand() * 0.12,
      layer: 1,
      kind: 1,
      birth: 1.1 + rand() * 1.9,
      seed: rand(),
      critical: false,
    });
  }

  const routes: RouteDef[] = [];
  for (let i = 0; i < routeCount; i++) {
    const along = rand() > 0.5;
    const len = 0.35 + rand() * 3.4;
    const x = -4.2 + rand() * 8.4;
    const z = -4.2 + rand() * 8.4;
    routes.push({
      x: along ? x + len / 2 : x,
      z: along ? z : z + len / 2,
      w: along ? len : 0.035,
      h: along ? 0.035 : len,
      layer: Math.floor(rand() * 5),
      birth: 4.6 + rand() * 1.2,
      seed: rand(),
      critical: false,
    });
  }

  // critical path: a connected chain across the die
  const chain = Math.min(16, Math.floor(routes.length * 0.14));
  let cx = -4.0;
  let cz = 3.9;
  let layer = 0;
  for (let i = 0; i < chain; i++) {
    const along = i % 2 === 0;
    const len = 1.2 + rand() * 2.4;
    const r: RouteDef = {
      x: along ? cx + len / 2 : cx,
      z: along ? cz : cz - len / 2,
      w: along ? len : 0.045,
      h: along ? 0.045 : len,
      layer: layer % 5,
      birth: 5.5 + i * 0.06,
      seed: rand(),
      critical: true,
    };
    routes.push(r);
    if (along) cx += len;
    else cz -= len;
    layer += rand() > 0.6 ? 1 : 0;
    if (cx > 4.2 || cz < -4.2) break;
  }
  // mark cells near the critical chain as timing-critical
  cells.forEach((c) => {
    if (Math.abs(c.z - 3.2) < 0.9 && c.x < 1.5) c.critical = true;
  });

  // abstract RTL graph
  const nodes: { p: [number, number, number]; seed: number }[] = [];
  const nodeCount = 58;
  for (let i = 0; i < nodeCount; i++) {
    const a = (i / nodeCount) * Math.PI * 2 + rand() * 0.4;
    const r = 0.8 + rand() * 3.1;
    nodes.push({ p: [Math.cos(a) * r, (rand() - 0.5) * 1.4, Math.sin(a) * r], seed: rand() });
  }
  const links: number[] = [];
  for (let i = 0; i < nodeCount; i++) {
    const a = nodes[i];
    const b = nodes[(i * 7 + 3) % nodeCount];
    const c = nodes[(i + 5) % nodeCount];
    links.push(a.p[0], a.p[1], a.p[2], b.p[0], b.p[1], b.p[2]);
    if (i % 3 === 0) links.push(a.p[0], a.p[1], a.p[2], c.p[0], c.p[1], c.p[2]);
  }

  return { cells, routes, nodes, links: new Float32Array(links) };
}

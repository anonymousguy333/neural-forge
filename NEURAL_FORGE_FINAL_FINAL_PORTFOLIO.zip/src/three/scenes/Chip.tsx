import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Html } from "@react-three/drei";
import * as THREE from "three";
import { COLORS, PACKAGE_PARTS } from "@/lib/constants";
import { clamp, damp, rng } from "@/lib/math";
import { motion, useUI } from "@/state/store";
import { dieTexture, substrateTexture, stackTexture } from "@/lib/textures";
import { useRevealOpacity } from "@/three/kit";

/* ==================================================================
 * CHAPTER 01 — THE CHIP
 * An exploded semiconductor package built from real geometry:
 * lid, I/O die, substrate, interposer + micro-bumps, compute die and
 * HBM stacks. Click any part to focus it; drag to orbit.
 * ================================================================== */

const ASSEMBLED: Record<string, number> = {
  lid: 0.46,
  io: 0.3,
  substrate: 0.17,
  interposer: 0.07,
  die: -0.03,
  hbm: -0.16,
};

const EXPLODED: Record<string, number> = {
  lid: 2.65,
  io: 1.75,
  substrate: 0.85,
  interposer: 0.05,
  die: -0.85,
  hbm: -1.85,
};

export function ChipScene({ cells: _cells }: { cells?: number }) {
  const index = 1;
  const selected = useUI((s) => s.selectedPart);
  const selectPart = useUI((s) => s.selectPart);
  const exploded = useUI((s) => s.exploded);
  const group = useRef<THREE.Group>(null);
  const explode = useRef(1);
  const focus = useRef(new THREE.Vector2(0, 0));

  const dieTex = useMemo(() => dieTexture(1024, 3), []);
  const subTex = useMemo(() => substrateTexture(1024, 9), []);
  const hbmTex = useMemo(() => stackTexture(512, 8, "139,92,246"), []);

  const mats = useMemo(() => {
    const mk = (color: string, o: Partial<THREE.MeshStandardMaterialParameters> = {}) =>
      new THREE.MeshStandardMaterial({
        color,
        metalness: 0.9,
        roughness: 0.3,
        transparent: true,
        emissive: new THREE.Color(color),
        emissiveIntensity: 0.08,
        ...o,
      });
    return {
      lid: mk("#9aa1ab", { roughness: 0.16, metalness: 1 }),
      io: mk("#39414d", { emissive: new THREE.Color(COLORS.emerald), emissiveIntensity: 0.3 }),
      substrate: mk("#1c2a24", {
        map: subTex,
        emissiveMap: subTex,
        emissive: new THREE.Color(COLORS.gold),
        emissiveIntensity: 0.35,
        metalness: 0.6,
        roughness: 0.45,
      }),
      interposer: mk("#4b515f", { roughness: 0.22, metalness: 0.95 }),
      die: mk("#20242c", {
        map: dieTex,
        emissiveMap: dieTex,
        emissive: new THREE.Color(COLORS.sig),
        emissiveIntensity: 0.65,
        roughness: 0.24,
        metalness: 0.7,
      }),
      hbm: mk("#241f33", {
        map: hbmTex,
        emissiveMap: hbmTex,
        emissive: new THREE.Color(COLORS.violet),
        emissiveIntensity: 0.6,
        metalness: 0.7,
        roughness: 0.35,
      }),
      bump: mk("#d8c08a", { metalness: 1, roughness: 0.25, emissiveIntensity: 0 }),
      pad: mk("#c9a15f", { metalness: 1, roughness: 0.3, emissiveIntensity: 0 }),
    };
  }, [dieTex, subTex, hbmTex]);

  useRevealOpacity(index, Object.values(mats));

  useEffect(
    () => () => {
      Object.values(mats).forEach((m) => m.dispose());
      [dieTex, subTex, hbmTex].forEach((t) => t.dispose());
    },
    [mats, dieTex, subTex, hbmTex]
  );

  /* ---- micro-bumps between die and interposer ---- */
  const bumps = useMemo(() => {
    const rand = rng(31);
    const n = 220;
    const pos = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      pos[i * 3] = (rand() - 0.5) * 1.7;
      pos[i * 3 + 1] = 0;
      pos[i * 3 + 2] = (rand() - 0.5) * 1.7;
    }
    return pos;
  }, []);
  const bumpRef = useRef<THREE.InstancedMesh>(null);
  useEffect(() => {
    const m = bumpRef.current;
    if (!m) return;
    const mat4 = new THREE.Matrix4();
    for (let i = 0; i < 220; i++) {
      mat4.makeScale(0.035, 0.035, 0.035);
      mat4.setPosition(bumps[i * 3], bumps[i * 3 + 1], bumps[i * 3 + 2]);
      m.setMatrixAt(i, mat4);
    }
    m.instanceMatrix.needsUpdate = true;
    m.frustumCulled = false;
  }, [bumps]);

  /* ---- BGA ball grid under the substrate ---- */
  const bga = useMemo(() => {
    const n = 16;
    const items: [number, number][] = [];
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) items.push([(i - (n - 1) / 2) * 0.24, (j - (n - 1) / 2) * 0.24]);
    return items;
  }, []);
  const bgaRef = useRef<THREE.InstancedMesh>(null);
  useEffect(() => {
    const m = bgaRef.current;
    if (!m) return;
    const mat4 = new THREE.Matrix4();
    bga.forEach(([x, z], i) => {
      mat4.identity();
      mat4.makeScale(0.055, 0.055, 0.055);
      mat4.setPosition(x, 0, z);
      m.setMatrixAt(i, mat4);
    });
    m.instanceMatrix.needsUpdate = true;
    m.frustumCulled = false;
  }, [bga]);

  const partRefs = useRef<Record<string, THREE.Group | null>>({});

  useFrame((state, dt) => {
    const g = group.current;
    if (!g) return;
    const target = exploded ? 1 : 0;
    explode.current = damp(explode.current, target, 3.2, dt);
    const ex = explode.current;

    // selection wins over scroll-driven emphasis, then the narrative auto-focus
    const af = motion.autoFocus;
    PACKAGE_PARTS.forEach((p) => {
      const node = partRefs.current[p.id];
      if (!node) return;
      const a = ASSEMBLED[p.id] ?? 0;
      const b = EXPLODED[p.id] ?? 0;
      node.position.y = a + (b - a) * ex;
      const isSel = selected === p.id;
      const isFocus = !selected && af === p.id;
      const dim = (selected || af) && !isSel && !isFocus ? 0.26 : 1;
      const mat = (mats as Record<string, THREE.MeshStandardMaterial>)[p.id];
      if (mat) {
        mat.emissiveIntensity = damp(
          mat.emissiveIntensity,
          (p.id === "die" || p.id === "hbm" || p.id === "substrate" ? 0.6 : 0.3) * dim +
            (isSel ? 0.6 + 0.25 * Math.sin(state.clock.elapsedTime * 3) : 0) +
            (isFocus ? 0.5 + 0.18 * Math.sin(state.clock.elapsedTime * 2) : 0),
          4,
          dt
        );
        mat.opacity = damp(mat.opacity, clamp(dim + 0.18), 4, dt);
      }
    });

    // camera-like focus: shift the assembly so the selected part sits centre
    const selPart = PACKAGE_PARTS.find((p) => p.id === selected);
    const sy = selPart ? (EXPLODED[selPart.id] ?? 0) * ex : 0;
    focus.current.x = damp(focus.current.x, selPart ? -0.0 : 0, 3, dt);
    focus.current.y = damp(focus.current.y, selPart ? -sy * 0.55 : 0, 3, dt);
    g.position.y = focus.current.y;
    g.rotation.y = Math.sin(state.clock.elapsedTime * 0.06) * 0.18;
    g.visible = (motion.reveal[index] ?? 0) > 0.02;
  });

  const onPick = (id: string) => (e: { stopPropagation: () => void }) => {
    e.stopPropagation();
    selectPart(useUI.getState().selectedPart === id ? null : id);
  };

  return (
    <group ref={group}>
      {PACKAGE_PARTS.map((p) => (
        <group
          key={p.id}
          ref={(n) => {
            partRefs.current[p.id] = n;
          }}
          onPointerDown={onPick(p.id)}
          onPointerOver={() => (document.body.style.cursor = "pointer")}
          onPointerOut={() => (document.body.style.cursor = "auto")}
        >
          {p.id === "lid" && (
            <mesh material={mats.lid} castShadow>
              <boxGeometry args={[4.3, 0.2, 4.3]} />
            </mesh>
          )}
          {p.id === "io" && (
            <group position={[-1.55, 0, 0]}>
              <mesh material={mats.io}>
                <boxGeometry args={[1.15, 0.14, 2.1]} />
              </mesh>
              {[-0.85, 0, 0.85].map((z) => (
                <mesh key={z} position={[0.62, 0, z]} material={mats.pad}>
                  <boxGeometry args={[0.06, 0.16, 0.22]} />
                </mesh>
              ))}
            </group>
          )}
          {p.id === "substrate" && (
            <mesh material={mats.substrate}>
              <boxGeometry args={[4.0, 0.14, 4.0]} />
            </mesh>
          )}
          {p.id === "interposer" && (
            <group>
              <mesh material={mats.interposer}>
                <boxGeometry args={[2.9, 0.09, 2.9]} />
              </mesh>
              <instancedMesh ref={bumpRef} args={[undefined, mats.bump, 220]}>
                <sphereGeometry args={[1, 8, 6]} />
              </instancedMesh>
              <mesh material={mats.bump} position={[0, -0.1, 0]}>
                <boxGeometry args={[2.86, 0.02, 2.86]} />
              </mesh>
            </group>
          )}
          {p.id === "die" && (
            <group>
              <mesh material={mats.die}>
                <boxGeometry args={[1.95, 0.13, 1.95]} />
              </mesh>
              <mesh material={mats.die} position={[0, 0.08, 0]} rotation={[0, Math.PI / 2, 0]}>
                <boxGeometry args={[1.2, 0.02, 0.9]} />
              </mesh>
            </group>
          )}
          {p.id === "hbm" && (
            <group>
              {[-1.05, 1.05].map((x) => (
                <group key={x} position={[x, 0, 0.55]}>
                  {[0, 1, 2, 3].map((i) => (
                    <mesh key={i} position={[0, i * 0.085, 0]} material={mats.hbm}>
                      <boxGeometry args={[0.72, 0.06, 1.05]} />
                    </mesh>
                  ))}
                  <mesh position={[0, 0.42, 0]} material={mats.pad}>
                    <boxGeometry args={[0.74, 0.03, 1.07]} />
                  </mesh>
                </group>
              ))}
            </group>
          )}
          {selected === p.id && (
            <mesh position={[0, 0, 0]}>
              <boxGeometry args={[4.5, 0.5, 4.5]} />
              <meshBasicMaterial color={p.accent} wireframe transparent opacity={0.18} toneMapped={false} />
            </mesh>
          )}
        </group>
      ))}

      {/* ball grid array */}
      <instancedMesh ref={bgaRef} args={[undefined, mats.pad, bga.length]} position={[0, -0.32, 0]}>
        <sphereGeometry args={[1, 8, 6]} />
      </instancedMesh>

      {/* scan sweep across the die */}
      <ScanSweep index={index} />

      {PACKAGE_PARTS.map((p) => (
        <Html
          key={`t-${p.id}`}
          position={[2.6, (EXPLODED[p.id] ?? 0) * (exploded ? 1 : 0.4), 0]}
          style={{ pointerEvents: "none" }}
          zIndexRange={[18, 0]}
        >
          <button
            onClick={() => selectPart(selected === p.id ? null : p.id)}
            className="pointer-events-auto whitespace-nowrap font-mono text-[9px] tracking-[0.22em] uppercase transition-opacity"
            style={{
              color: selected === p.id ? p.accent : "rgba(249,249,249,0.42)",
              textShadow: "0 2px 10px rgba(0,0,0,0.9)",
            }}
          >
            {selected === p.id ? "◈ " : "◇ "}
            {p.label}
          </button>
        </Html>
      ))}
    </group>
  );
}

/** A thin luminous plane sweeping the die — inspection scan. */
function ScanSweep({ index }: { index: number }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    const m = ref.current;
    if (!m) return;
    const t = (state.clock.elapsedTime * 0.35) % 3;
    m.position.x = -2.4 + t * 1.7;
    const mat = m.material as THREE.MeshBasicMaterial;
    mat.opacity = 0.16 * (motion.reveal[index] ?? 0);
  });
  return (
    <mesh ref={ref} position={[0, 0.9, 0]} rotation={[-Math.PI / 2, 0, 0]}>
      <planeGeometry args={[0.35, 4.4]} />
      <meshBasicMaterial
        color={COLORS.sig}
        transparent
        opacity={0.16}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
        toneMapped={false}
      />
    </mesh>
  );
}

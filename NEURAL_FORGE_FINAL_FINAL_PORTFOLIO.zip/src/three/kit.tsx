import { useEffect, useMemo, useRef, type ReactNode } from "react";
import { useFrame } from "@react-three/fiber";
import { Html } from "@react-three/drei";
import * as THREE from "three";
import { motion } from "@/state/store";
import { clamp, smoothstep } from "@/lib/math";
import { createCellMaterial } from "@/three/materials";

/* ==================================================================
 * 3D KIT — small reusable building blocks shared by every chapter.
 * ================================================================== */

/** Mounts/animates a chapter scene: visibility + scale driven by the rig. */
export function Reveal({
  index,
  children,
  scaleFrom = 0.93,
}: {
  index: number;
  children: ReactNode;
  scaleFrom?: number;
}) {
  const ref = useRef<THREE.Group>(null);
  useFrame(() => {
    const g = ref.current;
    if (!g) return;
    const r = motion.reveal[index] ?? 0;
    const visible = r > 0.015;
    if (g.visible !== visible) g.visible = visible;
    if (visible) {
      const s = scaleFrom + (1 - scaleFrom) * r;
      if (Math.abs(g.scale.x - s) > 0.002) g.scale.setScalar(s);
    }
  });
  return <group ref={ref}>{children}</group>;
}

/** Mono 3D-anchored annotation. */
export function Tag({
  position,
  children,
  color = "rgba(56,189,248,0.9)",
  align = "center",
}: {
  position: [number, number, number];
  children: ReactNode;
  color?: string;
  align?: "center" | "left";
}) {
  return (
    <Html position={position} center={align === "center"} style={{ pointerEvents: "none" }} zIndexRange={[20, 0]}>
      <div
        className="whitespace-nowrap font-mono text-[9px] tracking-[0.22em] uppercase"
        style={{ color, textShadow: "0 0 12px rgba(0,0,0,0.9)" }}
      >
        {children}
      </div>
    </Html>
  );
}

/** Subscribes a list of materials to the chapter reveal value. */
export function useRevealOpacity(index: number, materials: (THREE.Material | undefined | null)[]) {
  useFrame(() => {
    const r = motion.reveal[index] ?? 0;
    for (const m of materials) {
      if (!m) continue;
      const anyMat = m as unknown as { opacity: number; uOpacity?: { value: number } };
      if (anyMat.uOpacity) anyMat.uOpacity.value = r;
      else if ("opacity" in m) (m as THREE.Material & { opacity: number }).opacity = r;
    }
  });
}

/** Standard-metal helper */
export function useMetal(color: string, opts: { metalness?: number; roughness?: number } = {}) {
  return useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color,
        metalness: opts.metalness ?? 0.92,
        roughness: opts.roughness ?? 0.28,
        envMapIntensity: 1.1,
      }),
    [color, opts.metalness, opts.roughness]
  );
}

/* ---------------- instanced cell field ---------------- */

export interface CellFieldOptions {
  count: number;
  base?: "box" | "octa" | "plane";
  size?: [number, number, number];
  progress?: number;
  speed?: number;
}

export function createCellField(opts: CellFieldOptions) {
  const geo =
    opts.base === "octa"
      ? new THREE.OctahedronGeometry(0.5, 0)
      : opts.base === "plane"
        ? new THREE.PlaneGeometry(1, 1)
        : new THREE.BoxGeometry(1, 1, 1);
  geo.scale(opts.size?.[0] ?? 1, opts.size?.[1] ?? 1, opts.size?.[2] ?? 1);
  const tint = new Float32Array(opts.count * 3);
  const anim = new Float32Array(opts.count * 3);
  geo.setAttribute("aTint", new THREE.InstancedBufferAttribute(tint, 3));
  geo.setAttribute("aAnim", new THREE.InstancedBufferAttribute(anim, 3));
  const mat = createCellMaterial({ progress: opts.progress, speed: opts.speed });
  return { geometry: geo, material: mat, tint, anim };
}

export function writeTint(attr: THREE.InstancedBufferAttribute, i: number, c: THREE.Color, scale = 1) {
  const a = attr.array as Float32Array;
  a[i * 3] = c.r * scale;
  a[i * 3 + 1] = c.g * scale;
  a[i * 3 + 2] = c.b * scale;
}

/* ---------------- instanced flow field ---------------- */

export interface FlowPath {
  start: [number, number, number];
  end: [number, number, number];
  tint: THREE.Color;
  speed: number;
  size: number;
}

export function createFlowField(paths: FlowPath[], base?: THREE.BufferGeometry) {
  const proto = base ?? new THREE.SphereGeometry(0.05, 6, 5);
  const g = new THREE.InstancedBufferGeometry();
  g.index = proto.index;
  g.setAttribute("position", proto.attributes.position);
  g.setAttribute("normal", proto.attributes.normal);
  const start = new Float32Array(paths.length * 3);
  const end = new Float32Array(paths.length * 3);
  const tint = new Float32Array(paths.length * 3);
  const meta = new Float32Array(paths.length * 3);
  paths.forEach((p, i) => {
    start.set(p.start, i * 3);
    end.set(p.end, i * 3);
    tint.set([p.tint.r, p.tint.g, p.tint.b], i * 3);
    meta.set([Math.random(), p.speed, p.size], i * 3);
  });
  g.setAttribute("aStart", new THREE.InstancedBufferAttribute(start, 3));
  g.setAttribute("aEnd", new THREE.InstancedBufferAttribute(end, 3));
  g.setAttribute("aTint", new THREE.InstancedBufferAttribute(tint, 3));
  g.setAttribute("aMeta", new THREE.InstancedBufferAttribute(meta, 3));
  g.instanceCount = paths.length;
  g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);
  return g;
}

export interface CellPlace {
  p: [number, number, number];
  s?: [number, number, number];
  r?: [number, number, number];
}

/** Instanced glowing structure. Matrices are written once; all animation
 *  (birth, pulse, fade) happens on the GPU inside the cell shader. */
export function Cells({
  field,
  count,
  progress,
  speed = 3,
  write,
  place,
}: {
  field: ReturnType<typeof createCellField>;
  count: number;
  progress?: number;
  speed?: number;
  write?: (api: { tint: Float32Array; anim: Float32Array }) => void;
  place?: (i: number) => CellPlace;
}) {
  const ref = useRef<THREE.InstancedMesh>(null);

  useEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const e = new THREE.Euler();
    const v = new THREE.Vector3();
    const s = new THREE.Vector3();
    for (let i = 0; i < count; i++) {
      const c = place?.(i) ?? { p: [0, 0, 0] as [number, number, number] };
      e.set(c.r?.[0] ?? 0, c.r?.[1] ?? 0, c.r?.[2] ?? 0);
      q.setFromEuler(e);
      v.set(c.p[0], c.p[1], c.p[2]);
      s.set(c.s?.[0] ?? 1, c.s?.[1] ?? 1, c.s?.[2] ?? 1);
      m.compose(v, q, s);
      mesh.setMatrixAt(i, m);
    }
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
    mesh.frustumCulled = false;
    write?.({ tint: field.tint, anim: field.anim });
    (field.geometry.getAttribute("aTint") as THREE.InstancedBufferAttribute).needsUpdate = true;
    (field.geometry.getAttribute("aAnim") as THREE.InstancedBufferAttribute).needsUpdate = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [count, field, place, write]);

  useEffect(
    () => () => {
      field.geometry.dispose();
      field.material.dispose();
    },
    [field]
  );

  useFrame((state) => {
    const u = field.material.uniforms;
    u.uTime.value = state.clock.elapsedTime;
    if (progress !== undefined) u.uProgress.value = progress;
    u.uSpeed.value = speed;
  });

  return <instancedMesh ref={ref} args={[field.geometry, field.material, count]} frustumCulled={false} />;
}

/** Fade helper for scroll-windowed sub-scenes inside one chapter. */
export function windowFade(p: number, a: number, b: number, feather = 0.12) {
  const up = smoothstep((p - a + feather) / feather);
  const down = 1 - smoothstep((p - b) / feather);
  return clamp(Math.min(up, down));
}

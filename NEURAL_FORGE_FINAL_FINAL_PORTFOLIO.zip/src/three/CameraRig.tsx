import { useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { CHAPTERS, BACKDROP_MODE, COLORS, QUALITY_PROFILE } from "@/lib/constants";
import { clamp, damp, lerp, plateau, smoothstep } from "@/lib/math";
import { motion, useUI } from "@/state/store";
import { createDustMaterial } from "@/three/materials";
import { rng } from "@/lib/math";

/* ==================================================================
 * CAMERA RIG — the continuous descent.
 * Chapter poses are scene-local; the rig interpolates between them and
 * offsets by each chapter's world depth so the journey is one unbroken
 * camera move (no teleporting, no section snapping).
 * ================================================================== */

const tmpPos = new THREE.Vector3();
const tmpLook = new THREE.Vector3();
const tmpOffset = new THREE.Vector3();
const spherical = new THREE.Spherical();

export function CameraRig({ backdrop }: { backdrop: THREE.ShaderMaterial }) {
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera;
  const size = useThree((s) => s.size);
  const look = useRef(new THREE.Vector3(0, 0, 10));
  const posRef = useRef(new THREE.Vector3(0, 3, 16));
  const fovRef = useRef(44);
  const modeRef = useRef(0);
  const fadeRef = useRef(0);
  const started = useRef(false);

  useFrame((state, dt) => {
    const st = useUI.getState();
    const reduced = st.reducedMotion;
    const i = clamp(Math.floor(motion.camT), 0, CHAPTERS.length - 1);
    const j = Math.min(i + 1, CHAPTERS.length - 1);
    const t = plateau(motion.camT - i, 0.06, 0.94);
    const mobile = size.width < 860;
    const A = CHAPTERS[i];
    const B = CHAPTERS[j];
    const pa = mobile ? A.mobileCam : A.cam;
    const pb = mobile ? B.mobileCam : B.cam;
    const depth = lerp(A.depth, B.depth, t);

    tmpPos.set(
      lerp(pa.pos[0], pb.pos[0], t),
      lerp(pa.pos[1], pb.pos[1], t) + depth,
      lerp(pa.pos[2], pb.pos[2], t)
    );
    tmpLook.set(
      lerp(pa.look[0], pb.look[0], t),
      lerp(pa.look[1], pb.look[1], t) + depth,
      lerp(pa.look[2], pb.look[2], t)
    );

    // ---- user-controlled orbit (drag) ----
    if (!motion.dragging) motion.azTarget = damp(motion.azTarget, 0, 0.5, dt);
    motion.az = damp(motion.az, motion.azTarget, 4.5, dt);
    motion.pol = damp(motion.pol, motion.polTarget, 4.5, dt);
    tmpOffset.copy(tmpPos).sub(tmpLook);
    spherical.setFromVector3(tmpOffset);
    spherical.theta += motion.az;
    spherical.phi = clamp(spherical.phi + motion.pol, 0.22, Math.PI - 0.22);
    tmpOffset.setFromSpherical(spherical);
    tmpPos.copy(tmpLook).add(tmpOffset);

    // ---- pointer parallax ----
    const par = reduced ? 0 : 1;
    tmpPos.x += motion.px * 0.9 * par;
    tmpPos.y += -motion.py * 0.55 * par;
    tmpLook.x += motion.px * 0.22 * par;
    tmpLook.y += -motion.py * 0.14 * par;

    // ---- damped integration ----
    if (!started.current) {
      started.current = true;
      posRef.current.copy(tmpPos);
      look.current.copy(tmpLook);
    }
    const lambda = reduced ? 2.2 : 3.1;
    posRef.current.x = damp(posRef.current.x, tmpPos.x, lambda, dt);
    posRef.current.y = damp(posRef.current.y, tmpPos.y, lambda, dt);
    posRef.current.z = damp(posRef.current.z, tmpPos.z, lambda, dt);
    look.current.x = damp(look.current.x, tmpLook.x, lambda + 0.6, dt);
    look.current.y = damp(look.current.y, tmpLook.y, lambda + 0.6, dt);
    look.current.z = damp(look.current.z, tmpLook.z, lambda + 0.6, dt);

    camera.position.copy(posRef.current);
    camera.lookAt(look.current);

    const targetFov = lerp(pa.fov, pb.fov, t);
    fovRef.current = damp(fovRef.current, targetFov, 3, dt);
    if (Math.abs(camera.fov - fovRef.current) > 0.01) {
      camera.fov = fovRef.current;
      camera.updateProjectionMatrix();
    }

    // ---- reveal weights consumed by every scene ----
    for (let k = 0; k < CHAPTERS.length; k++) {
      const d = Math.abs(motion.camT - k);
      motion.reveal[k] = 1 - smoothstep((d - 0.08) / 0.62);
    }

    // ---- backdrop program + energy ----
    const chapter = CHAPTERS[Math.round(clamp(motion.camT, 0, CHAPTERS.length - 1))];
    const modeTarget = BACKDROP_MODE[chapter.id] ?? 0;
    if (modeTarget !== modeRef.current) fadeRef.current = Math.max(0, fadeRef.current - dt * 2.2);
    else fadeRef.current = Math.min(1, fadeRef.current + dt * 1.4);
    if (fadeRef.current <= 0.001 && modeTarget !== modeRef.current) modeRef.current = modeTarget;

    const lab = st.lab;
    let energy = 0.4;
    if (chapter.id === "transistor") energy = 0.15 + st.gate * 0.85;
    else if (chapter.id === "engine") energy = 0.55;
    else if (chapter.id === "memory") energy = 0.2 + clamp(st.bandwidth / 1.6) * 0.8;
    else if (chapter.id === "vlsi") energy = 0.25 + clamp(motion.stageF / 7) * 0.75;
    else if (chapter.id === "lab") energy = 0.25 + clamp(lab.cores / 256) * 0.6;
    else if (chapter.id === "ignition") energy = 0.45;
    motion.energy = damp(motion.energy, energy, 3, dt);

    const u = backdrop.uniforms;
    u.uTime.value = state.clock.elapsedTime * (reduced ? 0.35 : 1);
    u.uMode.value = modeRef.current;
    u.uOpacity.value = damp(u.uOpacity.value, fadeRef.current * 0.85, 5, dt);
    u.uEnergy.value = motion.energy;
    u.uStatic.value = reduced ? 1 : 0;
    u.uFocus.value = clamp(1 - Math.abs(motion.velocity) * 2);
    u.uAspect.value.set(size.width / size.height, 1);
    u.uZoom.value = clamp(motion.stageF / 7);
  });

  return null;
}

/* ==================================================================
 * CINEMATIC BACKDROP — full-frame procedural footage plane that rides
 * with the camera. Additive + depth-tested so real geometry always wins.
 * ================================================================== */

const BACKDROP_DIST = 46;

export function Backdrop({ material }: { material: THREE.ShaderMaterial }) {
  const mesh = useRef<THREE.Mesh>(null);
  const camera = useThree((s) => s.camera);
  const size = useThree((s) => s.size);

  useFrame(() => {
    const m = mesh.current;
    if (!m) return;
    camera.getWorldDirection(tmpOffset);
    m.position.copy(camera.position).addScaledVector(tmpOffset, BACKDROP_DIST);
    m.quaternion.copy(camera.quaternion);
    const h = 2 * Math.tan((((camera as THREE.PerspectiveCamera).fov ?? 45) * Math.PI) / 360) * BACKDROP_DIST;
    m.scale.set(h * (size.width / size.height) * 1.15, h * 1.15, 1);
  });

  return (
    <mesh ref={mesh} renderOrder={-1000} frustumCulled={false}>
      <planeGeometry args={[1, 1]} />
      <primitive object={material} attach="material" />
    </mesh>
  );
}

/* ==================================================================
 * DESCENT SHAFT — the vertical structure the camera travels through
 * between chapters: guide lines, depth rings and atmospheric dust.
 * ================================================================== */

export function DescentShaft({ dust }: { dust: number }) {
  const material = useMemo(() => createDustMaterial(), []);
  const group = useRef<THREE.Group>(null);
  const reduced = useUI((s) => s.reducedMotion);

  const { lines, rings } = useMemo(() => {
    const rand = rng(4242);
    const maxDepth = CHAPTERS[CHAPTERS.length - 1].depth - 26;
    const lp: number[] = [];
    const count = 150;
    for (let i = 0; i < count; i++) {
      const a = rand() * Math.PI * 2;
      const r = 11 + rand() * 12;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      const y0 = 18 - rand() * Math.abs(maxDepth);
      const len = 6 + rand() * 26;
      lp.push(x, y0, z, x, y0 - len, z);
    }
    const ringPos: number[] = [];
    const SEG = 96;
    for (const c of CHAPTERS) {
      const y = c.depth;
      for (let s = 0; s < SEG; s++) {
        const a0 = (s / SEG) * Math.PI * 2;
        const a1 = ((s + 1) / SEG) * Math.PI * 2;
        const r = 9.5;
        ringPos.push(Math.cos(a0) * r, y, Math.sin(a0) * r, Math.cos(a1) * r, y, Math.sin(a1) * r);
      }
    }
    return {
      lines: new Float32Array(lp),
      rings: new Float32Array(ringPos),
    };
  }, []);

  const dustGeo = useMemo(() => {
    const rand = rng(777);
    const pos = new Float32Array(dust * 3);
    const seed = new Float32Array(dust);
    const size = new Float32Array(dust);
    const maxDepth = Math.abs(CHAPTERS[CHAPTERS.length - 1].depth) + 30;
    for (let i = 0; i < dust; i++) {
      const a = rand() * Math.PI * 2;
      const r = 4 + rand() * 16;
      pos[i * 3] = Math.cos(a) * r;
      pos[i * 3 + 1] = -rand() * maxDepth;
      pos[i * 3 + 2] = Math.sin(a) * r;
      seed[i] = rand();
      size[i] = 1 + rand() * 3.5;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.setAttribute("aSeed", new THREE.BufferAttribute(seed, 1));
    g.setAttribute("aSize", new THREE.BufferAttribute(size, 1));
    return g;
  }, [dust]);

  useFrame((state, dt) => {
    const u = material.uniforms;
    u.uTime.value = state.clock.elapsedTime;
    u.uStatic.value = reduced ? 1 : 0;
    // dust density peaks while travelling between chapters
    const frac = Math.abs(motion.camT - Math.round(motion.camT));
    const travel = smoothstep((frac - 0.18) / 0.32);
    u.uOpacity.value = damp(u.uOpacity.value, 0.12 + travel * 0.55, 4, dt);
    if (group.current) group.current.rotation.y = state.clock.elapsedTime * 0.012;
    void dt;
  });

  return (
    <group ref={group}>
      <lineSegments frustumCulled={false}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[lines, 3]} />
        </bufferGeometry>
        <lineBasicMaterial
          color={COLORS.sig}
          transparent
          opacity={0.075}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
          toneMapped={false}
        />
      </lineSegments>
      <lineSegments frustumCulled={false}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[rings, 3]} />
        </bufferGeometry>
        <lineBasicMaterial
          color={COLORS.violet}
          transparent
          opacity={0.14}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
          toneMapped={false}
        />
      </lineSegments>
      <points geometry={dustGeo} frustumCulled={false}>
        <primitive object={material} attach="material" />
      </points>
    </group>
  );
}

/* ==================================================================
 * LIGHTING — one rig for the whole descent, tuned dark but readable
 * ================================================================== */

export function Lighting({ shadows }: { shadows: boolean }) {
  const key = useRef<THREE.DirectionalLight>(null);
  const rim = useRef<THREE.PointLight>(null);
  const fill = useRef<THREE.PointLight>(null);

  useFrame((state, dt) => {
    const t = state.clock.elapsedTime;
    const depth = motion.camT * 1;
    if (key.current) {
      key.current.position.set(-9 + Math.sin(t * 0.1) * 2, 14 - depth * 0 + 0, 9);
      key.current.target.position.set(0, CHAPTERS[Math.round(motion.camT)]?.depth ?? 0, 0);
      key.current.target.updateMatrixWorld();
    }
    if (rim.current) {
      const c = CHAPTERS[Math.round(clamp(motion.camT, 0, CHAPTERS.length - 1))];
      rim.current.position.set(0, c.depth + 4.5, -7);
      rim.current.color.set(
        c.id === "engine" || c.id === "memory" ? COLORS.violet : c.id === "memory" ? COLORS.magenta : COLORS.sig
      );
    }
    if (fill.current) {
      const c = CHAPTERS[Math.round(clamp(motion.camT, 0, CHAPTERS.length - 1))];
      fill.current.position.set(6, c.depth + 3, 6);
      fill.current.intensity = damp(fill.current.intensity, 26, 3, dt);
    }
  });

  return (
    <>
      <ambientLight intensity={0.14} color="#93c5fd" />
      <directionalLight
        ref={key}
        position={[-9, 14, 9]}
        intensity={2.6}
        color="#dbeafe"
        castShadow={shadows}
        shadow-mapSize={[1024, 1024]}
        shadow-bias={-0.0004}
      />
      <pointLight ref={rim} position={[0, 4, -7]} intensity={70} distance={40} decay={2} color={COLORS.sig} />
      <pointLight ref={fill} position={[6, 3, 6]} intensity={26} distance={34} decay={2} color={COLORS.violet} />
      <hemisphereLight args={["#1e293b", "#020617", 0.5]} />
    </>
  );
}

/** Instanced helper budget accessor for scenes */
export const budgetFor = (q: keyof typeof QUALITY_PROFILE) => QUALITY_PROFILE[q];

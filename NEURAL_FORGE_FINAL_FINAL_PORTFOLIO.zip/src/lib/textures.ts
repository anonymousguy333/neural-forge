import * as THREE from "three";
import { rng } from "@/lib/math";

/* ==================================================================
 * PROCEDURAL TEXTURES — drawn once into <canvas>, reused as maps +
 * emissive maps. Zero network fetches, deterministic output.
 * ================================================================== */

function makeCanvas(size: number, h = size) {
  const c = document.createElement("canvas");
  c.width = size;
  c.height = h;
  const ctx = c.getContext("2d")!;
  return { c, ctx };
}

function finish(c: HTMLCanvasElement, repeat: [number, number] = [1, 1]) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat[0], repeat[1]);
  t.anisotropy = 4;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** Wafer top face: die grid + per-die routing suggestion */
export function waferTexture(size = 1024, dies = 22) {
  const { c, ctx } = makeCanvas(size);
  const rand = rng(11);
  ctx.fillStyle = "#0b0e12";
  ctx.fillRect(0, 0, size, size);
  const cell = size / dies;
  for (let i = 0; i < dies; i++) {
    for (let j = 0; j < dies; j++) {
      const x = i * cell;
      const y = j * cell;
      ctx.fillStyle = `rgba(${12 + rand() * 14 | 0},${18 + rand() * 20 | 0},${26 + rand() * 24 | 0},1)`;
      ctx.fillRect(x + 1, y + 1, cell - 2, cell - 2);
      // inner blocks
      const blocks = 3 + Math.floor(rand() * 4);
      for (let b = 0; b < blocks; b++) {
        const bw = cell * (0.15 + rand() * 0.5);
        const bh = cell * (0.1 + rand() * 0.4);
        const bx = x + rand() * (cell - bw);
        const by = y + rand() * (cell - bh);
        const hue = rand();
        ctx.fillStyle =
          hue > 0.72
            ? `rgba(120,90,${180 + rand() * 60 | 0},0.5)`
            : hue > 0.4
              ? `rgba(${40 + rand() * 40 | 0},${150 + rand() * 80 | 0},${200 + rand() * 50 | 0},0.42)`
              : `rgba(${30 + rand() * 20 | 0},${60 + rand() * 30 | 0},${80 + rand() * 30 | 0},0.4)`;
        ctx.fillRect(bx, by, bw, bh);
      }
      // traces
      ctx.strokeStyle = `rgba(150,${200 + rand() * 40 | 0},255,${0.06 + rand() * 0.16})`;
      ctx.lineWidth = Math.max(1, cell * 0.012);
      ctx.beginPath();
      let px = x + rand() * cell;
      let py = y + rand() * cell;
      ctx.moveTo(px, py);
      for (let s = 0; s < 4; s++) {
        if (rand() > 0.5) px = x + rand() * cell;
        else py = y + rand() * cell;
        ctx.lineTo(px, py);
      }
      ctx.stroke();
      // grid line
      ctx.strokeStyle = "rgba(120,180,230,0.14)";
      ctx.lineWidth = 1;
      ctx.strokeRect(x + 0.5, y + 0.5, cell, cell);
    }
  }
  return finish(c, [2, 2]);
}

/** Compute die face: standard cell rows + macro blocks */
export function dieTexture(size = 1024, seed = 3) {
  const { c, ctx } = makeCanvas(size);
  const rand = rng(seed);
  ctx.fillStyle = "#0d1015";
  ctx.fillRect(0, 0, size, size);
  // standard cell rows
  const rows = 78;
  const rh = size / rows;
  for (let r = 0; r < rows; r++) {
    let x = 0;
    while (x < size) {
      const w = rh * (0.5 + rand() * 2.2);
      const hue = rand();
      ctx.fillStyle =
        hue > 0.94
          ? "rgba(90,220,255,0.55)"
          : hue > 0.8
            ? "rgba(140,110,255,0.4)"
            : `rgba(${40 + rand() * 26 | 0},${52 + rand() * 26 | 0},${66 + rand() * 30 | 0},0.85)`;
      ctx.fillRect(x, r * rh, w - 1, rh - 1.5);
      x += w;
    }
    ctx.fillStyle = "rgba(120,200,255,0.05)";
    ctx.fillRect(0, r * rh, size, 1);
  }
  // macro blocks (caches / tiles)
  const macros = 7;
  for (let m = 0; m < macros; m++) {
    const w = size * (0.14 + rand() * 0.24);
    const h = size * (0.12 + rand() * 0.26);
    const x = rand() * (size - w);
    const y = rand() * (size - h);
    ctx.fillStyle = rand() > 0.5 ? "rgba(20,42,58,0.95)" : "rgba(34,26,52,0.95)";
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = rand() > 0.5 ? "rgba(56,189,248,0.5)" : "rgba(139,92,246,0.45)";
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);
    // internal fins
    const fins = 10 + Math.floor(rand() * 20);
    ctx.strokeStyle = "rgba(140,210,255,0.12)";
    ctx.lineWidth = 1;
    for (let f = 0; f < fins; f++) {
      const fx = x + (f / fins) * w;
      ctx.beginPath();
      ctx.moveTo(fx, y);
      ctx.lineTo(fx, y + h);
      ctx.stroke();
    }
  }
  // top-level routing
  for (let i = 0; i < 90; i++) {
    ctx.strokeStyle = `rgba(${rand() > 0.7 ? "180,120,255" : "90,200,255"},${0.1 + rand() * 0.3})`;
    ctx.lineWidth = rand() > 0.8 ? 3 : 1.4;
    ctx.beginPath();
    const horiz = rand() > 0.5;
    let px = rand() * size;
    let py = rand() * size;
    ctx.moveTo(px, py);
    for (let s = 0; s < 3; s++) {
      if (horiz) px = rand() * size;
      else py = rand() * size;
      ctx.lineTo(px, py);
    }
    ctx.stroke();
  }
  return finish(c);
}

/** Package substrate: fan-out gold traces + vias */
export function substrateTexture(size = 1024, seed = 9) {
  const { c, ctx } = makeCanvas(size);
  const rand = rng(seed);
  ctx.fillStyle = "#101613";
  ctx.fillRect(0, 0, size, size);
  for (let i = 0; i < 260; i++) {
    ctx.strokeStyle = `rgba(${210 + rand() * 40 | 0},${170 + rand() * 50 | 0},${100 + rand() * 40 | 0},${0.08 + rand() * 0.22})`;
    ctx.lineWidth = 1 + rand() * 2.5;
    ctx.beginPath();
    const y = rand() * size;
    ctx.moveTo(0, y);
    let x = 0;
    let cy = y;
    while (x < size) {
      x += size * (0.04 + rand() * 0.1);
      cy += (rand() - 0.5) * size * 0.12;
      ctx.lineTo(x, cy);
    }
    ctx.stroke();
  }
  for (let i = 0; i < 400; i++) {
    ctx.fillStyle = `rgba(230,200,140,${0.1 + rand() * 0.4})`;
    ctx.beginPath();
    ctx.arc(rand() * size, rand() * size, 1 + rand() * 2.4, 0, Math.PI * 2);
    ctx.fill();
  }
  return finish(c);
}

/** Dense VLSI layout used on the foundry die + accelerator floorplan */
export function layoutTexture(size = 1024, density = 1, seed = 21) {
  const { c, ctx } = makeCanvas(size);
  const rand = rng(seed);
  ctx.fillStyle = "#080a0d";
  ctx.fillRect(0, 0, size, size);
  const regions = 12;
  for (let r = 0; r < regions; r++) {
    const w = size * (0.16 + rand() * 0.3);
    const h = size * (0.12 + rand() * 0.28);
    const x = rand() * (size - w);
    const y = rand() * (size - h);
    const violet = rand() > 0.55;
    ctx.fillStyle = violet ? "rgba(48,34,84,0.9)" : "rgba(18,44,62,0.9)";
    ctx.fillRect(x, y, w, h);
    // cell rows
    const rows = Math.floor(6 + rand() * 16 * density);
    for (let i = 0; i < rows; i++) {
      let cx = x;
      const rh = h / rows;
      while (cx < x + w) {
        const cw = rh * (0.6 + rand() * 2.4);
        ctx.fillStyle = violet
          ? `rgba(${120 + rand() * 60 | 0},${80 + rand() * 50 | 0},255,${0.12 + rand() * 0.3})`
          : `rgba(${40 + rand() * 40 | 0},${170 + rand() * 70 | 0},255,${0.1 + rand() * 0.3})`;
        ctx.fillRect(cx, y + i * rh, cw - 1, rh - 1);
        cx += cw;
      }
    }
    ctx.strokeStyle = violet ? "rgba(150,110,255,0.3)" : "rgba(70,190,255,0.3)";
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x, y, w, h);
  }
  // routing
  const segs = Math.floor(160 * density);
  for (let i = 0; i < segs; i++) {
    const horiz = rand() > 0.5;
    const w = horiz ? size * (0.03 + rand() * 0.22) : 2 + rand() * 3;
    const h = horiz ? 2 + rand() * 3 : size * (0.03 + rand() * 0.22);
    ctx.fillStyle =
      rand() > 0.9
        ? `rgba(245,158,11,${0.4 + rand() * 0.5})`
        : rand() > 0.75
          ? `rgba(139,92,246,${0.3 + rand() * 0.5})`
          : `rgba(56,189,248,${0.2 + rand() * 0.55})`;
    ctx.fillRect(rand() * size, rand() * size, w, h);
  }
  return finish(c);
}

/** HBM stack side: thin die layers with TSV hint */
export function stackTexture(size = 512, layers = 8, color = "139,92,246") {
  const { c, ctx } = makeCanvas(size, Math.round(size * 0.6));
  ctx.fillStyle = "#0c0d12";
  ctx.fillRect(0, 0, c.width, c.height);
  const lh = c.height / layers;
  for (let i = 0; i < layers; i++) {
    ctx.fillStyle = `rgba(${color},${0.16 + (i % 2) * 0.12})`;
    ctx.fillRect(0, i * lh + 1, c.width, lh - 3);
    ctx.fillStyle = "rgba(180,220,255,0.18)";
    ctx.fillRect(0, i * lh, c.width, 1);
  }
  // TSV columns
  for (let x = 0; x < c.width; x += 12) {
    ctx.fillStyle = "rgba(120,200,255,0.14)";
    ctx.fillRect(x, 0, 2, c.height);
  }
  return finish(c);
}

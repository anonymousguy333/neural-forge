import waferImg from "@/assets/media/wafer.jpg";
import dieImg from "@/assets/media/die.jpg";
import transistorImg from "@/assets/media/transistor.jpg";
import neuralImg from "@/assets/media/neural.jpg";
import memoryImg from "@/assets/media/memory.jpg";
import vlsiImg from "@/assets/media/vlsi.jpg";

/** ------------------------------------------------------------------
 *  CENTRAL CONSTANTS — colour system, chapter map, camera keys, copy.
 *  ------------------------------------------------------------------ */

export const COLORS = {
  void: "#0a0a0b",
  ink: "#F9F9F9",
  sig: "#38bdf8",
  sigDeep: "#0ea5e9",
  emerald: "#10b981",
  amber: "#f59e0b",
  red: "#ef4444",
  violet: "#8b5cf6",
  magenta: "#d946ef",
  graphite: "#1a1a1d",
  silicon: "#6b7280",
  copper: "#c98a5a",
  gold: "#d9b06a",
} as const;

export type Quality = "low" | "medium" | "high";

export const QUALITY_PROFILE: Record<
  Quality,
  { dpr: [number, number]; dies: number; cells: number; pulses: number; nodes: number; dust: number; shadows: boolean }
> = {
  low: { dpr: [0.7, 1], dies: 90, cells: 520, pulses: 90, nodes: 24, dust: 240, shadows: false },
  medium: { dpr: [0.85, 1.35], dies: 170, cells: 1150, pulses: 190, nodes: 40, dust: 520, shadows: false },
  high: { dpr: [1, 1.85], dies: 300, cells: 2100, pulses: 320, nodes: 62, dust: 900, shadows: true },
};

export interface ChapterDef {
  id: string;
  index: string;
  nav: string;
  title: string;
  kicker: string;
  /** world Y anchor of the chapter scene (the descent) */
  depth: number;
  /** camera pose in scene-local space */
  cam: { pos: [number, number, number]; look: [number, number, number]; fov: number };
  mobileCam: { pos: [number, number, number]; look: [number, number, number]; fov: number };
  media: string;
  mediaBlend: string;
  modeLabel: string;
}

export const CHAPTERS: ChapterDef[] = [
  {
    id: "ignition",
    index: "00",
    nav: "IGNITION",
    title: "NEURAL//FORGE",
    kicker: "WHERE INTELLIGENCE BECOMES HARDWARE",
    depth: 0,
    cam: { pos: [0, 2.6, 13.4], look: [0, 0.6, 0], fov: 42 },
    mobileCam: { pos: [0, 3.2, 16.5], look: [0, 0.8, 0], fov: 50 },
    media: waferImg,
    mediaBlend: "screen",
    modeLabel: "WAFER / MACRO PASS",
  },
  {
    id: "chip",
    index: "01",
    nav: "THE CHIP",
    title: "DISASSEMBLE THE PACKAGE",
    kicker: "SUBSTRATE · DIE · INTERCONNECT · MEMORY",
    depth: -34,
    cam: { pos: [6.4, 3.4, 7.6], look: [0, 0.1, 0], fov: 38 },
    mobileCam: { pos: [5.6, 4.2, 11.5], look: [0, 0.4, 0], fov: 46 },
    media: dieImg,
    mediaBlend: "screen",
    modeLabel: "DIE DESCENT / MACRO PASS",
  },
  {
    id: "transistor",
    index: "02",
    nav: "TRANSISTOR",
    title: "ONE SWITCH",
    kicker: "GATE · SOURCE · DRAIN · CHANNEL",
    depth: -68,
    cam: { pos: [2.6, 1.25, 3.9], look: [0, 0.32, 0], fov: 40 },
    mobileCam: { pos: [1.9, 1.6, 5.4], look: [0, 0.3, 0], fov: 48 },
    media: transistorImg,
    mediaBlend: "screen",
    modeLabel: "TRANSISTOR / MICRO PASS",
  },
  {
    id: "engine",
    index: "03",
    nav: "AI ENGINE",
    title: "MATH BECOMES MOTION",
    kicker: "LAYERS · MATMUL · CPU / GPU / NPU",
    depth: -104,
    cam: { pos: [0.2, 2.1, 13.2], look: [0, 0.2, 0], fov: 44 },
    mobileCam: { pos: [0, 2.4, 17.5], look: [0, 0.4, 0], fov: 52 },
    media: neuralImg,
    mediaBlend: "screen",
    modeLabel: "NEURAL COMPUTATION PASS",
  },
  {
    id: "memory",
    index: "04",
    nav: "MEMORY",
    title: "THE MEMORY WALL",
    kicker: "REGISTERS · CACHE · DRAM · HBM",
    depth: -140,
    cam: { pos: [-8.2, 3.6, 11.4], look: [-0.6, 0.9, 0], fov: 42 },
    mobileCam: { pos: [-5.4, 4.6, 15.5], look: [-0.6, 1.2, 0], fov: 50 },
    media: memoryImg,
    mediaBlend: "screen",
    modeLabel: "MEMORY STREAM PASS",
  },
  {
    id: "vlsi",
    index: "05",
    nav: "VLSI",
    title: "RTL BECOMES PHYSICAL",
    kicker: "SYNTHESIS · PLACE · ROUTE · TIMING · GDSII",
    depth: -178,
    cam: { pos: [0.4, 9.4, 8.6], look: [0, 0, 0], fov: 40 },
    mobileCam: { pos: [0.2, 12.5, 11.5], look: [0, 0, 0], fov: 48 },
    media: vlsiImg,
    mediaBlend: "screen",
    modeLabel: "VLSI MORPH PASS",
  },
  {
    id: "lab",
    index: "06",
    nav: "LAB",
    title: "BUILD YOUR ACCELERATOR",
    kicker: "CORES · BANDWIDTH · PRECISION · CACHE · CLOCK",
    depth: -214,
    cam: { pos: [5.2, 5.2, 7.4], look: [0, 0.6, 0], fov: 40 },
    mobileCam: { pos: [3.4, 6.2, 11.8], look: [0, 0.8, 0], fov: 48 },
    media: dieImg,
    mediaBlend: "screen",
    modeLabel: "ACCELERATOR LOAD PASS",
  },
  {
    id: "outro",
    index: "07",
    nav: "SILICON",
    title: "SILICON IS REAL",
    kicker: "SOFTWARE IS THE IDEA · SILICON IS WHERE IT BECOMES REAL",
    depth: -248,
    cam: { pos: [0, 3.2, 15.6], look: [0, 1.1, 0], fov: 44 },
    mobileCam: { pos: [0, 3.6, 19], look: [0, 1.2, 0], fov: 52 },
    media: waferImg,
    mediaBlend: "screen",
    modeLabel: "WAFER / EXIT PASS",
  },
];

export const CHAPTER_COUNT = CHAPTERS.length;

/** Backdrop shader program per chapter (see three/glsl.ts) */
export const BACKDROP_MODE: Record<string, number> = {
  ignition: 0,
  chip: 1,
  transistor: 2,
  engine: 3,
  memory: 4,
  vlsi: 5,
  lab: 6,
  outro: 0,
};

export const NAV_CTA = "ENTER THE DIE";

export const DISCLAIMER = {
  device: "SIMPLIFIED DEVICE VISUALIZATION",
  conceptual: "CONCEPTUAL VISUALIZATION",
  normalized: "NORMALIZED EDUCATIONAL COMPARISON",
  memory: "LOW-ORDER EDUCATIONAL MEMORY MODEL",
  lab: "EDUCATIONAL FIRST-PRINCIPLES MODEL",
  noBenchmark: "NOT A BENCHMARK OF ANY COMMERCIAL ACCELERATOR",
} as const;

/** 3D package parts for chapter 01 */
export interface PackagePart {
  id: string;
  label: string;
  sub: string;
  body: string;
  color: string;
  accent: string;
}

export const PACKAGE_PARTS: PackagePart[] = [
  {
    id: "lid",
    label: "HEAT SPREADER LID",
    sub: "NICKEL-PLATED COPPER",
    body: "The mechanical and thermal interface. It spreads heat from the die into the cooler and protects brittle silicon from handling force.",
    color: "#8d939c",
    accent: "#38bdf8",
  },
  {
    id: "io",
    label: "I/O DIE",
    sub: "INTERFACE LOGIC",
    body: "Physical interface logic: PCIe / CXL lanes, memory controllers and PHYs. It speaks to the outside world so compute tiles can stay dense.",
    color: "#3f4652",
    accent: "#10b981",
  },
  {
    id: "substrate",
    label: "PACKAGE SUBSTRATE",
    sub: "MULTI-LAYER ORGANIC",
    body: "A miniature multilayer PCB. It fans thousands of die connections out to the ball grid array that carries signal and power to the board.",
    color: "#2b3a35",
    accent: "#d9b06a",
  },
  {
    id: "interposer",
    label: "SILICON INTERPOSER",
    sub: "DISTRIBUTED INTERCONNECT",
    body: "A passive silicon layer carrying micron-scale wiring. It lets compute die and memory stacks sit close enough to move data very fast.",
    color: "#4a4f5c",
    accent: "#8b5cf6",
  },
  {
    id: "die",
    label: "COMPUTE DIE",
    sub: "ADVANCED LOGIC NODE",
    body: "Physical silicon containing the circuitry responsible for computation and control: cores, caches, schedulers and the neural engine.",
    color: "#23262d",
    accent: "#38bdf8",
  },
  {
    id: "hbm",
    label: "HBM STACK",
    sub: "3D STACKED DRAM",
    body: "DRAM dies thinned, stacked and through-silicon-via connected. Very wide interface, very short distance — bandwidth bought with geometry.",
    color: "#2a2438",
    accent: "#8b5cf6",
  },
];

/** Transistor educational states */
export const TRANSISTOR_LEVELS = [
  { id: "off", label: "OFF", v: 0, note: "Channel depleted. No inversion layer — the path from source to drain is blocked." },
  { id: "half", label: "PARTIAL", v: 0.5, note: "Weak inversion. Conduction begins, current is limited and nonlinear." },
  { id: "on", label: "ON", v: 1, note: "Inversion layer formed. Carriers flow source → drain: the switch conducts." },
] as const;

/** Memory hierarchy — educational orders of magnitude, not vendor data. */
export const MEMORY_LEVELS = [
  { id: "reg", label: "REGISTERS", latency: 1, capacity: "BYTES", bw: 1.0, color: "#38bdf8", note: "Inside the execution unit. Zero distance, zero tolerance for misses." },
  { id: "l1", label: "L1 CACHE", latency: 4, capacity: "KILOBYTES", bw: 0.72, color: "#22d3ee", note: "SRAM next to the pipeline. Answers in a handful of cycles." },
  { id: "l2", label: "L2 CACHE", latency: 14, capacity: "KILOBYTES–MB", bw: 0.48, color: "#8b5cf6", note: "Shared SRAM. Larger, slower, still on the same die." },
  { id: "hbm", label: "HBM STACK", latency: 120, capacity: "GIGABYTES", bw: 0.22, color: "#d946ef", note: "Stacked DRAM on the interposer. Wide bus, still far slower than compute." },
  { id: "dram", label: "DRAM", latency: 260, capacity: "TENS OF GB", bw: 0.1, color: "#f59e0b", note: "Off-package capacitance. Every trip here costs hundreds of cycles." },
] as const;

export const VLSI_STAGES = [
  { id: "rtl", label: "RTL", note: "Behaviour described as registers and operators. No geometry exists yet — only intent." },
  { id: "synth", label: "SYNTHESIS", note: "Logic is mapped onto a technology library: the description becomes gates." },
  { id: "gate", label: "GATE LEVEL", note: "Thousands of standard cells arranged into structured rows of logic." },
  { id: "floor", label: "FLOORPLAN", note: "The die is partitioned: compute regions, memory, I/O rings, power grid." },
  { id: "place", label: "PLACEMENT", note: "Cells are given real coordinates on silicon, respecting congestion and timing." },
  { id: "route", label: "ROUTING", note: "Metal layers carry every connection. Congestion fights timing here." },
  { id: "timing", label: "TIMING ANALYSIS", note: "Every path is checked against the clock. Failing paths become critical paths." },
  { id: "gds", label: "GDSII", note: "The final layout database: layer by layer, the mask set that prints the chip." },
] as const;

export const PRECISIONS = [
  { id: "fp32", label: "FP32", bytes: 4, opsPerCycle: 1, relEnergy: 1.0, note: "Full precision. Maximum flexibility, highest data cost." },
  { id: "fp16", label: "FP16", bytes: 2, opsPerCycle: 2, relEnergy: 0.55, note: "Half precision. Halves data movement, doubles dense throughput." },
  { id: "int8", label: "INT8", bytes: 1, opsPerCycle: 4, relEnergy: 0.3, note: "Quantized inference workhorse for dense linear algebra." },
  { id: "int4", label: "INT4", bytes: 0.5, opsPerCycle: 8, relEnergy: 0.19, note: "Aggressive quantization. Highest throughput, narrowest dynamic range." },
] as const;

export type PrecisionId = (typeof PRECISIONS)[number]["id"];

export const ARCHETYPES = [
  {
    id: "cpu",
    label: "CPU",
    lanes: "DOZENS OF WIDE LANES",
    strength: "BRANCHING, CONTROL, IRREGULAR CODE",
    parallel: 0.08,
    control: 1.0,
    color: "#38bdf8",
    note: "Optimised to keep a single instruction stream correct: deep caches, speculation, out-of-order execution.",
  },
  {
    id: "gpu",
    label: "GPU",
    lanes: "THOUSANDS OF SIMPLE LANES",
    strength: "MASSIVELY PARALLEL WORKLOADS",
    parallel: 1.0,
    control: 0.32,
    color: "#10b981",
    note: "Throughput machine. Many simple lanes hide latency by switching between threads instead of predicting them.",
  },
  {
    id: "npu",
    label: "NPU / AI ACCELERATOR",
    lanes: "SYSTOLIC MAC ARRAYS",
    strength: "DENSE LINEAR ALGEBRA, LOW PRECISION",
    parallel: 1.35,
    control: 0.12,
    color: "#d946ef",
    note: "Data flows rhythmically through a grid of multiply-accumulate units so values are reused instead of re-fetched.",
  },
] as const;

/**
 * SIMULATION MODELS — pure, deterministic, first-principles functions.
 * Nothing here renders. Nothing here knows about React or THREE.
 *
 * Every model is a *normalised educational* approximation. Values are
 * relative, not vendor specifications, and never presented as benchmarks.
 */

import { PRECISIONS, MEMORY_LEVELS, type PrecisionId } from "./constants";
import { clamp } from "./math";

/* ------------------------------------------------------------------ *
 * TRANSISTOR — conceptual MOS switch
 * ------------------------------------------------------------------ */

export interface TransistorState {
  gate: number; // 0..1 normalised gate overdrive
  channel: number; // 0..1 inversion strength
  current: number; // 0..1 normalised drive current
  flow: "IDLE" | "BLOCKED" | "WEAK" | "ACTIVE";
  carriers: number; // 0..1 carrier density in channel
}

export function transistorModel(gate: number): TransistorState {
  const g = clamp(gate);
  // Conceptual threshold at ~0.28 of normalised overdrive
  const over = clamp((g - 0.28) / 0.72);
  const channel = over * over * (3 - 2 * over);
  const current = channel * (0.35 + 0.65 * g);
  const flow = channel < 0.02 ? "BLOCKED" : channel < 0.45 ? "WEAK" : "ACTIVE";
  return { gate: g, channel, current, flow, carriers: channel };
}

/* ------------------------------------------------------------------ *
 * MEMORY WALL — first-order data-movement model
 * ------------------------------------------------------------------ */

export interface MemoryState {
  /** relative bytes/s demanded by the compute side */
  demand: number;
  /** relative bytes/s the configured fabric can deliver */
  supplied: number;
  /** achieved compute utilisation 0..1 */
  utilisation: number;
  /** fraction of cycles the machine waits 0..1 */
  stall: number;
  /** queue depth behind the memory interface 0..1 */
  congestion: number;
  /** relative effective throughput */
  throughput: number;
  /** required / available bandwidth at the interface */
  memoryPressure: number;
  /** dominant level servicing traffic */
  levelIndex: number;
}

export function memoryModel(bandwidthScale: number, demand = 1): MemoryState {
  const supplied = clamp(bandwidthScale, 0.15, 1.9) * 0.62;
  const ratio = demand > 0 ? supplied / demand : 1;
  // Saturation curve: fabric delivers well until it runs out of headroom
  const utilisation = clamp(1 - Math.exp(-2.6 * ratio));
  const stall = 1 - utilisation;
  const congestion = clamp(Math.pow(clamp(1 - ratio + 0.15), 1.35) * 1.25);
  const throughput = supplied * utilisation;
  const levelIndex = ratio > 0.92 ? 1 : ratio > 0.62 ? 2 : ratio > 0.3 ? 3 : 4;
  const memoryPressure = demand > 0 ? demand / Math.max(supplied, 1e-3) : 0;
  return { demand, supplied, utilisation, stall, congestion, throughput, levelIndex, memoryPressure };
}

/** Educational latency ladder (relative cycles) */
export const memoryLatency = MEMORY_LEVELS.map((l) => l.latency);

/* ------------------------------------------------------------------ *
 * NEURAL ENGINE — tiny deterministic matrix-multiply for stage 03
 * ------------------------------------------------------------------ */

export const MAT_N = 4;

export function matmulValues(seed = 7): { a: number[][]; b: number[][]; c: number[][] } {
  let s = seed;
  const rnd = () => {
    s = (s * 1103515245 + 12345) % 2147483648;
    return s / 2147483648;
  };
  const a: number[][] = [];
  const b: number[][] = [];
  for (let i = 0; i < MAT_N; i++) {
    a.push(Array.from({ length: MAT_N }, () => Math.round(rnd() * 8) - 4));
    b.push(Array.from({ length: MAT_N }, () => Math.round(rnd() * 8) - 4));
  }
  const c: number[][] = a.map((row) => row.map((_, j) => row.reduce((acc, v, k) => acc + v * b[k][j], 0)));
  return { a, b, c };
}

/* ------------------------------------------------------------------ *
 * ACCELERATOR LAB — educational first-principles model
 * ------------------------------------------------------------------ */

export interface LabConfig {
  cores: number; // 8 .. 256
  bandwidth: number; // 0.2 .. 2.0 relative GB/s-per-core units
  precision: PrecisionId;
  cache: number; // 1 .. 64 (relative MB)
  clock: number; // 0.8 .. 2.6 GHz
  workload: number; // 1 .. 10 (relative giga-op scale)
}

export const LAB_DEFAULTS: LabConfig = {
  cores: 64,
  bandwidth: 0.9,
  precision: "fp16",
  cache: 16,
  clock: 1.6,
  workload: 4,
};

export interface LabResult {
  precision: (typeof PRECISIONS)[number];
  /** relative peak operations / second */
  peak: number;
  /** bytes moved per operation after cache reuse */
  bytesPerOp: number;
  /** bytes/s required to keep the array fed */
  requiredBandwidth: number;
  /** bytes/s available */
  availableBandwidth: number;
  /** min(peak, bandwidth-limited throughput) */
  achieved: number;
  /** achieved / peak */
  utilisation: number;
  /** required / available */
  memoryPressure: number;
  /** relative energy per unit work */
  energyPerWork: number;
  /** relative thermal load 0..1+ */
  thermal: number;
  /** fraction of bytes absorbed by cache */
  hitRate: number;
  /** relative seconds to finish the workload */
  runtime: number;
  /** 0..1 completion, animated by the caller */
  completion: number;
  /** bound that limits the machine */
  bound: "COMPUTE" | "MEMORY" | "BALANCED";
}

/**
 * Cache reuse: bigger cache + smaller working set => fewer bytes off-die.
 * Modelled as a saturating power curve — shape, not a measured constant.
 */
function cacheHitRate(cache: number, workload: number, bytesPerOp: number) {
  const workingSet = workload * 2.2 * bytesPerOp * 4;
  const ratio = cache / workingSet;
  return clamp(0.42 * (1 - Math.exp(-3.1 * ratio)) + 0.06);
}

export function labModel(cfg: LabConfig): LabResult {
  const precision = PRECISIONS.find((p) => p.id === cfg.precision) ?? PRECISIONS[1];

  // Peak dense throughput: cores × lanes × clock, scaled by precision
  const peak = cfg.cores * precision.opsPerCycle * cfg.clock * 1.35;

  // Arithmetic intensity improves with reuse; cache absorbs some traffic
  const hit = cacheHitRate(cfg.cache, cfg.workload, precision.bytes);
  const bytesPerOp = precision.bytes * (1 - hit * 0.82);

  const availableBandwidth = cfg.bandwidth * cfg.cores * 0.42;
  const requiredBandwidth = peak * bytesPerOp;
  const memoryPressure = availableBandwidth > 0 ? requiredBandwidth / availableBandwidth : 99;

  const bandwidthLimited = availableBandwidth / Math.max(bytesPerOp, 1e-4);
  const achieved = Math.min(peak, bandwidthLimited);
  const utilisation = peak > 0 ? clamp(achieved / peak) : 0;

  const bound: LabResult["bound"] =
    memoryPressure > 1.12 ? "MEMORY" : memoryPressure < 0.86 ? "COMPUTE" : "BALANCED";

  const energyPerWork = precision.relEnergy * (0.55 + 0.75 * (bytesPerOp / precision.bytes) * 0.6);
  const thermal = clamp(
    (cfg.cores / 256) * 0.5 + (cfg.clock / 2.6) * 0.42 + precision.relEnergy * 0.22 - hit * 0.18,
    0.04,
    1.35
  );

  const runtime = achieved > 0 ? (cfg.workload * 1e3) / achieved : Infinity;

  return {
    precision,
    peak,
    bytesPerOp,
    requiredBandwidth,
    availableBandwidth,
    achieved,
    utilisation,
    memoryPressure,
    energyPerWork,
    thermal,
    hitRate: hit,
    runtime,
    completion: 0,
    bound,
  };
}

/** Normalised archetype comparison used in chapter 03 */
export function archetypeThroughput(parallel: number, precisionFactor: number, clockScale = 1) {
  return parallel * precisionFactor * clockScale;
}

import { useEffect, useRef, useState } from "react";
import { motion, useUI } from "@/state/store";
import { CHAPTERS, QUALITY_PROFILE, type Quality } from "@/lib/constants";
import { clamp, damp, plateau } from "@/lib/math";

/* ==================================================================
 * DOM-SIDE SYSTEM HOOKS
 * scroll → camera parameter, reveal masks, quality management
 * ================================================================== */

/** Measures the chapter sections and derives the continuous camera parameter. */
export function useChapterScroll() {
  const setChapter = useUI((s) => s.setChapter);
  useEffect(() => {
    let sections: HTMLElement[] = [];
    let keys: number[] = [];
    let raf = 0;
    let lastY = window.scrollY;
    let vel = 0;

    const measure = () => {
      sections = Array.from(document.querySelectorAll<HTMLElement>("[data-chapter]"));
      keys = sections.map((el) => el.offsetTop + el.offsetHeight / 2 - window.innerHeight / 2);
    };

    const update = () => {
      raf = 0;
      const y = window.scrollY;
      const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      vel = damp(vel, (y - lastY) / 40, 6, 0.016);
      lastY = y;
      motion.scroll = clamp(y / max);
      motion.velocity = vel;

      if (keys.length < 2) return;
      // find the segment containing the current scroll offset
      let i = 0;
      while (i < keys.length - 2 && y >= keys[i + 1]) i++;
      const k0 = keys[i];
      const k1 = keys[i + 1];
      const raw = k1 === k0 ? 0 : (y - k0) / (k1 - k0);
      motion.camT = i + plateau(raw, 0.14, 0.86);

      // active chapter = section under the viewport centre
      const centre = y + window.innerHeight / 2;
      let active = 0;
      for (let s = 0; s < sections.length; s++) {
        const el = sections[s];
        if (centre >= el.offsetTop && centre < el.offsetTop + el.offsetHeight) active = s;
      }
      if (useUI.getState().chapter !== active) setChapter(active);
    };

    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };

    measure();
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", measure);
    const t = window.setTimeout(measure, 400);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", measure);
      window.clearTimeout(t);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [setChapter]);
}

/** Reveal-mask observer for every `.rv` element in the document. */
export function useRevealMasks() {
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) e.target.classList.add("is-in");
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -8% 0px" }
    );
    const attach = () => {
      document.querySelectorAll<HTMLElement>(".rv:not(.is-in)").forEach((el) => io.observe(el));
    };
    attach();
    const t = window.setTimeout(attach, 600);
    return () => {
      io.disconnect();
      window.clearTimeout(t);
    };
  }, []);
}

/** Pointer parallax written straight into the mutable motion record. */
export function usePointerField() {
  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      motion.px = (e.clientX / window.innerWidth) * 2 - 1;
      motion.py = (e.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, []);
}

export function prefersReducedMotion() {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function detectQuality(): Quality {
  const mem = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 8;
  const cores = navigator.hardwareConcurrency ?? 4;
  const mobile = window.matchMedia("(max-width: 820px)").matches;
  if (mobile || cores <= 4 || mem <= 4) return "low";
  if (cores >= 8 && !mobile) return "high";
  return "medium";
}

/** Adaptive quality: device heuristics + live frame-time watchdog. */
export function useQualityManager(enabled: boolean) {
  const [quality, setQuality] = useState<Quality>("medium");
  const setStoreQuality = useUI((s) => s.setQuality);
  const setReducedMotion = useUI((s) => s.setReducedMotion);
  const downgrades = useRef(0);

  useEffect(() => {
    const q = detectQuality();
    setQuality(q);
    setStoreQuality(q);
    setReducedMotion(prefersReducedMotion());
    document.documentElement.classList.toggle("nf-static", prefersReducedMotion());
  }, [setStoreQuality, setReducedMotion]);

  useEffect(() => {
    if (!enabled) return;
    let frames = 0;
    let last = performance.now();
    let raf = 0;
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      frames++;
      if (now - last < 2000) return;
      const fps = (frames * 1000) / (now - last);
      frames = 0;
      last = now;
      if (fps < 30 && downgrades.current < 2) {
        downgrades.current++;
        setQuality((q) => {
          const next: Quality = q === "high" ? "medium" : "low";
          setStoreQuality(next);
          return next;
        });
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [enabled, setStoreQuality]);

  return quality;
}

/** Convenience for scenes: geometry budget for the active quality level. */
export function useBudget() {
  const quality = useUI((s) => s.quality);
  return QUALITY_PROFILE[quality];
}

export const CHAPTER_LENGTH = CHAPTERS.length;

/* ------------------------------------------------------------------
 * NARRATIVE CHOREOGRAPHY HOOKS
 * The DOM narrative is driven by the *camera parameter* (motion.camT),
 * so text appears/disappears at the precise scroll moments the camera
 * reaches a structure. State only changes when a boundary is crossed,
 * so these never re-render per-frame.
 * ------------------------------------------------------------------ */

/** True once scroll is at least `at` into the given chapter (camera-space). */
export function useVisibleAfter(chapter: number, at: number) {
  const [on, setOn] = useState(at <= 0);
  const ref = useRef(on);
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const v = motion.camT - chapter >= at;
      if (v !== ref.current) {
        ref.current = v;
        setOn(v);
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [chapter, at]);
  return on;
}

/** Which of `count` sequential narrative bands the camera currently occupies. */
export function useStageIndex(chapter: number, count: number) {
  const [stage, setStage] = useState(0);
  const ref = useRef(0);
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const p = Math.max(0, motion.camT - chapter);
      const s = Math.min(count - 1, Math.max(0, Math.floor(p * count)));
      if (s !== ref.current) {
        ref.current = s;
        setStage(s);
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [chapter, count]);
  return stage;
}

/** Shared math + animation helpers. Pure functions, no React, no THREE. */

export const clamp = (v: number, min = 0, max = 1) => (v < min ? min : v > max ? max : v);

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export const invLerp = (a: number, b: number, v: number) => (b === a ? 0 : (v - a) / (b - a));

export const smoothstep = (t: number) => {
  const x = clamp(t);
  return x * x * (3 - 2 * x);
};

/** smoothstep between edges */
export const sstep = (a: number, b: number, v: number) => smoothstep(invLerp(a, b, v));

/** Frame-rate independent exponential damping. */
export const damp = (current: number, target: number, lambda: number, dt: number) =>
  current + (target - current) * (1 - Math.exp(-lambda * Math.min(dt, 0.1)));

export const dampV3 = (
  c: [number, number, number],
  t: [number, number, number],
  lambda: number,
  dt: number
) => {
  c[0] = damp(c[0], t[0], lambda, dt);
  c[1] = damp(c[1], t[1], lambda, dt);
  c[2] = damp(c[2], t[2], lambda, dt);
  return c;
};

/** Plateau easing: holds 0 until `in`, reaches 1 at `out`. Keeps camera poses readable. */
export const plateau = (t: number, edgeIn = 0.22, edgeOut = 0.78) =>
  smoothstep(invLerp(edgeIn, edgeOut, clamp(t)));

export const easeOutCubic = (t: number) => 1 - Math.pow(1 - clamp(t), 3);

export const easeInOutCubic = (t: number) => {
  const x = clamp(t);
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
};

/** Deterministic PRNG (mulberry32) — stable layouts across reloads. */
export function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** fbm-ish 1D value noise for signal modulation */
export function noise1(x: number, seed = 1) {
  const i = Math.floor(x);
  const f = x - i;
  const u = f * f * (3 - 2 * f);
  const h = (n: number) => {
    const s = Math.sin((n * 127.1 + seed * 311.7) * 0.017453) * 43758.5453;
    return s - Math.floor(s);
  };
  return lerp(h(i), h(i + 1), u);
}

export const fmt = (v: number, digits = 2) =>
  v.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });

export const fmtInt = (v: number) => Math.round(v).toLocaleString("en-US");

export const pad2 = (n: number) => (n < 10 ? `0${n}` : `${n}`);
